package net.des.vyrnth.hub;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.util.Cuboid;
import net.des.vyrnth.util.Msg;
import org.bukkit.*;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.logging.Level;

/**
 * Hidden things in the hub: data logs, switches and multi-step secret passages. A secret with `requires: [a, b]` only works if the
 * player activated a and b within the last 2 minutes. Passages reopen themselves after `seconds`. Rewards pay once per player ever.
 */
public final class HubSecrets implements Listener {
    private record Hs(String id, int x, int y, int z, String type, String title, List<String> text, List<String> requires,
                      String opens, String message, long reward, String item) {}
    private record HubGate(Cuboid region, int seconds) {}

    private final VyrnthPlugin plugin;
    private final List<Hs> secrets = new ArrayList<>();
    private final Map<String, HubGate> gates = new HashMap<>();
    private final Set<String> openGates = new HashSet<>();
    private final Map<UUID, Map<String, Long>> session = new HashMap<>();

    public HubSecrets(VyrnthPlugin plugin) { this.plugin = plugin; }

    public void reload() {
        secrets.clear(); gates.clear();
        ConfigurationSection gs = plugin.getConfig().getConfigurationSection("hub-gates");
        if (gs != null) for (String k : gs.getKeys(false)) {
            try { gates.put(k, new HubGate(Cuboid.read(gs.getConfigurationSection(k)), gs.getInt(k + ".seconds", 20))); }
            catch (Exception e) { plugin.getLogger().log(Level.WARNING, "Bad hub gate " + k, e); }
        }
        ConfigurationSection ss = plugin.getConfig().getConfigurationSection("hub-secrets");
        if (ss != null) for (String k : ss.getKeys(false)) {
            try {
                ConfigurationSection e = ss.getConfigurationSection(k);
                List<Integer> pos = e.getIntegerList("pos");
                if (pos.size() != 3) throw new IllegalArgumentException("pos needs [x,y,z]");
                secrets.add(new Hs(k, pos.get(0), pos.get(1), pos.get(2), e.getString("type", "DATA_LOG").toUpperCase(Locale.ROOT),
                        e.getString("title", k), e.getStringList("text"), e.getStringList("requires"), e.getString("opens", ""),
                        e.getString("message", ""), e.getLong("reward", 0), e.getString("item", "")));
            } catch (Exception e) { plugin.getLogger().log(Level.WARNING, "Bad hub secret " + k, e); }
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (secrets.isEmpty() || e.getHand() != EquipmentSlot.HAND || e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        Player p = e.getPlayer();
        if (!p.getWorld().equals(plugin.hubSpawn().getWorld()) || plugin.instances().of(p.getUniqueId()) != null) return;
        var b = e.getClickedBlock();
        for (Hs s : secrets) {
            if (s.x() != b.getX() || s.y() != b.getY() || s.z() != b.getZ()) continue;
            e.setCancelled(true);
            long now = System.currentTimeMillis();
            Map<String, Long> done = session.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>());
            for (String req : s.requires()) {
                Long t = done.get(req);
                if (t == null || now - t > 120_000) { p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.6f, 0.6f); return; }   // deliberately silent
            }
            done.put(s.id(), now);
            trigger(p, s);
            return;
        }
    }

    private void trigger(Player p, Hs s) {
        if (s.type().equals("SWITCH")) {
            p.playSound(p.getLocation(), Sound.BLOCK_PISTON_EXTEND, 1f, 0.8f);
            if (!s.message().isBlank()) Msg.send(p, s.message());
            if (!s.opens().isBlank()) openGate(s.opens());
        } else {
            Msg.title(p, "<aqua><bold>" + s.title(), "<gray>Archive entry");
            for (String line : s.text()) p.sendMessage(Msg.c("<dark_aqua>▎ <gray>" + line));
            p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1f);
        }
        if (s.reward() <= 0 && s.item().isBlank()) return;
        byte[] item = null;
        if (!s.item().isBlank()) { ItemStack it = plugin.loot().resolve(s.item(), 1); if (it != null) item = it.serializeAsBytes(); }
        UUID id = p.getUniqueId();
        plugin.progression().recordSecret(id, "hub", s.id(), s.reward(), item).whenComplete((first, err) -> plugin.sync(() -> {
            Player pl = Bukkit.getPlayer(id);
            if (err != null || pl == null || !first) return;
            Msg.send(pl, "<light_purple>✦ Hub secret discovered!" + (s.reward() > 0 ? " <gray>+" + s.reward() + " " + plugin.currencyName() : ""));
            plugin.inbox().deliverAll(pl);
        }));
    }

    private void openGate(String id) {
        HubGate g = gates.get(id);
        World w = plugin.hubSpawn().getWorld();
        if (g == null || w == null || !openGates.add(id)) return;
        Cuboid c = g.region();
        List<int[]> cells = new ArrayList<>();
        List<BlockData> saved = new ArrayList<>();
        for (int x = (int) c.minX(); x <= (int) c.maxX(); x++)
            for (int y = (int) c.minY(); y <= (int) c.maxY(); y++)
                for (int z = (int) c.minZ(); z <= (int) c.maxZ(); z++) {
                    if (cells.size() >= 2000) break;
                    cells.add(new int[]{x, y, z}); saved.add(w.getBlockAt(x, y, z).getBlockData());
                }
        for (int[] c0 : cells) w.getBlockAt(c0[0], c0[1], c0[2]).setType(Material.AIR, false);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {   // the hub is shared: always put the wall back
            for (int k = 0; k < cells.size(); k++) { int[] c0 = cells.get(k); w.getBlockAt(c0[0], c0[1], c0[2]).setBlockData(saved.get(k), false); }
            openGates.remove(id);
        }, 20L * Math.max(3, g.seconds()));
    }

    /** Called on plugin disable so no passage stays open. */
    public void shutdown() { /* gates restore via scheduled tasks; on a crash the hub world keeps its saved state */ }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { session.remove(e.getPlayer().getUniqueId()); }
}
