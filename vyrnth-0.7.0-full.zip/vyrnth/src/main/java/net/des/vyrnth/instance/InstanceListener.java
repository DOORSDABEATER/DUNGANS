package net.des.vyrnth.instance;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.util.Msg;
import org.bukkit.GameMode;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class InstanceListener implements Listener {
    private final VyrnthPlugin plugin;
    private final InstanceManager im;

    public InstanceListener(VyrnthPlugin plugin) { this.plugin = plugin; this.im = plugin.instances(); }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        plugin.progression().load(id);
        Instance i = im.of(id);
        if (i != null) {   // reconnect inside grace window
            if (i.disconnectedAt.remove(id) != null) {
                im.broadcast(i, "<green>" + p.getName() + " reconnected.");
                if (i.spectators.contains(id)) plugin.sync(() -> p.setGameMode(GameMode.SPECTATOR));
                if (i.world != null && !p.getWorld().equals(i.world) && i.checkpoint != null) im.teleport(p, i.checkpoint);
            }
            return;
        }
        plugin.db().submit(c -> {
            try (var ps = c.prepareStatement("SELECT prev_mode FROM in_run WHERE uuid = ?")) {
                ps.setString(1, id.toString());
                try (var rs = ps.executeQuery()) { return rs.next() ? rs.getString(1) : null; }
            }
        }).thenAccept(mode -> plugin.sync(() -> {
            if (!p.isOnline() || im.of(id) != null) return;
            boolean inInstWorld = InstanceManager.PREFIX.length() > 0 && p.getWorld().getName().startsWith(InstanceManager.PREFIX);
            if (mode != null || inInstWorld) {
                GameMode gm;
                try { gm = GameMode.valueOf(mode == null ? "SURVIVAL" : mode); } catch (IllegalArgumentException ex) { gm = GameMode.SURVIVAL; }
                im.restoreStranded(p, gm);
            } else {
                im.stripBeacon(p);   // stray beacon from an old run
            }
        })).exceptionally(t -> null);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        Instance i = im.of(p.getUniqueId());
        if (i != null) im.handleDisconnect(i, p);
        plugin.parties().onQuit(p.getUniqueId());
        plugin.progression().unload(p.getUniqueId());
        plugin.entry().onQuit(p.getUniqueId());
        plugin.matchmaking().leave(p.getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Instance i = im.of(e.getPlayer().getUniqueId());
        if (i != null) im.handleDeath(i, e);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Instance i = im.of(e.getPlayer().getUniqueId());
        if (i != null) im.handleRespawn(i, e);
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent e) {
        Instance wi = im.ofWorld(e.getEntity().getWorld());
        if (wi != null) im.rooms().onMobDeath(wi, e.getEntity().getUniqueId());
        Instance i = im.ofBoss(e.getEntity().getUniqueId());
        if (i != null) im.complete(i);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (im.of(p.getUniqueId()) == null || p.isOp()) return;
        String base = e.getMessage().substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
        if (base.contains(":")) base = base.substring(base.indexOf(':') + 1);
        List<String> allow = plugin.getConfig().getStringList("command-allowlist");
        if (!allow.contains(base)) {
            e.setCancelled(true);
            Msg.send(p, "<red>You can't use that command during an expedition.");
        }
    }

    /** Blocks every route out of (or into) an instance that isn't one of our own teleports. */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        Player p = e.getPlayer();
        if (p.isOp() || im.isInternalTeleport(p.getUniqueId()) || e.getTo() == null) return;
        World to = e.getTo().getWorld();
        Instance mine = im.of(p.getUniqueId());
        Instance dest = im.ofWorld(to);
        if (dest != null && dest != mine) { e.setCancelled(true); return; }
        if (mine != null && mine.world != null && !mine.world.equals(to)) {
            e.setCancelled(true);
            Msg.send(p, "<red>You can't leave an active expedition that way. Use the Exit Beacon.");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(org.bukkit.event.entity.EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Instance i = im.of(p.getUniqueId());
        if (i != null && "FRAGILE".equals(i.modifier) && i.members.contains(p.getUniqueId())) e.setDamage(e.getDamage() * 1.25);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim) || im.ofWorld(victim.getWorld()) == null) return;
        Entity d = e.getDamager();
        if (d instanceof Projectile pr && pr.getShooter() instanceof Entity s) d = s;
        if (d instanceof Player) e.setCancelled(true);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND || !e.getAction().isRightClick()) return;
        Player p = e.getPlayer();
        Instance inst = im.of(p.getUniqueId());
        if (im.isBeacon(e.getItem())) {
            e.setCancelled(true);
            if (inst != null) plugin.menus().openAbandon(p);
            return;
        }
        if (inst != null && e.getClickedBlock() != null && e.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK
                && im.rooms().onInteract(inst, p, e.getClickedBlock().getLocation())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (im.isBeacon(e.getItemDrop().getItemStack())) e.setCancelled(true);
    }
}
