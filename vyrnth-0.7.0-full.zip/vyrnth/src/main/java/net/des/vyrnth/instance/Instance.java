package net.des.vyrnth.instance;

import net.des.vyrnth.dungeon.Difficulty;
import net.des.vyrnth.dungeon.DungeonDefinition;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.*;

/** One isolated run of one dungeon. All fields are touched from the main thread only. */
public final class Instance {
    public enum State { PREPARING, ACTIVE, COMPLETED, FAILED, CLOSING }

    public final UUID runId = UUID.randomUUID();
    public final DungeonDefinition def;
    public final Difficulty difficulty;
    public final String worldName;
    public World world;
    public State state = State.PREPARING;

    public final Set<UUID> members = new LinkedHashSet<>();      // everyone still part of the run
    public final Set<UUID> spectators = new HashSet<>();         // out of lives
    public final Map<UUID, Integer> lives = new HashMap<>();     // -1 = unlimited
    public final Map<UUID, Long> disconnectedAt = new HashMap<>();
    public final Map<UUID, GameMode> prevMode = new HashMap<>();

    public final Map<String, RoomState> rooms = new HashMap<>();
    public final Set<String> openedGates = new HashSet<>(), foundSecrets = new HashSet<>();

    public final Map<String, Long> nextFire = new HashMap<>();
    public final Map<String, MechanicsManager.CrushState> crush = new HashMap<>();
    public final Map<String, MechanicsManager.PlatState> plats = new HashMap<>();

    public final Map<String, Long> tpCool = new HashMap<>();
    public final Map<String, Integer> revivalUses = new HashMap<>();
    public final Map<UUID, String> secretBosses = new HashMap<>();
    public final Set<UUID> watchers = new LinkedHashSet<>();     // spectators who are not part of the run
    public int bossPhase = 1;
    public String modifier;                                      // weekly encounter modifier fixed at start
    public long nextMusicMs;
    public boolean bossMusicOn;

    public Location checkpoint;
    public int checkpointIndex = -1;
    public long startMs, closeAtMs;
    public boolean bossQueued, bossSpawned;
    public UUID bossId;
    public int deaths;
    public final Map<UUID, Integer> deathsBy = new HashMap<>();

    public Instance(DungeonDefinition def, Difficulty difficulty, String worldName) {
        this.def = def; this.difficulty = difficulty; this.worldName = worldName;
    }

    public String shortId() { return runId.toString().substring(0, 8); }
}
