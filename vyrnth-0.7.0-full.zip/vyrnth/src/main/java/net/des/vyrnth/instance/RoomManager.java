package net.des.vyrnth.instance;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.dungeon.Layout;
import net.des.vyrnth.util.Msg;
import org.bukkit.*;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;

/** Runs the data-driven rooms, hazards, gates, secrets, revival points and secret bosses of one instance. Main thread only. */
public final class RoomManager {
    private static final int MAX_GATE_BLOCKS = 12_000;
    private final VyrnthPlugin plugin;
    private final Set<String> warnedEffects = new HashSet<>();

    public RoomManager(VyrnthPlugin plugin) { this.plugin = plugin; }

    private RoomState st(Instance i, String id) { return i.rooms.computeIfAbsent(id, k -> new RoomState()); }

    private int holdSeconds(Instance i, Layout.Room r) {
        if (r.type().equals("SURVIVE")) return r.hold() + r.holdReduction() * i.difficulty.ordinal();   // longer on higher difficulties
        return Math.max(5, r.hold() - r.holdReduction() * i.difficulty.ordinal());                          // shorter window on higher difficulties
    }

    // ------------------------------------------------------------------ tick
    public void tick(Instance i, List<Player> alive, long now) {
        Layout L = i.def.layout;
        for (Layout.Hazard h : L.hazards) hazard(i, h, alive);
        for (Layout.Room r : L.rooms) {
            RoomState s = st(i, r.id());
            if (s.complete) continue;
            for (Layout.Hazard h : r.hazards()) hazard(i, h, alive);
            if (!s.active) {
                for (Player p : alive) if (r.trigger().contains(p.getLocation())) { activate(i, r, s, alive, now); break; }
                continue;
            }
            switch (r.type()) {
                case "ACTIVATE" -> tickActivate(i, r, s, alive, now);
                case "REACH" -> { for (Player p : alive) if (r.goal().contains(p.getLocation())) { completeRoom(i, r, s); break; } }
                case "SURVIVE" -> {
                    long left = holdSeconds(i, r) * 1000L - (now - s.startMs);
                    if (left <= 0) completeRoom(i, r, s);
                    else for (Player p : alive) p.sendActionBar(Msg.c("<yellow>Survive <white>" + (left / 1000 + 1) + "s"));
                }
                case "SEQUENCE" -> {
                    if (s.seq > 0 && r.hold() > 0 && now - s.seqStart > r.hold() * 1000L) {
                        s.seq = 0;
                        plugin.instances().broadcast(i, "<red>Terminal timed out. Sequence reset.");
                    }
                }
                default -> { }
            }
        }
    }

    private void hazard(Instance i, Layout.Hazard h, List<Player> alive) {
        if (i.difficulty.ordinal() < h.minDiff().ordinal()) return;
        PotionEffectType type = effect(h.effect());
        for (Player p : alive) {
            if (!h.region().contains(p.getLocation())) continue;
            if (type != null) p.addPotionEffect(new PotionEffect(type, 50, h.amp(), true, true, true));
            if (h.damage() > 0) p.damage(h.damage());
            p.getWorld().spawnParticle(Particle.SPORE_BLOSSOM_AIR, p.getLocation().add(0, 1, 0), 8, 0.8, 0.6, 0.8, 0);
        }
    }

    private PotionEffectType effect(String name) {
        if (name == null || name.isBlank()) return null;
        PotionEffectType t = PotionEffectType.getByKey(NamespacedKey.minecraft(name.toLowerCase(Locale.ROOT)));
        if (t == null && warnedEffects.add(name)) plugin.getLogger().warning("Unknown hazard effect '" + name + "'");
        return t;
    }

    // ------------------------------------------------------------------ rooms
    private void activate(Instance i, Layout.Room r, RoomState s, List<Player> alive, long now) {
        s.active = true;
        s.startMs = now;
        if (!r.message().isBlank()) plugin.instances().broadcast(i, r.message());
        int failures = 0;
        if (r.type().equals("WAVES")) { s.wave = 1; failures = spawn(i, r, s, 1, alive.size()); }
        else failures = spawn(i, r, s, 0, alive.size());
        s.spawned = true;
        if (failures > 0) {
            for (Player op : Bukkit.getOnlinePlayers()) if (op.isOp()) Msg.send(op, "<red>Room " + r.id() + ": " + failures + " spawn(s) failed. See console.");
        }
        switch (r.type()) {
            case "ROUTING" -> {
                var rt = r.routing();
                s.jstate = new int[rt.junctions().size()];
                do { for (int k = 0; k < s.jstate.length; k++) s.jstate[k] = ThreadLocalRandom.current().nextInt(rt.states()); }
                while (Arrays.equals(s.jstate, rt.solution()));
                plugin.instances().broadcast(i, "<yellow>Power is down. Route it correctly through all " + s.jstate.length + " junctions (right-click to cycle).");
            }
            case "REACH" -> plugin.instances().broadcast(i, "<yellow>Cross to the far side.");
            case "ACTIVATE" -> plugin.instances().broadcast(i, "<yellow>Activate all " + r.activators().size() + " switches within " + holdSeconds(i, r) + "s of the first one. Work together!");
            case "SURVIVE" -> plugin.instances().broadcast(i, "<yellow>Survive for " + holdSeconds(i, r) + " seconds.");
            case "SEQUENCE" -> plugin.instances().broadcast(i, "<yellow>Enter the access sequence on the terminals. Mistakes shock you.");
            case "WAVES" -> {
                plugin.instances().broadcast(i, "<yellow>Wave 1/" + r.waves());
                if (s.required.isEmpty()) advanceWave(i, r, s);
            }
            case "CLEAR_SPAWNS" -> { if (s.required.isEmpty()) completeRoom(i, r, s); }   // nothing to kill: never soft-lock
            default -> { }
        }
    }

    /** Spawns the room's mobs. wave 0 = everything (non-WAVES rooms); otherwise only that wave. @return number of failed spawns */
    private int spawn(Instance i, Layout.Room r, RoomState s, int wave, int players) {
        int diff = i.difficulty.ordinal();
        int failures = 0;
        String lastError = "";
        for (Layout.Spawn sp : r.spawns()) {
            if (diff < sp.minDiff().ordinal() || (wave != 0 && sp.wave() != wave)) continue;
            int count = sp.count() + sp.extraPerDiff() * diff + sp.perPlayer() * Math.max(0, players - 1);
            if ("SWARM".equals(i.modifier)) count = (int) Math.ceil(count * 1.5);
            count = Math.min(40, count);
            for (int k = 0; k < count; k++) {
                Location loc = sp.pos().at(i.world);
                if (count > 1) loc.add(ThreadLocalRandom.current().nextDouble(-2.5, 2.5), 0, ThreadLocalRandom.current().nextDouble(-2.5, 2.5));
                try {
                    Entity e = spawnOne(i, sp, loc);
                    if (e == null) { failures++; continue; }
                    s.all.add(e.getUniqueId());
                    if (sp.required()) s.required.add(e.getUniqueId());
                } catch (Exception ex) { failures++; lastError = sp.mob() + ": " + ex.getMessage(); }
            }
        }
        if (failures > 0) plugin.getLogger().log(Level.SEVERE, "Room " + r.id() + " in " + i.worldName + ": " + failures + " spawn(s) failed (" + lastError + ")");
        return failures;
    }

    private Entity spawnOne(Instance i, Layout.Spawn sp, Location loc) throws Exception {
        String mob = sp.mob();
        if (!sp.rareMob().isBlank() && ThreadLocalRandom.current().nextDouble() < sp.rareChance()) {
            mob = sp.rareMob();
            plugin.instances().broadcast(i, "<light_purple>✦ A rare variant emerges!");
        }
        Entity e = plugin.mythic().spawn(mob, loc);
        if (e instanceof LivingEntity le && "MOB_HASTE".equals(i.modifier))
            le.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, PotionEffect.INFINITE_DURATION, 1, true, false));
        return e;
    }

    private void advanceWave(Instance i, Layout.Room r, RoomState s) {
        if (s.wave >= r.waves()) { completeRoom(i, r, s); return; }
        s.wave++;
        plugin.instances().broadcast(i, "<yellow>Wave " + s.wave + "/" + r.waves());
        for (UUID id : i.members) { Player p = Bukkit.getPlayer(id); if (p != null) p.playSound(p.getLocation(), Sound.EVENT_RAID_HORN, 1f, 1f); }
        spawn(i, r, s, s.wave, plugin.instances().aliveIn(i).size());
        if (s.required.isEmpty()) advanceWave(i, r, s);
    }

    private void tickActivate(Instance i, Layout.Room r, RoomState s, List<Player> alive, long now) {
        if (s.activated.isEmpty()) return;
        long left = holdSeconds(i, r) * 1000L - (now - s.windowStart);
        if (left <= 0) {
            s.activated.clear();
            plugin.instances().broadcast(i, "<red>The switches shut down. Activate them together, and faster!");
            return;
        }
        for (Player p : alive)
            p.sendActionBar(Msg.c("<green>Switches " + s.activated.size() + "/" + r.activators().size() + " <gray>· <yellow>" + (left / 1000 + 1) + "s"));
    }

    public void onMobDeath(Instance i, UUID entity) {
        String sb = i.secretBosses.remove(entity);
        if (sb != null) secretBossDefeated(i, sb);
        for (Layout.Room r : i.def.layout.rooms) {
            RoomState s = i.rooms.get(r.id());
            if (s == null || s.complete || !s.spawned) continue;
            s.all.remove(entity);
            if (s.required.remove(entity) && s.required.isEmpty()) {
                if (r.type().equals("CLEAR_SPAWNS")) completeRoom(i, r, s);
                else if (r.type().equals("WAVES")) advanceWave(i, r, s);
            }
        }
    }

    public void completeRoom(Instance i, Layout.Room r, RoomState s) {
        if (s.complete) return;
        s.complete = true;
        s.active = true;
        for (UUID id : s.all) { Entity e = Bukkit.getEntity(id); if (e != null) e.remove(); }   // no leftover entities
        s.all.clear(); s.required.clear();
        for (String g : r.opens()) openGate(i, g);
        if (r.checkpoint() != null) i.checkpoint = r.checkpoint().at(i.world);
        for (UUID id : i.members) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            Msg.send(p, "<green>Objective complete." + (r.checkpoint() != null ? " Checkpoint saved." : ""));
            p.playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.7f, 1.3f);
        }
    }

    /** Admin recovery tool for soft-locks. */
    public boolean forceComplete(Instance i, String roomId) {
        for (Layout.Room r : i.def.layout.rooms) if (r.id().equals(roomId)) { completeRoom(i, r, st(i, r.id())); return true; }
        return false;
    }

    public void openGate(Instance i, String gateId) {
        if (!i.openedGates.add(gateId)) return;
        var c = i.def.layout.gates.get(gateId);
        if (c == null || i.world == null) return;
        long size = (long) (c.maxX() - c.minX() + 1) * (long) (c.maxY() - c.minY() + 1) * (long) (c.maxZ() - c.minZ() + 1);
        if (size > MAX_GATE_BLOCKS) { plugin.getLogger().warning("Gate '" + gateId + "' is too large (" + size + " blocks); not opened."); return; }
        for (int x = (int) c.minX(); x <= (int) c.maxX(); x++)
            for (int y = (int) c.minY(); y <= (int) c.maxY(); y++)
                for (int z = (int) c.minZ(); z <= (int) c.maxZ(); z++)
                    i.world.getBlockAt(x, y, z).setType(Material.AIR, false);
        Location mid = new Location(i.world, (c.minX() + c.maxX()) / 2 + 0.5, (c.minY() + c.maxY()) / 2, (c.minZ() + c.maxZ()) / 2 + 0.5);
        i.world.playSound(mid, Sound.BLOCK_MOSS_BREAK, 2f, 0.6f);
        plugin.instances().broadcast(i, "<green>A path opens...");
    }

    // ------------------------------------------------------------------ interaction
    /** @return true if the click was a puzzle/secret/revival interaction (caller cancels the event). */
    public boolean onInteract(Instance i, Player p, Location block) {
        if (i.state != Instance.State.ACTIVE || !p.getWorld().equals(i.world) || i.spectators.contains(p.getUniqueId())) return false;
        int x = block.getBlockX(), y = block.getBlockY(), z = block.getBlockZ();
        long now = System.currentTimeMillis();
        for (Layout.Room r : i.def.layout.rooms) {
            RoomState s = i.rooms.get(r.id());
            if (s == null || !s.active || s.complete) continue;
            switch (r.type()) {
                case "ACTIVATE" -> {
                    for (int[] a : r.activators()) {
                        if (a[0] != x || a[1] != y || a[2] != z) continue;
                        long hold = holdSeconds(i, r) * 1000L;
                        if (s.activated.isEmpty() || now - s.windowStart > hold) { s.activated.clear(); s.windowStart = now; }
                        String key = x + "," + y + "," + z;
                        if (s.activated.containsKey(key)) { Msg.send(p, "<gray>This switch is already running."); return true; }
                        s.activated.put(key, now);
                        block.getWorld().spawnParticle(Particle.END_ROD, block.clone().add(0.5, 1.0, 0.5), 25, 0.3, 0.5, 0.3, 0.02);
                        block.getWorld().playSound(block, Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.2f);
                        if (s.activated.size() >= r.activators().size()) completeRoom(i, r, s);
                        return true;
                    }
                }
                case "ROUTING" -> { if (s.jstate != null && routing(i, p, r, s, x, y, z, block)) return true; }
                case "SEQUENCE" -> { if (sequence(i, p, r, s, x, y, z, block, now)) return true; }
                default -> { }
            }
        }
        for (Layout.Revival rv : i.def.layout.revivals) if (rv.x() == x && rv.y() == y && rv.z() == z) { revive(i, p, rv); return true; }
        for (Layout.Secret sec : i.def.layout.secrets) if (sec.x() == x && sec.y() == y && sec.z() == z) { secret(i, p, sec); return true; }
        return false;
    }

    private boolean routing(Instance i, Player p, Layout.Room r, RoomState s, int x, int y, int z, Location block) {
        var rt = r.routing();
        for (int k = 0; k < rt.junctions().size(); k++) {
            int[] j = rt.junctions().get(k);
            if (j[0] != x || j[1] != y || j[2] != z) continue;
            s.jstate[k] = (s.jstate[k] + 1) % rt.states();
            int correct = 0;
            for (int m = 0; m < s.jstate.length; m++) if (s.jstate[m] == rt.solution()[m]) correct++;
            String label = rt.labels().isEmpty() ? String.valueOf(s.jstate[k]) : rt.labels().get(s.jstate[k] % rt.labels().size());
            boolean feedback = i.difficulty.ordinal() < rt.hideFeedbackFrom().ordinal();
            p.sendActionBar(Msg.c("<aqua>Junction " + (k + 1) + " → <white>" + label + (feedback ? " <gray>· Power flow <green>" + correct + "/" + s.jstate.length : "")));
            block.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, block.clone().add(0.5, 1.0, 0.5), 20, 0.3, 0.4, 0.3, 0.05);
            block.getWorld().playSound(block, Sound.BLOCK_COMPARATOR_CLICK, 1f, 0.8f + 0.2f * s.jstate[k]);
            if (correct == s.jstate.length) completeRoom(i, r, s);
            return true;
        }
        return false;
    }

    private boolean sequence(Instance i, Player p, Layout.Room r, RoomState s, int x, int y, int z, Location block, long now) {
        var q = r.sequence();
        for (int b = 0; b < q.buttons().size(); b++) {
            int[] c = q.buttons().get(b);
            if (c[0] != x || c[1] != y || c[2] != z) continue;
            if (q.order()[s.seq] == b) {
                if (s.seq == 0) s.seqStart = now;
                s.seq++;
                block.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, block.clone().add(0.5, 1.0, 0.5), 8, 0.2, 0.3, 0.2, 0);
                block.getWorld().playSound(block, Sound.BLOCK_NOTE_BLOCK_CHIME, 1f, 0.6f + 0.15f * s.seq);
                p.sendActionBar(Msg.c("<green>Access sequence " + s.seq + "/" + q.order().length));
                if (s.seq >= q.order().length) completeRoom(i, r, s);
            } else {
                s.seq = 0;
                p.damage(q.failDamage());
                block.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, block.clone().add(0.5, 1.0, 0.5), 30, 0.3, 0.4, 0.3, 0.1);
                block.getWorld().playSound(block, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.6f, 2f);
                plugin.instances().broadcast(i, "<red>ACCESS DENIED. Sequence reset.");
            }
            return true;
        }
        return false;
    }

    private void revive(Instance i, Player p, Layout.Revival rv) {
        if (!plugin.getConfig().getBoolean("revival.enabled", true)) { Msg.send(p, "<gray>Revival is disabled."); return; }
        int used = i.revivalUses.getOrDefault(rv.id(), 0);
        if (used >= rv.uses()) { Msg.send(p, "<gray>This revival point is depleted."); return; }
        UUID target = null;
        for (UUID id : i.spectators) if (i.members.contains(id) && Bukkit.getPlayer(id) != null) { target = id; break; }
        if (target == null) { Msg.send(p, "<gray>No fallen teammates to revive."); return; }
        Player t = Bukkit.getPlayer(target);
        i.spectators.remove(target);
        i.lives.put(target, Math.max(1, plugin.getConfig().getInt("revival.lives-granted", 1)));
        plugin.instances().setRunMode(t);
        Location at = new Location(i.world, rv.x() + 0.5, rv.y() + 1, rv.z() + 0.5);
        plugin.instances().teleport(t, at);
        i.revivalUses.put(rv.id(), used + 1);
        i.world.spawnParticle(Particle.TOTEM_OF_UNDYING, at, 60, 0.5, 1, 0.5, 0.3);
        i.world.playSound(at, Sound.ITEM_TOTEM_USE, 1f, 1f);
        plugin.instances().broadcast(i, "<green>" + p.getName() + " revived " + t.getName() + "!");
    }

    private void secret(Instance i, Player p, Layout.Secret sec) {
        if (sec.type().equals("SWITCH")) {
            if (!i.foundSecrets.add(sec.id())) { Msg.send(p, "<gray>Nothing more happens."); return; }
            if (!sec.message().isBlank()) plugin.instances().broadcast(i, sec.message());
            if (!sec.opens().isBlank()) openGate(i, sec.opens());
            p.playSound(p.getLocation(), Sound.BLOCK_PISTON_EXTEND, 1f, 0.7f);
        } else {
            i.foundSecrets.add(sec.id());
            Msg.title(p, "<aqua><bold>" + sec.title(), "<gray>Data log");
            for (String line : sec.text()) p.sendMessage(Msg.c("<dark_aqua>▎ <gray>" + line));
            p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1f);
        }
        checkSecretBosses(i, sec.id());
        byte[] item = null;
        if (!sec.item().isBlank()) { ItemStack it = plugin.loot().resolve(sec.item(), 1); if (it != null) item = it.serializeAsBytes(); }
        UUID id = p.getUniqueId();
        plugin.progression().recordSecret(id, i.def.id, sec.id(), sec.reward(), item).whenComplete((first, err) -> plugin.sync(() -> {
            if (err != null) { plugin.getLogger().log(Level.SEVERE, "Secret record failed for " + id, err); return; }
            Player pl = Bukkit.getPlayer(id);
            if (pl == null || !first) return;
            Msg.send(pl, "<light_purple>✦ Secret discovered!" + (sec.reward() > 0 ? " <gray>+" + sec.reward() + " " + plugin.currencyName() : ""));
            plugin.inbox().deliverAll(pl);
        }));
    }

    // ------------------------------------------------------------------ secret bosses
    private void checkSecretBosses(Instance i, String foundId) {
        for (Layout.SecretBoss b : i.def.layout.secretBosses) {
            if (!b.after().equals(foundId) || i.difficulty.ordinal() < b.minDiff().ordinal()) continue;
            if (!i.foundSecrets.add("sb:" + b.id())) continue;
            try {
                Entity e = plugin.mythic().spawn(b.mob(), b.pos().at(i.world));
                if (e == null) throw new IllegalStateException("no entity");
                i.secretBosses.put(e.getUniqueId(), b.id());
                if (e instanceof LivingEntity le) plugin.instances().scaleHealth(i, le);
                if (!b.message().isBlank()) plugin.instances().broadcast(i, b.message());
            } catch (Exception ex) {
                plugin.getLogger().log(Level.SEVERE, "Secret boss spawn failed (" + b.mob() + ")", ex);
            }
        }
    }

    private void secretBossDefeated(Instance i, String bossId) {
        Layout.SecretBoss b = null;
        for (Layout.SecretBoss x : i.def.layout.secretBosses) if (x.id().equals(bossId)) b = x;
        if (b == null) return;
        final Layout.SecretBoss boss = b;
        byte[] item = null;
        if (!boss.item().isBlank()) { ItemStack it = plugin.loot().resolve(boss.item(), 1); if (it != null) item = it.serializeAsBytes(); }
        final byte[] bytes = item;
        plugin.instances().broadcast(i, "<light_purple><bold>SECRET BOSS DEFEATED.");
        for (UUID id : List.copyOf(i.members)) {
            plugin.progression().recordSecret(id, i.def.id, "boss:" + boss.id(), boss.reward(), bytes).whenComplete((first, err) -> plugin.sync(() -> {
                if (err != null) { plugin.getLogger().log(Level.SEVERE, "Secret boss reward failed for " + id, err); return; }
                Player pl = Bukkit.getPlayer(id);
                if (pl == null || !first) return;
                Msg.send(pl, "<light_purple>✦ Secret boss reward! <gray>+" + boss.reward() + " " + plugin.currencyName());
                plugin.inbox().deliverAll(pl);
            }));
        }
    }
}
