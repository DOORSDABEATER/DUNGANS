package net.des.vyrnth.economy;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.data.CurrencyService;
import net.des.vyrnth.data.InboxService;
import net.des.vyrnth.util.Msg;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.*;
import java.util.logging.Level;

/** Dungeon shop: fixed stock + a daily rotation + optional limited-time items. Purchases are one atomic transaction. */
public final class ShopService {
    public record Item(String key, String display, long price, byte[] data, Material icon, int dailyLimit, boolean rotating, long untilMs) {}

    private final VyrnthPlugin plugin;
    private final Map<String, Item> items = new LinkedHashMap<>();
    private int rotatingSlots = 3;

    public ShopService(VyrnthPlugin plugin) { this.plugin = plugin; }

    public void reload() {
        items.clear();
        File f = new File(plugin.getDataFolder(), "shop.yml");
        if (!f.exists()) plugin.saveResource("shop.yml", false);
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        rotatingSlots = y.getInt("rotating-slots", 3);
        ConfigurationSection s = y.getConfigurationSection("items");
        if (s == null) return;
        for (String key : s.getKeys(false)) {
            try {
                ConfigurationSection e = s.getConfigurationSection(key);
                ItemStack st = plugin.loot().resolve(e.getString("item", ""), e.getInt("amount", 1));
                if (st == null) continue;
                long until = 0;
                String u = e.getString("until", "");
                if (!u.isBlank()) until = LocalDate.parse(u).plusDays(1).atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli();
                items.put(key, new Item(key, e.getString("display", key), Math.max(1, e.getLong("price", 1)),
                        st.serializeAsBytes(), st.getType(), e.getInt("daily-limit", 0), e.getBoolean("rotating", false), until));
            } catch (Exception ex) { plugin.getLogger().log(Level.WARNING, "Bad shop item '" + key + "'", ex); }
        }
        plugin.getLogger().info("Shop: " + items.size() + " item(s).");
    }

    public static String today() { return LocalDate.now(ZoneOffset.UTC).toString(); }

    /** Fixed items plus today's rotating picks (deterministic per UTC day). */
    public List<Item> available() {
        long now = System.currentTimeMillis();
        List<Item> fixed = new ArrayList<>(), rot = new ArrayList<>();
        for (Item i : items.values()) {
            if (i.untilMs() > 0 && now > i.untilMs()) continue;
            (i.rotating() ? rot : fixed).add(i);
        }
        Collections.shuffle(rot, new Random(today().hashCode()));
        fixed.addAll(rot.subList(0, Math.min(rotatingSlots, rot.size())));
        return fixed;
    }

    public void buy(Player p, String key, Runnable after) {
        Item it = available().stream().filter(i -> i.key().equals(key)).findFirst().orElse(null);
        if (it == null) { Msg.send(p, "<red>That item is no longer available."); if (after != null) after.run(); return; }
        UUID id = p.getUniqueId();
        String day = today();
        plugin.db().tx(c -> {
            if (it.dailyLimit() > 0) {
                int count = 0;
                try (PreparedStatement ps = c.prepareStatement("SELECT count FROM shop_purchases WHERE uuid=? AND item_key=? AND day=?")) {
                    ps.setString(1, id.toString()); ps.setString(2, key); ps.setString(3, day);
                    try (ResultSet rs = ps.executeQuery()) { if (rs.next()) count = rs.getInt(1); }
                }
                if (count >= it.dailyLimit()) return "LIMIT";
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO shop_purchases(uuid,item_key,day,count) VALUES(?,?,?,1) ON CONFLICT(uuid,item_key,day) DO UPDATE SET count = count + 1")) {
                    ps.setString(1, id.toString()); ps.setString(2, key); ps.setString(3, day); ps.executeUpdate();
                }
            }
            if (!CurrencyService.debit(c, id, it.price(), "shop:" + key)) return "FUNDS";
            InboxService.insert(c, id, it.data(), "shop:" + key);
            return "OK";
        }).whenComplete((res, err) -> plugin.sync(() -> {
            if (err != null) { plugin.getLogger().log(Level.SEVERE, "Shop purchase failed for " + id, err); Msg.send(p, "<red>Purchase failed. Nothing was charged."); }
            else switch (res) {
                case "OK" -> { Msg.send(p, "<green>Purchased <white>" + it.display() + "</white> for " + it.price() + " " + plugin.currencyName() + "."); plugin.inbox().deliverAll(p); }
                case "FUNDS" -> Msg.send(p, "<red>Not enough " + plugin.currencyName() + ".");
                default -> Msg.send(p, "<red>Daily purchase limit reached for this item.");
            }
            if (after != null) after.run();
        }));
    }
}
