package net.des.vyrnth.command;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.dungeon.Difficulty;
import net.des.vyrnth.dungeon.DungeonDefinition;
import net.des.vyrnth.dungeon.VoidGenerator;
import net.des.vyrnth.hub.PortalService;
import net.des.vyrnth.instance.Instance;
import net.des.vyrnth.util.Cuboid;
import net.des.vyrnth.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.*;

/** Every sub-command re-checks isAdmin(); tab completion is hidden from non-OPs too. */
public final class VyrnthCommand implements TabExecutor {
    private final VyrnthPlugin plugin;
    private final Map<UUID, Location> pos1 = new HashMap<>(), pos2 = new HashMap<>();

    public VyrnthCommand(VyrnthPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!VyrnthPlugin.isAdmin(s)) { s.sendMessage("Unknown command."); return true; }
        if (a.length == 0) { help(s); return true; }
        try {
            switch (a[0].toLowerCase()) {
                case "reload" -> { plugin.reloadConfig(); plugin.dungeons().reload(); plugin.portals().reload(); plugin.shop().reload(); plugin.gacha().reload(); plugin.live().reload(); plugin.hubSecrets().reload(); Msg.send(s, "Reloaded config, dungeons, portals, shop and gacha."); }
                case "maintenance" -> {
                    boolean on = a.length > 1 && a[1].equalsIgnoreCase("on");
                    plugin.setMaintenance(on);
                    Msg.send(s, "Maintenance " + (on ? "<red>ON" : "<green>OFF") + "<gray>. Running instances are unaffected.");
                }
                case "dungeon" -> dungeon(s, a);
                case "instances" -> instances(s);
                case "close" -> close(s, a);
                case "currency" -> currency(s, a);
                case "progress" -> progress(s, a);
                case "top" -> top(s, a);
                case "run" -> run(s, a);
                case "boss" -> boss(s, a);
                case "edit" -> edit(s, a);
                case "set" -> set(s, a);
                case "pos1", "pos2" -> pos(s, a[0]);
                case "portal" -> portal(s, a);
                case "room" -> room(s, a);
                case "build" -> build(s, a);
                case "schedule" -> schedule(s, a);
                case "rotation" -> rotation(s, a);
                case "modifier" -> {
                    String v = a.length > 1 ? a[1].toUpperCase() : "AUTO";
                    if (!v.equals("AUTO") && !net.des.vyrnth.live.LiveContentService.MODIFIERS.containsKey(v)) { Msg.send(s, "<red>Options: AUTO, " + String.join(", ", net.des.vyrnth.live.LiveContentService.MODIFIERS.keySet())); break; }
                    plugin.getConfig().set("live.modifier-override", v.equals("AUTO") ? "auto" : v); plugin.saveConfig();
                    Msg.send(s, "Weekly modifier is now " + (v.equals("AUTO") ? "automatic (" + plugin.live().weeklyModifier() + ")" : v) + ". Applies to runs started from now on.");
                }
                case "queue" -> { var snap = plugin.matchmaking().snapshot(); if (snap.isEmpty()) Msg.send(s, "Group finder is empty."); snap.forEach((k, v) -> Msg.send(s, k + ": " + v + " waiting")); }
                case "shop" -> plugin.shop().available().forEach(i -> Msg.send(s, i.key() + " - " + i.display() + " (" + i.price() + ")" + (i.rotating() ? " [rotating]" : "")));
                case "gacha" -> plugin.gacha().pools().forEach(p -> Msg.send(s, p.id() + " - " + p.display() + " entries=" + p.entries().size() + " pity=" + p.pity()));
                case "live" -> {
                    var d = plugin.live().dailyDungeon(); var w = plugin.live().weeklyFeatured();
                    Msg.send(s, "Daily dungeon: " + (d == null ? "none" : d.id) + " | Weekly featured: " + (w == null ? "none" : w.id));
                    plugin.live().activeDaily().forEach(c -> Msg.send(s, "Daily: " + c.id() + " - " + c.display()));
                    plugin.live().activeWeekly().forEach(c -> Msg.send(s, "Weekly: " + c.id() + " - " + c.display()));
                }
                case "debug" -> Msg.send(s, "instances=" + plugin.instances().all().size() + " mythic=" + plugin.mythic().present()
                        + " maintenance=" + plugin.maintenance() + " dungeons=" + plugin.dungeons().all().size());
                default -> help(s);
            }
        } catch (Exception e) {
            Msg.send(s, "<red>Error: " + e.getMessage());
            plugin.getLogger().warning("Admin command failed: " + e);
        }
        return true;
    }

    private void help(CommandSender s) {
        for (String l : List.of(
                "/vyrnth reload | maintenance <on|off> | debug",
                "/vyrnth dungeon list|enable <id>|disable <id>",
                "/vyrnth instances | close <runId|all>",
                "/vyrnth currency balance|give|take <player> [amount]",
                "/vyrnth progress <player> | top <dungeon> <difficulty>",
                "/vyrnth run <dungeon> <difficulty> (OP test run, ignores unlocks)",
                "/vyrnth boss <mythicMobId> (spawn at your feet)",
                "/vyrnth schedule <dungeon> <MON..SUN|always|reset> | rotation daily|weekly <dungeon|auto> | modifier <KEY|auto> | queue | shop | gacha",
                "/vyrnth room list|complete <id>|gate <id> (inside an instance; soft-lock recovery)",
                "/vyrnth build <dungeon|all|hub> (auto-builds the map/hub from the layout) | edit <dungeon> | edit done",
                "/vyrnth set hub|lobby | pos1 | pos2",
                "/vyrnth portal add <id> <LOBBY_TO_HUB|HUB_TO_LOBBY|DUNGEON_GATEWAY|REWARD_STATION|SHOP|GACHA|CHALLENGES|ACHIEVEMENTS|LEADERBOARDS|STATS|TROPHIES|LORE|SEASON|SPECTATE|PRACTICE> [dungeon|poolId] | remove <id> | list")) Msg.send(s, l);
    }

    private void dungeon(CommandSender s, String[] a) {
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
            for (DungeonDefinition d : plugin.dungeons().all())
                Msg.send(s, d.id + " - " + d.display + " " + (plugin.dungeons().isEnabled(d.id) ? "<green>enabled" : "<red>disabled"));
            return;
        }
        if (a.length < 3 || plugin.dungeons().get(a[2]) == null) { Msg.send(s, "<red>Unknown dungeon."); return; }
        plugin.dungeons().setEnabled(a[2], a[1].equalsIgnoreCase("enable"));
        Msg.send(s, a[2] + " is now " + (a[1].equalsIgnoreCase("enable") ? "enabled" : "disabled") + ".");
    }

    private void instances(CommandSender s) {
        if (plugin.instances().all().isEmpty()) { Msg.send(s, "No active instances."); return; }
        for (Instance i : plugin.instances().all())
            Msg.send(s, i.shortId() + " " + i.def.id + " " + i.difficulty + " " + i.state + " players=" + i.members.size()
                    + " deaths=" + i.deaths + " boss=" + i.bossSpawned);
    }

    private void close(CommandSender s, String[] a) {
        if (a.length < 2) { Msg.send(s, "<red>Usage: /vyrnth close <runId|all>"); return; }
        int n = 0;
        for (Instance i : plugin.instances().all())
            if (a[1].equalsIgnoreCase("all") || i.shortId().equalsIgnoreCase(a[1])) { plugin.instances().close(i); n++; }
        Msg.send(s, "Closing " + n + " instance(s).");
    }

    private OfflinePlayer target(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online;
        OfflinePlayer cached = Bukkit.getOfflinePlayerIfCached(name);
        if (cached == null) throw new IllegalArgumentException("Unknown player (must have joined before): " + name);
        return cached;
    }

    private void currency(CommandSender s, String[] a) {
        if (a.length < 3) { Msg.send(s, "<red>Usage: /vyrnth currency balance|give|take <player> [amount]"); return; }
        OfflinePlayer t = target(a[2]);
        UUID id = t.getUniqueId();
        String cur = plugin.currencyName();
        if (a[1].equalsIgnoreCase("balance")) {
            plugin.currency().balance(id).thenAccept(b -> plugin.sync(() -> Msg.send(s, a[2] + ": " + b + " " + cur)));
            return;
        }
        long amt = a.length > 3 ? Long.parseLong(a[3]) : 0;
        if (amt <= 0) { Msg.send(s, "<red>Amount must be positive."); return; }
        if (a[1].equalsIgnoreCase("give")) {
            plugin.currency().grant(id, amt, "admin:" + s.getName()).whenComplete((b, e) -> plugin.sync(() ->
                    Msg.send(s, e == null ? "Gave " + amt + " " + cur + " (balance " + b + ")" : "<red>Failed: " + e.getMessage())));
        } else if (a[1].equalsIgnoreCase("take")) {
            plugin.currency().spend(id, amt, "admin:" + s.getName()).whenComplete((ok, e) -> plugin.sync(() ->
                    Msg.send(s, e != null ? "<red>Failed: " + e.getMessage() : ok ? "Took " + amt + " " + cur : "<red>Player doesn't have that much.")));
        }
    }

    private void progress(CommandSender s, String[] a) {
        if (a.length < 2) { Msg.send(s, "<red>Usage: /vyrnth progress <player>"); return; }
        plugin.progression().summary(target(a[1]).getUniqueId()).thenAccept(lines -> plugin.sync(() -> {
            if (lines.isEmpty()) Msg.send(s, "No records.");
            lines.forEach(l -> Msg.send(s, l));
        }));
    }

    private void top(CommandSender s, String[] a) {
        Difficulty d = a.length > 2 ? Difficulty.parse(a[2]) : null;
        if (a.length < 3 || d == null) { Msg.send(s, "<red>Usage: /vyrnth top <dungeon> <difficulty>"); return; }
        plugin.progression().top(a[1], d, 10).thenAccept(list -> plugin.sync(() -> {
            if (list.isEmpty()) Msg.send(s, "No records yet.");
            int n = 1;
            for (var e : list) Msg.send(s, "#" + n++ + " " + Bukkit.getOfflinePlayer(e.player()).getName() + " " + Msg.fmt(e.bestMs()));
        }));
    }

    private void run(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) { Msg.send(s, "Players only."); return; }
        DungeonDefinition def = a.length > 1 ? plugin.dungeons().get(a[1]) : null;
        Difficulty d = a.length > 2 ? Difficulty.parse(a[2]) : Difficulty.NORMAL;
        if (def == null || d == null) { Msg.send(s, "<red>Usage: /vyrnth run <dungeon> <difficulty>"); return; }
        String err = plugin.instances().start(def, d, List.of(p), true);
        if (err != null) Msg.send(s, "<red>" + err);
    }

    private void boss(CommandSender s, String[] a) throws Exception {
        if (!(s instanceof Player p) || a.length < 2) { Msg.send(s, "<red>Usage (in game): /vyrnth boss <mythicMobId>"); return; }
        Entity e = plugin.mythic().spawn(a[1], p.getLocation());
        Msg.send(s, e == null ? "<red>Spawn failed." : "Spawned " + a[1] + ".");
    }

    private void edit(CommandSender s, String[] a) {
        if (!(s instanceof Player p) || a.length < 2) { Msg.send(s, "<red>Usage (in game): /vyrnth edit <dungeon> | edit done"); return; }
        if (a[1].equalsIgnoreCase("done")) {
            World w = p.getWorld();
            if (!w.getName().startsWith("vyrnth_template_")) { Msg.send(s, "<red>You're not in a template world."); return; }
            w.save();
            for (Player x : w.getPlayers()) x.teleport(plugin.hubSpawn());
            Msg.send(s, Bukkit.unloadWorld(w, true) ? "Template saved and unloaded." : "<red>Could not unload the template world.");
            return;
        }
        DungeonDefinition def = plugin.dungeons().get(a[1]);
        if (def == null) { Msg.send(s, "<red>Unknown dungeon."); return; }
        if (plugin.instances().all().stream().anyMatch(i -> i.def.id.equals(def.id)))
            { Msg.send(s, "<red>Close active instances of this dungeon first."); return; }
        World w = new WorldCreator(def.templateWorld).generator(new VoidGenerator()).generateStructures(false).createWorld();
        if (w == null) { Msg.send(s, "<red>Could not open template world."); return; }
        p.teleport(w.getSpawnLocation().add(0.5, 0, 0.5));
        Msg.send(s, "Editing <white>" + def.templateWorld + "</white>. Run <white>/vyrnth edit done</white> to save. Runs of this dungeon are blocked meanwhile.");
    }

    private void build(CommandSender s, String[] a) {
        if (a.length < 2) { Msg.send(s, "<red>Usage: /vyrnth build <dungeon|all|hub>  (hub builds around you)"); return; }
        var mb = plugin.mapBuilder();
        if (a[1].equalsIgnoreCase("hub")) {
            if (!(s instanceof Player p)) { Msg.send(s, "Players only."); return; }
            String err = mb.buildHub(s, p.getLocation().getBlock().getLocation().add(0, 0, 0), null);
            if (err != null) Msg.send(s, "<red>" + err);
            return;
        }
        if (a[1].equalsIgnoreCase("all")) {
            Deque<net.des.vyrnth.dungeon.DungeonDefinition> todo = new ArrayDeque<>(plugin.dungeons().all());
            buildNext(s, todo);
            return;
        }
        var def = plugin.dungeons().get(a[1]);
        if (def == null) { Msg.send(s, "<red>Unknown dungeon."); return; }
        String err = mb.build(s, def, null);
        if (err != null) Msg.send(s, "<red>" + err);
    }

    private void buildNext(CommandSender s, Deque<net.des.vyrnth.dungeon.DungeonDefinition> todo) {
        if (todo.isEmpty()) { Msg.send(s, "<green>All dungeon maps built."); return; }
        var def = todo.poll();
        String err = plugin.mapBuilder().build(s, def, () -> buildNext(s, todo));
        if (err != null) { Msg.send(s, "<red>" + def.id + ": " + err); buildNext(s, todo); }
    }

    private void schedule(CommandSender s, String[] a) {
        if (a.length < 3 || plugin.dungeons().get(a[1]) == null) { Msg.send(s, "<red>Usage: /vyrnth schedule <dungeon> <MON TUE ...|always|reset>"); return; }
        String path = "schedule-override." + a[1];
        if (a[2].equalsIgnoreCase("reset")) plugin.getConfig().set(path, null);
        else {
            List<String> days = new ArrayList<>();
            for (int k = 2; k < a.length; k++) {
                String d = a[k].toUpperCase();
                if (d.length() == 3) for (java.time.DayOfWeek w : java.time.DayOfWeek.values()) if (w.name().startsWith(d)) d = w.name();
                if (!d.equals("ALWAYS") && !isDay(d)) { Msg.send(s, "<red>Unknown day: " + a[k]); return; }
                days.add(d);
            }
            plugin.getConfig().set(path, days);
        }
        plugin.saveConfig();
        Msg.send(s, a[1] + " open days: " + plugin.openDays(plugin.dungeons().get(a[1])) + (plugin.openDays(plugin.dungeons().get(a[1])).isEmpty() ? "always" : ""));
    }

    private static boolean isDay(String d) {
        for (java.time.DayOfWeek w : java.time.DayOfWeek.values()) if (w.name().equals(d)) return true;
        return false;
    }

    private void rotation(CommandSender s, String[] a) {
        if (a.length < 3 || !(a[1].equalsIgnoreCase("daily") || a[1].equalsIgnoreCase("weekly"))) { Msg.send(s, "<red>Usage: /vyrnth rotation daily|weekly <dungeon|auto>"); return; }
        if (!a[2].equalsIgnoreCase("auto") && plugin.dungeons().get(a[2]) == null) { Msg.send(s, "<red>Unknown dungeon."); return; }
        plugin.getConfig().set("live." + a[1].toLowerCase() + "-override", a[2].toLowerCase());
        plugin.saveConfig();
        Msg.send(s, a[1] + " rotation set to " + a[2] + ".");
    }

    private void room(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) { Msg.send(s, "Players only."); return; }
        Instance i = plugin.instances().ofWorld(p.getWorld());
        if (i == null) { Msg.send(s, "<red>Stand inside an active instance first."); return; }
        String sub = a.length > 1 ? a[1].toLowerCase() : "list";
        switch (sub) {
            case "complete" -> Msg.send(s, a.length > 2 && plugin.instances().rooms().forceComplete(i, a[2]) ? "Room completed." : "<red>Unknown room.");
            case "gate" -> { if (a.length > 2) plugin.instances().rooms().openGate(i, a[2]); Msg.send(s, "Gate opened (if it exists)."); }
            default -> {
                for (var r : i.def.layout.rooms) {
                    var st = i.rooms.get(r.id());
                    Msg.send(s, r.id() + " " + r.type() + " " + (st == null ? "idle" : st.complete ? "<green>complete" : st.active ? "<yellow>active (" + st.required.size() + " required left)" : "idle"));
                }
            }
        }
    }

    private void set(CommandSender s, String[] a) {
        if (!(s instanceof Player p) || a.length < 2) { Msg.send(s, "<red>Usage (in game): /vyrnth set hub|lobby"); return; }
        if (a[1].equalsIgnoreCase("hub")) plugin.writeLocation("hub.spawn", p.getLocation());
        else if (a[1].equalsIgnoreCase("lobby")) plugin.writeLocation("lobby.spawn", p.getLocation());
        else { Msg.send(s, "<red>hub or lobby."); return; }
        Msg.send(s, a[1] + " spawn saved.");
    }

    private void pos(CommandSender s, String which) {
        if (!(s instanceof Player p)) return;
        (which.equals("pos1") ? pos1 : pos2).put(p.getUniqueId(), p.getLocation().getBlock().getLocation());
        Msg.send(s, which + " set.");
    }

    private void portal(CommandSender s, String[] a) {
        if (a.length < 2) { Msg.send(s, "<red>Usage: /vyrnth portal add|remove|list"); return; }
        switch (a[1].toLowerCase()) {
            case "list" -> { for (var p : plugin.portals().all()) Msg.send(s, p.id() + " " + p.type() + " in " + p.world() + " " + p.dungeon()); }
            case "remove" -> Msg.send(s, a.length > 2 && plugin.portals().remove(a[2]) ? "Removed." : "<red>No such portal.");
            case "add" -> {
                if (!(s instanceof Player p) || a.length < 4) { Msg.send(s, "<red>Usage (in game): /vyrnth portal add <id> <TYPE> [dungeon]"); return; }
                Location l1 = pos1.get(p.getUniqueId()), l2 = pos2.get(p.getUniqueId());
                if (l1 == null || l2 == null || !l1.getWorld().equals(l2.getWorld())) { Msg.send(s, "<red>Set /vyrnth pos1 and pos2 in the same world first."); return; }
                PortalService.Type t = PortalService.Type.valueOf(a[3].toUpperCase());
                String dungeon = a.length > 4 ? a[4] : "";
                if (t == PortalService.Type.DUNGEON_GATEWAY && plugin.dungeons().get(dungeon) == null) { Msg.send(s, "<red>DUNGEON_GATEWAY needs a valid dungeon id."); return; }
                plugin.portals().add(new PortalService.Portal(a[2], t, l1.getWorld().getName(),
                        Cuboid.of(l1.getX(), l1.getY(), l1.getZ(), l2.getX(), l2.getY(), l2.getZ()), dungeon));
                Msg.send(s, "Portal <white>" + a[2] + "</white> created.");
            }
            default -> Msg.send(s, "<red>Usage: /vyrnth portal add|remove|list");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (!VyrnthPlugin.isAdmin(s)) return List.of();
        if (a.length == 1) return List.of("reload", "maintenance", "dungeon", "instances", "close", "currency", "progress", "top",
                "run", "boss", "edit", "set", "pos1", "pos2", "portal", "live", "room", "build", "schedule", "rotation", "modifier", "queue", "shop", "gacha", "debug");
        if (a.length == 2 && (a[0].equalsIgnoreCase("run") || a[0].equalsIgnoreCase("edit") || a[0].equalsIgnoreCase("top")))
            return plugin.dungeons().all().stream().map(d -> d.id).toList();
        return null;
    }
}
