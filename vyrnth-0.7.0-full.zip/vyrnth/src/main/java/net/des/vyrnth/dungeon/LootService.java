package net.des.vyrnth.dungeon;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.dungeon.DungeonDefinition.LootEntry;
import net.des.vyrnth.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/** Personal loot: every participant rolls independently. Items are resolved from MATERIAL:X or MYTHIC:id. */
public final class LootService {
    private final VyrnthPlugin plugin;
    private final Random rng = new Random();

    public LootService(VyrnthPlugin plugin) { this.plugin = plugin; }

    public List<ItemStack> roll(DungeonDefinition def, Difficulty diff, String playerName) {
        List<ItemStack> out = new ArrayList<>();
        for (LootEntry e : def.guaranteed) if (eligible(e, diff)) add(out, e, playerName, false);
        List<LootEntry> pool = def.loot.stream().filter(e -> eligible(e, diff)).toList();
        if (pool.isEmpty()) return out;
        double total = pool.stream().mapToDouble(LootEntry::weight).sum();
        int rolls = def.rolls + plugin.bonusRolls(diff);
        for (int r = 0; r < rolls; r++) {
            double x = rng.nextDouble() * total;
            for (LootEntry e : pool) {
                x -= e.weight();
                if (x <= 0) { add(out, e, playerName, true); break; }
            }
        }
        return out;
    }

    private boolean eligible(LootEntry e, Difficulty d) { return d.ordinal() >= e.minDifficulty().ordinal(); }

    private void add(List<ItemStack> out, LootEntry e, String player, boolean announceAllowed) {
        int amt = e.min() + (e.max() > e.min() ? rng.nextInt(e.max() - e.min() + 1) : 0);
        ItemStack it = resolve(e.id(), amt);
        if (it == null) return;
        out.add(it);
        if (announceAllowed && e.announce() && plugin.getConfig().getBoolean("announce-rare-drops", true)) {
            Bukkit.broadcast(Msg.c("<#2DD4BF><bold>VYRNTH</bold> <dark_gray>»</dark_gray> <gold>" + player
                    + "</gold> <gray>found a rare drop: </gray><light_purple>" + e.id().replaceAll("^[A-Za-z]+:", "")));
        }
    }

    public ItemStack resolve(String id, int amount) {
        int idx = id.indexOf(':');
        String kind = idx < 0 ? "MATERIAL" : id.substring(0, idx).toUpperCase(Locale.ROOT);
        String key = idx < 0 ? id : id.substring(idx + 1);
        if (kind.equals("MYTHIC")) {
            ItemStack it = plugin.mythic().item(key);
            if (it == null) { plugin.getLogger().warning("Unknown MythicMobs item in loot table: " + key); return null; }
            it = it.clone();
            it.setAmount(Math.max(1, Math.min(amount, it.getMaxStackSize())));
            return it;
        }
        Material m = Material.matchMaterial(key);
        if (m == null || !m.isItem()) { plugin.getLogger().warning("Unknown material in loot table: " + key); return null; }
        return new ItemStack(m, Math.max(1, Math.min(amount, m.getMaxStackSize())));
    }
}
