package net.des.vyrnth.hub;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public final class Menu implements InventoryHolder {
    private final Inventory inv;
    private final Map<Integer, Consumer<Player>> actions = new HashMap<>();

    public Menu(Component title, int rows) { inv = Bukkit.createInventory(this, rows * 9, title); }

    public Menu set(int slot, ItemStack item, Consumer<Player> action) {
        inv.setItem(slot, item);
        if (action != null) actions.put(slot, action);
        return this;
    }

    public void open(Player p) { p.openInventory(inv); }
    public void click(Player p, int slot) { Consumer<Player> a = actions.get(slot); if (a != null) a.accept(p); }
    @Override public Inventory getInventory() { return inv; }
}
