package net.des.vyrnth.data;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.util.Msg;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/**
 * Reward inbox. Loot is always committed here first (in the same transaction as the clear record),
 * then moved to the player's inventory. Claim = delete-row-then-give; overflow goes back into the inbox.
 */
public final class InboxService {
    public record Entry(long id, byte[] data, String source) {}

    private final VyrnthPlugin plugin;
    private final Database db;

    public InboxService(VyrnthPlugin plugin, Database db) { this.plugin = plugin; this.db = db; }

    /** In-transaction insert so purchases/draws and their items commit together. */
    public static void insert(java.sql.Connection c, UUID id, byte[] data, String source) throws java.sql.SQLException {
        try (PreparedStatement ps = c.prepareStatement("INSERT INTO inbox(uuid, item, source, ts) VALUES(?,?,?,?)")) {
            ps.setString(1, id.toString()); ps.setBytes(2, data); ps.setString(3, source); ps.setLong(4, System.currentTimeMillis());
            ps.executeUpdate();
        }
    }

    public CompletableFuture<List<Entry>> list(UUID id) {
        return db.submit(c -> {
            List<Entry> out = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement("SELECT id, item, source FROM inbox WHERE uuid=? ORDER BY id LIMIT 45")) {
                ps.setString(1, id.toString());
                try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(new Entry(rs.getLong(1), rs.getBytes(2), rs.getString(3))); }
            }
            return out;
        });
    }

    public CompletableFuture<Void> add(UUID id, ItemStack item, String source) {
        byte[] data = item.serializeAsBytes();
        return db.tx(c -> {
            try (PreparedStatement ps = c.prepareStatement("INSERT INTO inbox(uuid, item, source, ts) VALUES(?,?,?,?)")) {
                ps.setString(1, id.toString()); ps.setBytes(2, data); ps.setString(3, source); ps.setLong(4, System.currentTimeMillis());
                ps.executeUpdate();
            }
            return null;
        });
    }

    private CompletableFuture<byte[]> claim(UUID id, long rowId) {
        return db.tx(c -> {
            byte[] data = null;
            try (PreparedStatement ps = c.prepareStatement("SELECT item FROM inbox WHERE id=? AND uuid=?")) {
                ps.setLong(1, rowId); ps.setString(2, id.toString());
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) data = rs.getBytes(1); }
            }
            if (data == null) return null;
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM inbox WHERE id=? AND uuid=?")) {
                ps.setLong(1, rowId); ps.setString(2, id.toString());
                if (ps.executeUpdate() != 1) return null;   // someone else claimed it first: no dupes
            }
            return data;
        });
    }

    public void claimAndGive(Player p, long rowId, Runnable after) {
        UUID id = p.getUniqueId();
        claim(id, rowId).whenComplete((data, err) -> plugin.sync(() -> {
            if (err != null) { plugin.getLogger().log(Level.SEVERE, "Inbox claim failed for " + id, err); return; }
            if (data != null) {
                ItemStack it = ItemStack.deserializeBytes(data);
                if (!p.isOnline()) add(id, it, "returned");
                else {
                    Map<Integer, ItemStack> left = p.getInventory().addItem(it);
                    for (ItemStack l : left.values()) add(id, l, "overflow");
                    if (!left.isEmpty()) Msg.send(p, "<red>Inventory full — the rest is waiting at the Reward Collection Station.");
                }
            }
            if (after != null) after.run();
        }));
    }

    public void deliverAll(Player p) {
        list(p.getUniqueId()).thenAccept(es -> plugin.sync(() -> { for (Entry e : es) claimAndGive(p, e.id(), null); }));
    }
}
