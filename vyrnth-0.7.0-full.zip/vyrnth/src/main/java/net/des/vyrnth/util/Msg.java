package net.des.vyrnth.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.time.Duration;

public final class Msg {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private Msg() {}

    public static Component c(String mini) { return MM.deserialize(mini); }

    public static void send(CommandSender to, String mini) {
        to.sendMessage(c("<#2DD4BF><bold>VYRNTH</bold> <dark_gray>»</dark_gray> <gray>" + mini));
    }

    public static void title(Player p, String title, String sub) {
        p.showTitle(Title.title(c(title), c(sub),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(800))));
    }

    public static String fmt(long ms) {
        long s = ms / 1000;
        return String.format("%d:%02d", s / 60, s % 60);
    }
}
