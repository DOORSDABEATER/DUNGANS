package net.des.vyrnth.hub;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.dungeon.Difficulty;
import net.des.vyrnth.dungeon.DungeonDefinition;
import net.des.vyrnth.party.PartyManager.Party;
import net.des.vyrnth.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/** The only path from hub to dungeon: physical gateway -> menu -> (ready check) -> InstanceManager.start. */
public final class EntryService {
    private static final class Check {
        final DungeonDefinition def; final Difficulty diff; final Set<UUID> members; final Set<UUID> ready = new HashSet<>();
        BukkitTask timeout; boolean done;
        Check(DungeonDefinition def, Difficulty diff, Set<UUID> members) { this.def = def; this.diff = diff; this.members = members; }
    }

    private final VyrnthPlugin plugin;
    private final Map<UUID, Check> byMember = new HashMap<>();

    public EntryService(VyrnthPlugin plugin) { this.plugin = plugin; }

    public void request(Player leader, DungeonDefinition def, Difficulty diff) {
        UUID id = leader.getUniqueId();
        if (plugin.instances().of(id) != null) { Msg.send(leader, "<red>You're already in an expedition."); return; }
        Party party = plugin.parties().of(id);
        if (party != null && !party.leader.equals(id)) { Msg.send(leader, "<red>Only the party leader can launch."); return; }
        if (byMember.containsKey(id)) { Msg.send(leader, "<red>A ready check is already running."); return; }
        Collection<UUID> ids = party == null ? List.of(id) : new ArrayList<>(party.members);
        List<Player> players = new ArrayList<>();
        var hubWorld = plugin.hubSpawn().getWorld();
        for (UUID m : ids) {
            Player p = Bukkit.getPlayer(m);
            if (p == null) { Msg.send(leader, "<red>A party member is offline."); return; }
            if (!p.getWorld().equals(hubWorld)) { Msg.send(leader, "<red>" + p.getName() + " must be in the hub."); return; }
            players.add(p);
        }
        if (players.size() == 1) {
            String err = plugin.instances().start(def, diff, players, false);
            if (err != null) Msg.send(leader, "<red>" + err);
            return;
        }
        Check c = new Check(def, diff, new HashSet<>(ids));
        c.ready.add(id);
        for (UUID m : ids) byMember.put(m, c);
        c.timeout = Bukkit.getScheduler().runTaskLater(plugin, () -> cancel(c, "Ready check timed out."), 20L * 30);
        for (Player p : players) {
            if (p.getUniqueId().equals(id)) continue;
            Msg.send(p, "<white>" + leader.getName() + "</white> wants to launch <white>" + def.display + "</white> ("
                    + diff.color + diff.display + "<gray>). <green><click:run_command:'/party ready'>[READY]</click></green> "
                    + "<red><click:run_command:'/party notready'>[DECLINE]</click></red>");
            plugin.menus().openReady(p, def, diff);
        }
        Msg.send(leader, "Ready check sent to your party (30s).");
    }

    public void respond(Player p, boolean ready) {
        Check c = byMember.get(p.getUniqueId());
        if (c == null || c.done) { Msg.send(p, "<red>No ready check is running."); return; }
        if (!ready) { cancel(c, p.getName() + " declined."); return; }
        c.ready.add(p.getUniqueId());
        if (c.ready.containsAll(c.members)) launch(c);
        else Msg.send(p, "You are ready. Waiting for the others...");
    }

    private void launch(Check c) {
        finish(c);
        List<Player> players = new ArrayList<>();
        for (UUID m : c.members) {
            Player p = Bukkit.getPlayer(m);
            if (p == null) { notify(c, "A party member went offline."); return; }
            players.add(p);
        }
        String err = plugin.instances().start(c.def, c.diff, players, false);
        if (err != null) notify(c, "<red>" + err);
    }

    private void cancel(Check c, String why) {
        if (c.done) return;
        finish(c);
        notify(c, "<red>Launch cancelled: " + why);
    }

    private void finish(Check c) {
        c.done = true;
        if (c.timeout != null) c.timeout.cancel();
        for (UUID m : c.members) byMember.remove(m);
    }

    private void notify(Check c, String msg) {
        for (UUID m : c.members) { Player p = Bukkit.getPlayer(m); if (p != null) Msg.send(p, msg); }
    }

    public void onQuit(UUID id) {
        Check c = byMember.get(id);
        if (c != null) cancel(c, "a party member disconnected.");
    }
}
