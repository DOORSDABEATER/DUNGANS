package net.des.vyrnth.dungeon;

import org.bukkit.generator.ChunkGenerator;

/** Generates nothing: instance/template worlds are void outside the built map. */
public final class VoidGenerator extends ChunkGenerator {
}
