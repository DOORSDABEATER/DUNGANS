package net.des.vyrnth.party;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;

public final class PartyManager {
    public static final class Party {
        public UUID leader;
        public final LinkedHashSet<UUID> members = new LinkedHashSet<>();
    }
    private record Invite(UUID leader, long expiresMs) {}

    private final VyrnthPlugin plugin;
    private final Map<UUID, Party> byMember = new HashMap<>();
    private final Map<UUID, Invite> invites = new HashMap<>();

    public PartyManager(VyrnthPlugin plugin) { this.plugin = plugin; }

    public Party of(UUID id) { return byMember.get(id); }

    /** @return error message or null */
    public String invite(Player from, Player to) {
        if (from.equals(to)) return "You can't invite yourself.";
        if (plugin.instances().of(from.getUniqueId()) != null) return "You can't manage parties during an expedition.";
        if (byMember.containsKey(to.getUniqueId())) return to.getName() + " is already in a party.";
        Party p = byMember.get(from.getUniqueId());
        if (p != null && !p.leader.equals(from.getUniqueId())) return "Only the party leader can invite.";
        int max = plugin.getConfig().getInt("party.max-size", 4);
        if (p != null && p.members.size() >= max) return "Your party is full (" + max + ").";
        if (p == null) {
            p = new Party();
            p.leader = from.getUniqueId();
            p.members.add(from.getUniqueId());
            byMember.put(from.getUniqueId(), p);
        }
        invites.put(to.getUniqueId(), new Invite(p.leader, System.currentTimeMillis() + 60_000));
        Msg.send(to, "<white>" + from.getName() + "</white> invited you to a party. "
                + "<green><click:run_command:'/party accept " + from.getName() + "'>[Accept]</click></green> "
                + "<red><click:run_command:'/party decline'>[Decline]</click></red> <dark_gray>(60s)");
        Msg.send(from, "Invited <white>" + to.getName() + "</white>.");
        return null;
    }

    public String accept(Player p, String leaderName) {
        Invite inv = invites.remove(p.getUniqueId());
        if (inv == null || inv.expiresMs() < System.currentTimeMillis()) return "You have no pending invite.";
        Player leader = Bukkit.getPlayer(inv.leader());
        if (leader == null || !leader.getName().equalsIgnoreCase(leaderName)) return "That invite is no longer valid.";
        Party party = byMember.get(inv.leader());
        if (party == null) return "That party no longer exists.";
        if (party.members.size() >= plugin.getConfig().getInt("party.max-size", 4)) return "That party is full.";
        if (byMember.containsKey(p.getUniqueId())) return "Leave your current party first.";
        party.members.add(p.getUniqueId());
        byMember.put(p.getUniqueId(), party);
        broadcast(party, "<white>" + p.getName() + "</white> joined the party.");
        return null;
    }

    public void decline(Player p) {
        if (invites.remove(p.getUniqueId()) != null) Msg.send(p, "Invite declined.");
    }

    public String leave(Player p) {
        if (plugin.instances().of(p.getUniqueId()) != null) return "Use the Exit Beacon to abandon an expedition.";
        if (!byMember.containsKey(p.getUniqueId())) return "You are not in a party.";
        remove(p.getUniqueId(), p.getName() + " left the party.");
        return null;
    }

    public String kick(Player leader, String name) {
        Party party = byMember.get(leader.getUniqueId());
        if (party == null || !party.leader.equals(leader.getUniqueId())) return "Only the party leader can kick.";
        if (plugin.instances().of(leader.getUniqueId()) != null) return "Not during an expedition.";
        Player t = Bukkit.getPlayerExact(name);
        if (t == null || !party.members.contains(t.getUniqueId()) || t.equals(leader)) return "No such party member.";
        Msg.send(t, "<red>You were removed from the party.");
        remove(t.getUniqueId(), t.getName() + " was removed from the party.");
        return null;
    }

    public String promote(Player leader, String name) {
        Party party = byMember.get(leader.getUniqueId());
        if (party == null || !party.leader.equals(leader.getUniqueId())) return "Only the party leader can promote.";
        Player t = Bukkit.getPlayerExact(name);
        if (t == null || !party.members.contains(t.getUniqueId())) return "No such party member.";
        party.leader = t.getUniqueId();
        broadcast(party, "<white>" + t.getName() + "</white> is now the party leader.");
        return null;
    }

    public List<String> describe(Player p) {
        Party party = byMember.get(p.getUniqueId());
        if (party == null) return List.of("You are not in a party.");
        List<String> out = new ArrayList<>();
        for (UUID id : party.members) {
            String n = String.valueOf(Bukkit.getOfflinePlayer(id).getName());
            out.add((id.equals(party.leader) ? "★ " : "• ") + n + (Bukkit.getPlayer(id) == null ? " (offline)" : ""));
        }
        return out;
    }

    /** Called on disconnect. Mid-run members stay in the party (the instance owns their reconnect grace). */
    public void onQuit(UUID id) {
        invites.remove(id);
        Party party = byMember.get(id);
        if (party == null) return;
        if (plugin.instances().of(id) != null) {
            if (party.leader.equals(id)) promoteNextOnline(party, id);
            return;
        }
        Player p = Bukkit.getPlayer(id);
        remove(id, (p != null ? p.getName() : "A member") + " disconnected and left the party.");
    }

    private void promoteNextOnline(Party party, UUID except) {
        for (UUID m : party.members) {
            if (!m.equals(except) && Bukkit.getPlayer(m) != null) {
                party.leader = m;
                broadcast(party, "<white>" + Bukkit.getPlayer(m).getName() + "</white> is now the party leader.");
                return;
            }
        }
    }

    private void remove(UUID id, String message) {
        Party party = byMember.remove(id);
        if (party == null) return;
        party.members.remove(id);
        if (party.members.size() <= 1) {
            for (UUID m : party.members) {
                byMember.remove(m);
                Player p = Bukkit.getPlayer(m);
                if (p != null) Msg.send(p, message + " Party disbanded.");
            }
            party.members.clear();
            return;
        }
        if (party.leader.equals(id)) promoteNextOnline(party, id);
        if (!party.members.contains(party.leader)) party.leader = party.members.iterator().next();
        broadcast(party, message);
    }

    /** Drop a member from the party without messages (used when an expedition forfeits them). */
    public void silentRemove(UUID id) {
        Party party = byMember.get(id);
        if (party != null) remove(id, "A member left the party.");
    }

    private void broadcast(Party party, String msg) {
        for (UUID m : party.members) { Player p = Bukkit.getPlayer(m); if (p != null) Msg.send(p, msg); }
    }
}
