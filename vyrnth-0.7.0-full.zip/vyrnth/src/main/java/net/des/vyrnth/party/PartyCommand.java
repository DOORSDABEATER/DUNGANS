package net.des.vyrnth.party;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;

/** Party management only. Nothing here can teleport anyone into a dungeon. */
public final class PartyCommand implements TabExecutor {
    private final VyrnthPlugin plugin;

    public PartyCommand(VyrnthPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
        PartyManager pm = plugin.parties();
        String sub = a.length == 0 ? "list" : a[0].toLowerCase();
        String err = null;
        switch (sub) {
            case "invite" -> {
                Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : null;
                err = t == null ? "Usage: /party invite <player> (player must be online)" : pm.invite(p, t);
            }
            case "accept" -> err = pm.accept(p, a.length > 1 ? a[1] : "");
            case "decline" -> pm.decline(p);
            case "leave" -> { err = pm.leave(p); if (err == null) Msg.send(p, "You left the party."); }
            case "kick" -> err = a.length > 1 ? pm.kick(p, a[1]) : "Usage: /party kick <player>";
            case "promote" -> err = a.length > 1 ? pm.promote(p, a[1]) : "Usage: /party promote <player>";
            case "ready" -> plugin.entry().respond(p, true);     // confirms a ready check started at a hub gateway
            case "notready" -> plugin.entry().respond(p, false);
            default -> pm.describe(p).forEach(l -> Msg.send(p, l));
        }
        if (err != null) Msg.send(p, "<red>" + err);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) return List.of("invite", "accept", "decline", "leave", "kick", "promote", "list", "ready", "notready");
        return null; // default player-name completion
    }
}
