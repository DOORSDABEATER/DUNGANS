package net.des.vyrnth.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/** Server-authoritative currency. Balances can never go negative (CHECK constraint + guarded UPDATE). */
public final class CurrencyService {
    private static final long MAX_TX = 1_000_000_000L;
    private final Database db;

    public CurrencyService(Database db) { this.db = db; }

    public CompletableFuture<Long> balance(UUID id) { return db.submit(c -> read(c, id)); }

    public CompletableFuture<Long> grant(UUID id, long amount, String reason) {
        if (amount <= 0 || amount > MAX_TX) return CompletableFuture.failedFuture(new IllegalArgumentException("bad amount"));
        return db.tx(c -> { add(c, id, amount, reason); return read(c, id); });
    }

    /** @return true if the balance covered the cost and was debited atomically. */
    public CompletableFuture<Boolean> spend(UUID id, long amount, String reason) {
        if (amount <= 0 || amount > MAX_TX) return CompletableFuture.failedFuture(new IllegalArgumentException("bad amount"));
        return db.tx(c -> {
            try (PreparedStatement ps = c.prepareStatement("UPDATE balances SET balance = balance - ? WHERE uuid = ? AND balance >= ?")) {
                ps.setLong(1, amount); ps.setString(2, id.toString()); ps.setLong(3, amount);
                if (ps.executeUpdate() != 1) return false;
            }
            ledger(c, id, -amount, reason);
            return true;
        });
    }

    /** Use inside an existing transaction so currency + rewards commit together. */
    public static void add(Connection c, UUID id, long amount, String reason) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO balances(uuid, balance) VALUES(?, ?) ON CONFLICT(uuid) DO UPDATE SET balance = balance + excluded.balance")) {
            ps.setString(1, id.toString()); ps.setLong(2, amount); ps.executeUpdate();
        }
        ledger(c, id, amount, reason);
    }

    /** In-transaction debit: false (and nothing written) if the balance can't cover it. */
    public static boolean debit(Connection c, UUID id, long amount, String reason) throws SQLException {
        if (amount <= 0 || amount > MAX_TX) return false;
        try (PreparedStatement ps = c.prepareStatement("UPDATE balances SET balance = balance - ? WHERE uuid = ? AND balance >= ?")) {
            ps.setLong(1, amount); ps.setString(2, id.toString()); ps.setLong(3, amount);
            if (ps.executeUpdate() != 1) return false;
        }
        ledger(c, id, -amount, reason);
        return true;
    }

    private static void ledger(Connection c, UUID id, long delta, String reason) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("INSERT INTO ledger(uuid, delta, reason, ts) VALUES(?,?,?,?)")) {
            ps.setString(1, id.toString()); ps.setLong(2, delta); ps.setString(3, reason); ps.setLong(4, System.currentTimeMillis());
            ps.executeUpdate();
        }
    }

    private static long read(Connection c, UUID id) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT balance FROM balances WHERE uuid = ?")) {
            ps.setString(1, id.toString());
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getLong(1) : 0L; }
        }
    }
}
