package net.des.vyrnth.instance;

import java.util.*;

public final class RoomState {
    public boolean active, complete, spawned, warned;
    public final Set<UUID> required = new HashSet<>();   // must die to finish a CLEAR_SPAWNS / current WAVES wave
    public final Set<UUID> all = new HashSet<>();        // everything this room spawned (cleaned up on completion)
    public final Map<String, Long> activated = new HashMap<>();
    public long windowStart, startMs, seqStart;
    public int[] jstate;     // ROUTING junction states
    public int wave, seq;    // WAVES current wave; SEQUENCE progress
}
