package net.des.vyrnth.dungeon;

import net.des.vyrnth.util.Cuboid;
import net.des.vyrnth.util.Pos;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;

public final class DungeonDefinition {
    public record Checkpoint(Cuboid region, Pos spawn) {}
    public record LootEntry(String id, int min, int max, double weight, Difficulty minDifficulty, boolean announce) {}

    public final String id, display, templateWorld, requires;
    public final int minPlayers, maxPlayers, timeLimitMin;
    public final long timeOfDay, baseCurrency, firstClearBonus;
    public final int rolls;
    public final Pos spawn, bossSpawn;
    public final Cuboid bossTrigger;
    public final Layout layout;
    public final boolean raid;
    public final String bossName, music, bossMusic;
    public final int musicSeconds;
    public final List<String> days;          // UTC day names the dungeon is open (empty = always)
    public final List<Integer> bossPhases;   // boss health % thresholds that start phase 2, 3, ...
    public final Map<Difficulty, String> bossMobs = new EnumMap<>(Difficulty.class);
    public final List<Checkpoint> checkpoints = new ArrayList<>();
    public final List<LootEntry> loot = new ArrayList<>(), guaranteed = new ArrayList<>();

    private DungeonDefinition(String id, ConfigurationSection s) {
        this.id = id;
        display = s.getString("display", id);
        templateWorld = s.getString("template-world", "vyrnth_template_" + id);
        requires = s.getString("requires", "");
        minPlayers = s.getInt("party.min", 1);
        maxPlayers = s.getInt("party.max", 4);
        timeLimitMin = s.getInt("time-limit-minutes", 45);
        timeOfDay = s.getLong("time-of-day", 18000);
        spawn = Pos.read(s.getConfigurationSection("spawn"));
        bossSpawn = Pos.read(s.getConfigurationSection("boss.spawn"));
        bossTrigger = Cuboid.read(Objects.requireNonNull(s.getConfigurationSection("boss.trigger"), "boss.trigger"));

        ConfigurationSection bm = s.getConfigurationSection("boss.mobs");
        String last = null;
        for (Difficulty d : Difficulty.values()) {   // missing tiers fall back to the previous tier's boss
            String v = bm == null ? null : bm.getString(d.name());
            if (v != null) last = v;
            if (last == null) throw new IllegalArgumentException("boss.mobs.NORMAL is required");
            bossMobs.put(d, last);
        }

        ConfigurationSection cps = s.getConfigurationSection("checkpoints");
        if (cps != null) for (String k : cps.getKeys(false)) {
            ConfigurationSection c = cps.getConfigurationSection(k);
            checkpoints.add(new Checkpoint(Cuboid.read(c), Pos.read(c.getConfigurationSection("spawn"))));
        }

        layout = Layout.read(s);
        raid = s.getBoolean("raid", false);
        bossName = s.getString("boss.name", "");
        music = s.getString("music.ambient", "");
        musicSeconds = Math.max(10, s.getInt("music.ambient-seconds", 120));
        bossMusic = s.getString("music.boss", "");
        days = s.getStringList("days").stream().map(d -> d.toUpperCase(Locale.ROOT)).toList();
        List<Integer> bp = s.getIntegerList("boss.phases");
        bossPhases = bp.isEmpty() ? List.of(65, 35) : List.copyOf(bp);
        baseCurrency = s.getLong("rewards.currency", 0);
        firstClearBonus = s.getLong("rewards.first-clear-bonus", 0);
        rolls = s.getInt("rewards.rolls", 1);
        readLoot(s.getConfigurationSection("rewards.loot"), loot);
        readLoot(s.getConfigurationSection("rewards.guaranteed"), guaranteed);
    }

    private static void readLoot(ConfigurationSection sec, List<LootEntry> out) {
        if (sec == null) return;
        for (String k : sec.getKeys(false)) {
            ConfigurationSection e = sec.getConfigurationSection(k);
            Difficulty md = Optional.ofNullable(Difficulty.parse(e.getString("min-difficulty", "NORMAL"))).orElse(Difficulty.NORMAL);
            int min = Math.max(1, e.getInt("min", 1));
            out.add(new LootEntry(e.getString("id", ""), min, Math.max(min, e.getInt("max", min)),
                    Math.max(0.0001, e.getDouble("weight", 1)), md, e.getBoolean("announce", false)));
        }
    }

    public static DungeonDefinition load(String id, ConfigurationSection s) { return new DungeonDefinition(id, s); }
}
