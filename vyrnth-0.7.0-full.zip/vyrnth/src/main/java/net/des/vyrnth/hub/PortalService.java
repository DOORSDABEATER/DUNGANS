package net.des.vyrnth.hub;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.dungeon.DungeonDefinition;
import net.des.vyrnth.util.Cuboid;
import net.des.vyrnth.util.Msg;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.*;
import java.util.logging.Level;

/** Walk-into regions: lobby<->hub portals, dungeon gateways and the reward station. */
public final class PortalService implements Listener {
    public enum Type { LOBBY_TO_HUB, HUB_TO_LOBBY, DUNGEON_GATEWAY, REWARD_STATION, SHOP, GACHA, CHALLENGES, ACHIEVEMENTS, LEADERBOARDS, STATS, TROPHIES, LORE, SEASON, SPECTATE, PRACTICE }
    public record Portal(String id, Type type, String world, Cuboid region, String dungeon) {}

    private final VyrnthPlugin plugin;
    private final Map<String, List<Portal>> byWorld = new HashMap<>();
    private final Map<String, Portal> byId = new LinkedHashMap<>();
    private final Map<UUID, Long> cooldown = new HashMap<>();

    public PortalService(VyrnthPlugin plugin) { this.plugin = plugin; }

    public void reload() {
        byWorld.clear(); byId.clear();
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("portals");
        if (s == null) return;
        for (String key : s.getKeys(false)) {
            try {
                ConfigurationSection p = s.getConfigurationSection(key);
                Portal portal = new Portal(key, Type.valueOf(p.getString("type", "").toUpperCase(Locale.ROOT)),
                        p.getString("world", ""), Cuboid.read(p), p.getString("dungeon", ""));
                byId.put(key, portal);
                byWorld.computeIfAbsent(portal.world(), w -> new ArrayList<>()).add(portal);
            } catch (Exception e) { plugin.getLogger().log(Level.WARNING, "Bad portal '" + key + "'", e); }
        }
    }

    public Collection<Portal> all() { return byId.values(); }

    public void add(Portal p) {
        String base = "portals." + p.id();
        plugin.getConfig().set(base + ".type", p.type().name());
        plugin.getConfig().set(base + ".world", p.world());
        Cuboid r = p.region();
        plugin.getConfig().set(base + ".min", List.of(r.minX(), r.minY(), r.minZ()));
        plugin.getConfig().set(base + ".max", List.of(r.maxX(), r.maxY(), r.maxZ()));
        if (!p.dungeon().isBlank()) plugin.getConfig().set(base + ".dungeon", p.dungeon());
        plugin.saveConfig();
        reload();
    }

    public boolean remove(String id) {
        if (!byId.containsKey(id)) return false;
        plugin.getConfig().set("portals." + id, null);
        plugin.saveConfig();
        reload();
        return true;
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!e.hasChangedBlock()) return;
        List<Portal> list = byWorld.get(e.getTo().getWorld().getName());
        if (list == null) return;
        Player p = e.getPlayer();
        for (Portal portal : list) {
            if (!portal.region().contains(e.getTo())) continue;
            long now = System.currentTimeMillis();
            if (cooldown.getOrDefault(p.getUniqueId(), 0L) > now) return;
            cooldown.put(p.getUniqueId(), now + 2500);
            trigger(p, portal);
            return;
        }
    }

    private void trigger(Player p, Portal portal) {
        if (plugin.instances().of(p.getUniqueId()) != null) return;
        switch (portal.type()) {
            case LOBBY_TO_HUB -> {
                if (plugin.maintenance() && !p.isOp()) { Msg.send(p, "<red>VYRNTH is under maintenance."); return; }
                p.teleportAsync(plugin.hubSpawn());
            }
            case HUB_TO_LOBBY -> p.teleportAsync(plugin.lobbySpawn());
            case DUNGEON_GATEWAY -> {
                DungeonDefinition def = plugin.dungeons().get(portal.dungeon());
                if (def == null) Msg.send(p, "<red>This gateway is not linked to a dungeon.");
                else plugin.menus().openDungeon(p, def);
            }
            case REWARD_STATION -> plugin.menus().openInbox(p);
            case SHOP -> plugin.menus().openShop(p);
            case CHALLENGES -> plugin.menus().openChallenges(p);
            case ACHIEVEMENTS -> plugin.menus().openAchievements(p);
            case LEADERBOARDS -> plugin.menus().openLeaderboards(p);
            case STATS -> plugin.menus().openStats(p);
            case TROPHIES -> plugin.menus().openTrophies(p);
            case LORE -> plugin.menus().openLore(p);
            case SEASON -> plugin.menus().openSeason(p);
            case SPECTATE -> plugin.menus().openSpectate(p);
            case PRACTICE -> plugin.practice().use(p);
            case GACHA -> { if (portal.dungeon().isBlank()) plugin.menus().openGachaSelect(p); else plugin.menus().openGacha(p, portal.dungeon()); }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { cooldown.remove(e.getPlayer().getUniqueId()); }
}
