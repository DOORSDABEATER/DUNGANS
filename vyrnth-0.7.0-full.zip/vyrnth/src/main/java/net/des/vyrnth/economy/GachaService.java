package net.des.vyrnth.economy;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.data.CurrencyService;
import net.des.vyrnth.data.InboxService;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import net.des.vyrnth.util.Msg;

import java.io.File;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;

/**
 * Gacha chambers. Every draw is ONE transaction: debit, pity update, roll, duplicate check, item grant, history.
 * Item bytes are pre-serialised at reload so the DB thread never touches the Bukkit/Mythic API.
 */
public final class GachaService {
    public record Entry(String key, String display, double weight, boolean rare, boolean unique, long refund, byte[] data) {}
    public record Pool(String id, String display, long cost, int multi, long multiCost, int pity, boolean announce, List<Entry> entries) {
        public double total() { return entries.stream().mapToDouble(Entry::weight).sum(); }
    }
    public record Draw(Entry entry, boolean duplicate) {}
    public record Outcome(String error, List<Draw> draws, int pity) {}

    private final VyrnthPlugin plugin;
    private final Map<String, Pool> pools = new LinkedHashMap<>();

    public GachaService(VyrnthPlugin plugin) { this.plugin = plugin; }

    public Collection<Pool> pools() { return pools.values(); }
    public Pool pool(String id) { return pools.get(id); }

    public void reload() {
        pools.clear();
        File f = new File(plugin.getDataFolder(), "gacha.yml");
        if (!f.exists()) plugin.saveResource("gacha.yml", false);
        ConfigurationSection root = YamlConfiguration.loadConfiguration(f).getConfigurationSection("pools");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            try {
                ConfigurationSection s = root.getConfigurationSection(id);
                List<Entry> entries = new ArrayList<>();
                ConfigurationSection es = s.getConfigurationSection("entries");
                if (es != null) for (String k : es.getKeys(false)) {
                    ConfigurationSection e = es.getConfigurationSection(k);
                    ItemStack st = plugin.loot().resolve(e.getString("item", ""), e.getInt("amount", 1));
                    if (st == null) continue;
                    entries.add(new Entry(id + ":" + k, e.getString("display", k), Math.max(0.0001, e.getDouble("weight", 1)),
                            e.getBoolean("rare", false), e.getBoolean("unique", false), e.getLong("duplicate-refund", 0), st.serializeAsBytes()));
                }
                if (entries.isEmpty()) throw new IllegalArgumentException("no valid entries");
                long cost = Math.max(1, s.getLong("cost", 100));
                int multi = Math.max(2, s.getInt("multi", 10));
                pools.put(id, new Pool(id, s.getString("display", id), cost, multi, s.getLong("multi-cost", cost * multi),
                        s.getInt("pity", 0), s.getBoolean("announce-rare", true), List.copyOf(entries)));
            } catch (Exception ex) { plugin.getLogger().log(Level.WARNING, "Bad gacha pool '" + id + "'", ex); }
        }
        plugin.getLogger().info("Gacha: " + pools.size() + " pool(s).");
    }

    public CompletableFuture<Integer> pity(UUID id, Pool pool) {
        return plugin.db().submit(c -> {
            try (PreparedStatement ps = c.prepareStatement("SELECT count FROM gacha_pity WHERE uuid=? AND pool=?")) {
                ps.setString(1, id.toString()); ps.setString(2, pool.id());
                try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
            }
        });
    }

    public CompletableFuture<Outcome> draw(UUID id, Pool pool, int times) {
        long cost = times == pool.multi() ? pool.multiCost() : pool.cost() * times;
        return plugin.db().tx(c -> {
            if (!CurrencyService.debit(c, id, cost, "gacha:" + pool.id() + "x" + times)) return new Outcome("FUNDS", List.of(), 0);
            int pity = 0;
            try (PreparedStatement ps = c.prepareStatement("SELECT count FROM gacha_pity WHERE uuid=? AND pool=?")) {
                ps.setString(1, id.toString()); ps.setString(2, pool.id());
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) pity = rs.getInt(1); }
            }
            List<Entry> rares = pool.entries().stream().filter(Entry::rare).toList();
            List<Draw> draws = new ArrayList<>();
            for (int t = 0; t < times; t++) {
                pity++;
                boolean force = pool.pity() > 0 && pity >= pool.pity() && !rares.isEmpty();
                Entry e = pick(force ? rares : pool.entries());
                if (e.rare()) pity = 0;
                boolean dup = false;
                if (e.unique()) {
                    try (PreparedStatement ps = c.prepareStatement("INSERT OR IGNORE INTO owned(uuid, item_key) VALUES(?,?)")) {
                        ps.setString(1, id.toString()); ps.setString(2, e.key());
                        dup = ps.executeUpdate() == 0;
                    }
                }
                if (dup) { if (e.refund() > 0) CurrencyService.add(c, id, e.refund(), "gacha-duplicate:" + e.key()); }
                else InboxService.insert(c, id, e.data(), "gacha:" + pool.id());
                try (PreparedStatement ps = c.prepareStatement("INSERT INTO gacha_history(uuid, pool, entry, ts) VALUES(?,?,?,?)")) {
                    ps.setString(1, id.toString()); ps.setString(2, pool.id()); ps.setString(3, e.key()); ps.setLong(4, System.currentTimeMillis());
                    ps.executeUpdate();
                }
                draws.add(new Draw(e, dup));
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO gacha_pity(uuid, pool, count) VALUES(?,?,?) ON CONFLICT(uuid, pool) DO UPDATE SET count = excluded.count")) {
                ps.setString(1, id.toString()); ps.setString(2, pool.id()); ps.setInt(3, pity); ps.executeUpdate();
            }
            return new Outcome(null, draws, pity);
        });
    }

    private static Entry pick(List<Entry> list) {
        double total = list.stream().mapToDouble(Entry::weight).sum();
        double x = ThreadLocalRandom.current().nextDouble() * total;
        for (Entry e : list) { x -= e.weight(); if (x <= 0) return e; }
        return list.get(list.size() - 1);
    }

    /** Main-thread follow-up: messages, rare announcements, inbox delivery. */
    public void announce(org.bukkit.entity.Player p, Pool pool, Outcome o) {
        StringBuilder sb = new StringBuilder();
        for (Draw d : o.draws()) {
            sb.append(d.entry().rare() ? "<gold>★ " : "<white>• ").append(d.entry().display());
            if (d.duplicate()) sb.append(" <gray>(duplicate → +").append(d.entry().refund()).append(" ").append(plugin.currencyName()).append(")");
            sb.append("\n");
            if (d.entry().rare() && pool.announce() && !d.duplicate())
                Bukkit.broadcast(Msg.c("<#2DD4BF><bold>VYRNTH</bold> <dark_gray>»</dark_gray> <gold>" + p.getName()
                        + "</gold> <gray>pulled <light_purple>" + d.entry().display() + "</light_purple> from " + pool.display()));
        }
        Msg.send(p, "<gray>Results from <white>" + pool.display() + "</white>:\n" + sb.toString().stripTrailing());
        if (pool.pity() > 0) Msg.send(p, "<gray>Pity: " + o.pity() + "/" + pool.pity());
        plugin.inbox().deliverAll(p);
    }
}
