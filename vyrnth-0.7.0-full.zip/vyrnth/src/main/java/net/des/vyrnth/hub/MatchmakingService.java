package net.des.vyrnth.hub;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.dungeon.Difficulty;
import net.des.vyrnth.dungeon.DungeonDefinition;
import net.des.vyrnth.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;

/** Opt-in group finder: queue at a gateway, get grouped with others waiting for the same dungeon + difficulty. */
public final class MatchmakingService {
    private record Key(String dungeon, Difficulty diff) {}

    private final VyrnthPlugin plugin;
    private final Map<Key, LinkedHashMap<UUID, Long>> queues = new HashMap<>();

    public MatchmakingService(VyrnthPlugin plugin) { this.plugin = plugin; }

    public boolean queued(UUID id) { return queues.values().stream().anyMatch(q -> q.containsKey(id)); }

    /** @return error message or null */
    public String join(Player p, DungeonDefinition def, Difficulty d) {
        UUID id = p.getUniqueId();
        if (plugin.parties().of(id) != null) return "Leave your party to use the group finder (parties launch directly).";
        if (plugin.instances().of(id) != null) return "You're already in an expedition.";
        if (def.maxPlayers < 2) return "This dungeon is solo only.";
        if (!plugin.progression().isUnlocked(id, def, d)) return "You haven't unlocked " + d.display + " here.";
        if (!p.getWorld().equals(plugin.hubSpawn().getWorld())) return "You must be in the hub.";
        leave(id);
        queues.computeIfAbsent(new Key(def.id, d), k -> new LinkedHashMap<>()).put(id, System.currentTimeMillis());
        return null;
    }

    public boolean leave(UUID id) {
        boolean any = false;
        for (var q : queues.values()) any |= q.remove(id) != null;
        return any;
    }

    public int size(String dungeon, Difficulty d) {
        var q = queues.get(new Key(dungeon, d));
        return q == null ? 0 : q.size();
    }

    public Map<String, Integer> snapshot() {
        Map<String, Integer> out = new LinkedHashMap<>();
        for (var e : queues.entrySet()) if (!e.getValue().isEmpty()) out.put(e.getKey().dungeon() + " " + e.getKey().diff(), e.getValue().size());
        return out;
    }

    public void tick() {
        if (queues.isEmpty()) return;
        long now = System.currentTimeMillis();
        long waitMs = plugin.getConfig().getLong("matchmaking.wait-seconds", 30) * 1000L;
        var hubWorld = plugin.hubSpawn().getWorld();
        for (var entry : new ArrayList<>(queues.entrySet())) {
            Key key = entry.getKey();
            DungeonDefinition def = plugin.dungeons().get(key.dungeon());
            LinkedHashMap<UUID, Long> q = entry.getValue();
            if (def == null) { q.clear(); continue; }
            q.keySet().removeIf(id -> {   // drop anyone who left the hub, joined a party/run, or went offline
                Player p = Bukkit.getPlayer(id);
                return p == null || !p.getWorld().equals(hubWorld) || plugin.instances().of(id) != null || plugin.parties().of(id) != null;
            });
            if (q.isEmpty()) continue;
            long oldest = Collections.min(q.values());
            boolean full = q.size() >= def.maxPlayers;
            boolean enough = q.size() >= Math.max(2, def.minPlayers) && now - oldest >= waitMs;
            if (!full && !enough) continue;
            List<Player> group = new ArrayList<>();
            for (UUID id : q.keySet()) { if (group.size() >= def.maxPlayers) break; Player p = Bukkit.getPlayer(id); if (p != null) group.add(p); }
            for (Player p : group) q.remove(p.getUniqueId());
            String err = plugin.instances().start(def, key.diff(), group, false);
            for (Player p : group) Msg.send(p, err == null ? "<green>Group found! Launching " + def.display + "..." : "<red>Group launch failed: " + err);
        }
    }
}
