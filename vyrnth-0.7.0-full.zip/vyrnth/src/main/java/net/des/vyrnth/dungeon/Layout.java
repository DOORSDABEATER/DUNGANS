package net.des.vyrnth.dungeon;

import net.des.vyrnth.util.Cuboid;
import net.des.vyrnth.util.Pos;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;

/**
 * Data-driven dungeon layout: gates, hazards, rooms with objectives, secrets, secret bosses, revival points and machinery
 * (turrets, crushers, conveyors, platforms, gravity/teleport anomalies, cold and heat zones). Pure config.
 * Runtime lives in instance.RoomManager / instance.MechanicsManager.
 */
public final class Layout {
    /**
     * Machinery switches. during: room id (while active) | "boss" | "boss-phase-N" (phase >= N) | "boss-only-N" (phase == N).
     * disabledBy: room/secret id that switches it off. after: room/secret id that must be done before it switches on.
     */
    public record Cond(String during, String disabledBy, String after) {}
    public record Hazard(Cuboid region, String effect, int amp, double damage, Difficulty minDiff) {}
    public record Spawn(String mob, Pos pos, int count, int extraPerDiff, int perPlayer, boolean required, Difficulty minDiff,
                        int wave, String rareMob, double rareChance) {}
    public record Routing(List<int[]> junctions, int[] solution, int states, List<String> labels, Difficulty hideFeedbackFrom) {}
    public record Sequence(List<int[]> buttons, int[] order, double failDamage) {}
    /** type: CLEAR_SPAWNS | ACTIVATE | ROUTING | REACH | SEQUENCE | WAVES | SURVIVE. */
    public record Room(String id, Cuboid trigger, String message, String type, List<Hazard> hazards, List<Spawn> spawns,
                       List<int[]> activators, int hold, int holdReduction, List<String> opens, Pos checkpoint,
                       Cuboid goal, Routing routing, Sequence sequence) {
        public int waves() { return spawns.stream().mapToInt(Spawn::wave).max().orElse(1); }
    }
    public record Secret(String id, String type, int x, int y, int z, String title, List<String> text, long reward,
                         String item, String opens, String message) {}
    public record SecretBoss(String id, String mob, Pos pos, String after, long reward, String item, Difficulty minDiff, String message) {}
    public record Revival(String id, int x, int y, int z, int uses) {}
    public record Turret(String id, double x, double y, double z, double range, double interval, double intervalReduction,
                         double damage, double damagePerDiff, Difficulty minDiff, Cond cond) {}
    /** style CRUSH (dust + anvil) or ARC (electric sparks + thunder). */
    public record Crusher(String id, Cuboid region, double period, double periodReduction, double warn, double active,
                          double damage, String style, Difficulty minDiff, Cond cond) {}
    public record Conveyor(String id, Cuboid region, double dx, double dy, double dz, double speed, double speedPerDiff,
                           Difficulty minDiff, Cond cond) {}
    /** SLIDE: ping-pong along one axis carrying riders. PHASE: warn colour, vanish, return; `offset` staggers paired platforms. */
    public record Platform(String id, String type, Cuboid region, int mx, int my, int mz, int stepTicks, double pause,
                           double on, double warn, double off, double offset, String warnMaterial, Difficulty minDiff, Cond cond) {}
    /** type GRAVITY (mode LOW|HEAVY|LIFT, optional period/active cycle) or TELEPORT (pad -> `to`; Nightmare+ picks randomly among all). */
    public record Anomaly(String id, String type, Cuboid region, String mode, List<Pos> to, double period, double active,
                          double cooldown, Difficulty minDiff, Cond cond) {}
    public record Cold(String id, Cuboid region, int rate, Difficulty minDiff, Cond cond) {}
    public record Heat(String id, Cuboid region, double period, double active, double offset, Cond cond) {}

    public final Map<String, Cuboid> gates = new LinkedHashMap<>();
    public final List<Hazard> hazards = new ArrayList<>();
    public final List<Room> rooms = new ArrayList<>();
    public final List<Secret> secrets = new ArrayList<>();
    public final List<SecretBoss> secretBosses = new ArrayList<>();
    public final List<Revival> revivals = new ArrayList<>();
    public final List<Turret> turrets = new ArrayList<>();
    public final List<Crusher> crushers = new ArrayList<>();
    public final List<Conveyor> conveyors = new ArrayList<>();
    public final List<Platform> platforms = new ArrayList<>();
    public final List<Anomaly> anomalies = new ArrayList<>();
    public final List<Cold> cold = new ArrayList<>();
    public final List<Heat> heat = new ArrayList<>();

    public boolean hasMotion() {
        return !crushers.isEmpty() || !conveyors.isEmpty() || !platforms.isEmpty() || !anomalies.isEmpty() || !cold.isEmpty();
    }

    private static final Set<String> ROOM_TYPES = Set.of("CLEAR_SPAWNS", "ACTIVATE", "ROUTING", "REACH", "SEQUENCE", "WAVES", "SURVIVE");

    public static Layout read(ConfigurationSection s) {
        Layout L = new Layout();
        ConfigurationSection g = s.getConfigurationSection("gates");
        if (g != null) for (String k : g.getKeys(false)) L.gates.put(k, Cuboid.read(g.getConfigurationSection(k)));
        readHazards(s.getConfigurationSection("hazards"), L.hazards);

        ConfigurationSection rs = s.getConfigurationSection("rooms");
        if (rs != null) for (String k : rs.getKeys(false)) L.rooms.add(readRoom(k, rs.getConfigurationSection(k)));

        ConfigurationSection ss = s.getConfigurationSection("secrets");
        if (ss != null) for (String k : ss.getKeys(false)) {
            ConfigurationSection e = ss.getConfigurationSection(k);
            List<Integer> p = e.getIntegerList("pos");
            if (p.size() != 3) throw new IllegalArgumentException("secret " + k + " needs pos [x,y,z]");
            L.secrets.add(new Secret(k, e.getString("type", "DATA_LOG").toUpperCase(Locale.ROOT), p.get(0), p.get(1), p.get(2),
                    e.getString("title", k), e.getStringList("text"), e.getLong("reward", 0), e.getString("item", ""),
                    e.getString("opens", ""), e.getString("message", "")));
        }
        ConfigurationSection sb = s.getConfigurationSection("secret-bosses");
        if (sb != null) for (String k : sb.getKeys(false)) {
            ConfigurationSection e = sb.getConfigurationSection(k);
            L.secretBosses.add(new SecretBoss(k, e.getString("mob", ""), vec(e.getDoubleList("pos")), e.getString("after", ""),
                    e.getLong("reward", 0), e.getString("item", ""), diff(e.getString("min-difficulty")), e.getString("message", "")));
        }
        ConfigurationSection rv = s.getConfigurationSection("revival");
        if (rv != null) for (String k : rv.getKeys(false)) {
            ConfigurationSection e = rv.getConfigurationSection(k);
            List<Integer> p = e.getIntegerList("pos");
            if (p.size() != 3) throw new IllegalArgumentException("revival " + k + " needs pos");
            L.revivals.add(new Revival(k, p.get(0), p.get(1), p.get(2), Math.max(1, e.getInt("uses", 1))));
        }

        ConfigurationSection ts = s.getConfigurationSection("turrets");
        if (ts != null) for (String k : ts.getKeys(false)) {
            ConfigurationSection e = ts.getConfigurationSection(k);
            List<Double> p = e.getDoubleList("pos");
            if (p.size() != 3) throw new IllegalArgumentException("turret " + k + " needs pos");
            L.turrets.add(new Turret(k, p.get(0), p.get(1), p.get(2), e.getDouble("range", 20), e.getDouble("interval", 4),
                    e.getDouble("interval-reduction-per-difficulty", 0.5), e.getDouble("damage", 4), e.getDouble("damage-per-difficulty", 1),
                    diff(e.getString("min-difficulty")), cond(e)));
        }
        ConfigurationSection cs = s.getConfigurationSection("crushers");
        if (cs != null) for (String k : cs.getKeys(false)) {
            ConfigurationSection e = cs.getConfigurationSection(k);
            double period = e.getDouble("period", 8), warn = e.getDouble("warn", 2), active = e.getDouble("active", 1);
            if (warn + active >= period) throw new IllegalArgumentException("crusher " + k + ": warn+active must be < period");
            L.crushers.add(new Crusher(k, Cuboid.read(Objects.requireNonNull(e.getConfigurationSection("region"), "crusher " + k)),
                    period, e.getDouble("period-reduction-per-difficulty", 1), warn, active, e.getDouble("damage", 8),
                    e.getString("style", "CRUSH").toUpperCase(Locale.ROOT), diff(e.getString("min-difficulty")), cond(e)));
        }
        ConfigurationSection vs = s.getConfigurationSection("conveyors");
        if (vs != null) for (String k : vs.getKeys(false)) {
            ConfigurationSection e = vs.getConfigurationSection(k);
            List<Double> d = e.getDoubleList("dir");
            if (d.size() != 3) throw new IllegalArgumentException("conveyor " + k + " needs dir [x,y,z]");
            double len = Math.sqrt(d.get(0) * d.get(0) + d.get(1) * d.get(1) + d.get(2) * d.get(2));
            if (len == 0) throw new IllegalArgumentException("conveyor " + k + ": zero dir");
            L.conveyors.add(new Conveyor(k, Cuboid.read(Objects.requireNonNull(e.getConfigurationSection("region"), "conveyor " + k)),
                    d.get(0) / len, d.get(1) / len, d.get(2) / len, e.getDouble("speed", 0.1), e.getDouble("speed-per-difficulty", 0.02),
                    diff(e.getString("min-difficulty")), cond(e)));
        }
        ConfigurationSection ps = s.getConfigurationSection("platforms");
        if (ps != null) for (String k : ps.getKeys(false)) {
            ConfigurationSection e = ps.getConfigurationSection(k);
            String type = e.getString("type", "SLIDE").toUpperCase(Locale.ROOT);
            Cuboid region = Cuboid.read(Objects.requireNonNull(e.getConfigurationSection("region"), "platform " + k));
            long cells = (long) (region.maxX() - region.minX() + 1) * (long) (region.maxY() - region.minY() + 1) * (long) (region.maxZ() - region.minZ() + 1);
            if (cells > 900) throw new IllegalArgumentException("platform " + k + ": max 900 blocks");
            List<Integer> mv = e.getIntegerList("move");
            int mx = 0, my = 0, mz = 0;
            if (type.equals("SLIDE")) {
                if (mv.size() != 3) throw new IllegalArgumentException("platform " + k + ": SLIDE needs move [dx,dy,dz]");
                mx = mv.get(0); my = mv.get(1); mz = mv.get(2);
                if ((mx != 0 ? 1 : 0) + (my != 0 ? 1 : 0) + (mz != 0 ? 1 : 0) != 1) throw new IllegalArgumentException("platform " + k + ": move must be along exactly one axis");
            } else if (!type.equals("PHASE")) throw new IllegalArgumentException("platform " + k + ": type must be SLIDE or PHASE");
            L.platforms.add(new Platform(k, type, region, mx, my, mz, Math.max(2, e.getInt("step-ticks", 8)), e.getDouble("pause", 3),
                    e.getDouble("on", 4), e.getDouble("warn", 1.5), e.getDouble("off", 3), e.getDouble("offset", 0),
                    e.getString("warn-material", "RED_CONCRETE"), diff(e.getString("min-difficulty")), cond(e)));
        }
        ConfigurationSection as = s.getConfigurationSection("anomalies");
        if (as != null) for (String k : as.getKeys(false)) {
            ConfigurationSection e = as.getConfigurationSection(k);
            String type = e.getString("type", "GRAVITY").toUpperCase(Locale.ROOT);
            List<Pos> to = new ArrayList<>();
            for (Object o : e.getList("to", List.of()))
                if (o instanceof List<?> l && l.size() == 3) to.add(new Pos(dbl(l.get(0)), dbl(l.get(1)), dbl(l.get(2)), 0f, 0f));
            if (type.equals("TELEPORT") && to.isEmpty()) throw new IllegalArgumentException("anomaly " + k + ": TELEPORT needs `to`");
            if (!type.equals("TELEPORT") && !type.equals("GRAVITY")) throw new IllegalArgumentException("anomaly " + k + ": type GRAVITY or TELEPORT");
            L.anomalies.add(new Anomaly(k, type, Cuboid.read(Objects.requireNonNull(e.getConfigurationSection("region"), "anomaly " + k)),
                    e.getString("mode", "LOW").toUpperCase(Locale.ROOT), to, e.getDouble("period", 0), e.getDouble("active", 0),
                    e.getDouble("cooldown", 3), diff(e.getString("min-difficulty")), cond(e)));
        }
        ConfigurationSection cl = s.getConfigurationSection("cold");
        if (cl != null) for (String k : cl.getKeys(false)) {
            ConfigurationSection e = cl.getConfigurationSection(k);
            L.cold.add(new Cold(k, Cuboid.read(Objects.requireNonNull(e.getConfigurationSection("region"), "cold " + k)),
                    e.getInt("rate", 6), diff(e.getString("min-difficulty")), cond(e)));
        }
        ConfigurationSection ht = s.getConfigurationSection("heat");
        if (ht != null) for (String k : ht.getKeys(false)) {
            ConfigurationSection e = ht.getConfigurationSection(k);
            L.heat.add(new Heat(k, Cuboid.read(Objects.requireNonNull(e.getConfigurationSection("region"), "heat " + k)),
                    e.getDouble("period", 0), e.getDouble("active", 0), e.getDouble("offset", 0), cond(e)));
        }

        // reference validation: fail the dungeon load loudly instead of silently never opening a door
        Set<String> refs = new HashSet<>(List.of("boss"));
        for (int n = 1; n <= 6; n++) { refs.add("boss-phase-" + n); refs.add("boss-only-" + n); }
        for (Room r : L.rooms) refs.add(r.id());
        for (Secret x : L.secrets) refs.add(x.id());
        for (Room r : L.rooms) for (String o : r.opens())
            if (!L.gates.containsKey(o)) throw new IllegalArgumentException("room " + r.id() + " opens unknown gate '" + o + "'");
        for (Secret x : L.secrets)
            if (!x.opens().isBlank() && !L.gates.containsKey(x.opens())) throw new IllegalArgumentException("secret " + x.id() + " opens unknown gate '" + x.opens() + "'");
        Set<String> secretIds = new HashSet<>();
        for (Secret x : L.secrets) secretIds.add(x.id());
        for (SecretBoss b : L.secretBosses)
            if (!secretIds.contains(b.after())) throw new IllegalArgumentException("secret boss " + b.id() + " needs `after` = a secret id");
        List<Cond> conds = new ArrayList<>();
        L.turrets.forEach(t -> conds.add(t.cond())); L.crushers.forEach(t -> conds.add(t.cond()));
        L.conveyors.forEach(t -> conds.add(t.cond())); L.platforms.forEach(t -> conds.add(t.cond()));
        L.anomalies.forEach(t -> conds.add(t.cond())); L.cold.forEach(t -> conds.add(t.cond())); L.heat.forEach(t -> conds.add(t.cond()));
        for (Cond c : conds) for (String ref : new String[]{c.during(), c.disabledBy(), c.after()})
            if (!ref.isBlank() && !refs.contains(ref)) throw new IllegalArgumentException("machinery references unknown id '" + ref + "'");
        return L;
    }

    private static Room readRoom(String k, ConfigurationSection r) {
        List<Hazard> hz = new ArrayList<>();
        readHazards(r.getConfigurationSection("hazards"), hz);
        List<Spawn> sp = new ArrayList<>();
        ConfigurationSection ss = r.getConfigurationSection("spawns");
        if (ss != null) for (String sk : ss.getKeys(false)) {
            ConfigurationSection e = ss.getConfigurationSection(sk);
            sp.add(new Spawn(e.getString("mob", ""), vec(e.getDoubleList("pos")), Math.max(1, e.getInt("count", 1)),
                    e.getInt("extra-per-difficulty", 0), e.getInt("per-extra-player", 0), e.getBoolean("required", true),
                    diff(e.getString("min-difficulty")), Math.max(1, e.getInt("wave", 1)),
                    e.getString("rare-mob", ""), e.getDouble("rare-chance", 0.0)));
        }
        List<int[]> acts = ints(r.getList("activators", List.of()));
        String type = r.getString("type", "CLEAR_SPAWNS").toUpperCase(Locale.ROOT);
        if (!ROOM_TYPES.contains(type)) throw new IllegalArgumentException("room " + k + ": unknown type " + type);
        if (type.equals("ACTIVATE") && acts.isEmpty()) throw new IllegalArgumentException("room " + k + ": ACTIVATE needs activators");
        if (type.equals("WAVES") && sp.isEmpty()) throw new IllegalArgumentException("room " + k + ": WAVES needs spawns");
        ConfigurationSection goalSec = r.getConfigurationSection("goal");
        if (type.equals("REACH") && goalSec == null) throw new IllegalArgumentException("room " + k + ": REACH needs goal");
        Routing routing = null;
        if (type.equals("ROUTING")) {
            ConfigurationSection rt = Objects.requireNonNull(r.getConfigurationSection("routing"), "room " + k + " routing");
            List<int[]> js = ints(rt.getList("junctions", List.of()));
            int states = rt.getInt("states", 4);
            List<Integer> sol = rt.getIntegerList("solution");
            if (js.size() < 2 || js.size() > 8 || sol.size() != js.size() || states < 2)
                throw new IllegalArgumentException("room " + k + ": routing needs 2-8 junctions, matching solution, states>=2");
            int[] solution = new int[sol.size()];
            for (int q = 0; q < solution.length; q++) {
                if (sol.get(q) < 0 || sol.get(q) >= states) throw new IllegalArgumentException("room " + k + ": solution value out of range");
                solution[q] = sol.get(q);
            }
            Difficulty hide = Difficulty.parse(rt.getString("hide-feedback-from", "NIGHTMARE"));
            routing = new Routing(js, solution, states, rt.getStringList("labels"), hide == null ? Difficulty.NIGHTMARE : hide);
        }
        Sequence seq = null;
        if (type.equals("SEQUENCE")) {
            ConfigurationSection q = Objects.requireNonNull(r.getConfigurationSection("sequence"), "room " + k + " sequence");
            List<int[]> bs = ints(q.getList("buttons", List.of()));
            List<Integer> ord = q.getIntegerList("order");
            if (bs.size() < 2 || ord.size() < 2) throw new IllegalArgumentException("room " + k + ": sequence needs >=2 buttons and an order");
            int[] order = new int[ord.size()];
            for (int n = 0; n < order.length; n++) {
                if (ord.get(n) < 0 || ord.get(n) >= bs.size()) throw new IllegalArgumentException("room " + k + ": sequence order index out of range");
                order[n] = ord.get(n);
            }
            seq = new Sequence(bs, order, q.getDouble("fail-damage", 4));
        }
        ConfigurationSection cp = r.getConfigurationSection("checkpoint");
        return new Room(k, Cuboid.read(Objects.requireNonNull(r.getConfigurationSection("trigger"), "room " + k + " trigger")),
                r.getString("message", ""), type, hz, sp, acts, r.getInt("hold-seconds", 30), r.getInt("hold-reduction-per-difficulty", 0),
                r.getStringList("opens"), cp == null ? null : Pos.read(cp), goalSec == null ? null : Cuboid.read(goalSec), routing, seq);
    }

    private static List<int[]> ints(List<?> list) {
        List<int[]> out = new ArrayList<>();
        for (Object o : list) if (o instanceof List<?> l && l.size() == 3) out.add(new int[]{num(l.get(0)), num(l.get(1)), num(l.get(2))});
        return out;
    }

    private static Cond cond(ConfigurationSection e) {
        return new Cond(e.getString("active-during", ""), e.getString("disabled-by", ""), e.getString("after", ""));
    }

    private static void readHazards(ConfigurationSection sec, List<Hazard> out) {
        if (sec == null) return;
        for (String k : sec.getKeys(false)) {
            ConfigurationSection h = sec.getConfigurationSection(k);
            out.add(new Hazard(Cuboid.read(Objects.requireNonNull(h.getConfigurationSection("region"), "hazard " + k + " region")),
                    h.getString("effect", ""), h.getInt("amplifier", 0), h.getDouble("damage", 0), diff(h.getString("min-difficulty"))));
        }
    }

    private static Pos vec(List<Double> d) {
        if (d.size() != 3) throw new IllegalArgumentException("pos needs [x,y,z]");
        return new Pos(d.get(0), d.get(1), d.get(2), 0f, 0f);
    }

    private static Difficulty diff(String s) {
        Difficulty d = s == null ? null : Difficulty.parse(s);
        return d == null ? Difficulty.NORMAL : d;
    }

    private static int num(Object o) { return ((Number) o).intValue(); }
    private static double dbl(Object o) { return ((Number) o).doubleValue(); }
}
