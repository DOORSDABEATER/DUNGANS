package net.des.vyrnth.hub;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.*;

/** Hub practice arena: stepping on the pad spawns a time-limited, self-healing target dummy. Capped so it can't accumulate entities. */
public final class PracticeService {
    private static final int MAX_DUMMIES = 6;
    private static final long LIFETIME_TICKS = 20L * 180;

    private final VyrnthPlugin plugin;
    private final Map<UUID, UUID> byPlayer = new HashMap<>();   // player -> dummy entity

    public PracticeService(VyrnthPlugin plugin) { this.plugin = plugin; }

    public void use(Player p) {
        Location at = plugin.readLocation("practice.spawn");
        if (at == null) { Msg.send(p, "<gray>The practice arena isn't configured yet."); return; }
        byPlayer.values().removeIf(id -> { Entity e = Bukkit.getEntity(id); return e == null || e.isDead(); });
        UUID existing = byPlayer.get(p.getUniqueId());
        if (existing != null) { Msg.send(p, "<gray>You already have a dummy out."); return; }
        if (byPlayer.size() >= MAX_DUMMIES) { Msg.send(p, "<gray>All dummies are in use. Try again in a moment."); return; }
        if (!plugin.mythic().present()) { Msg.send(p, "<gray>Practice dummies need MythicMobs."); return; }
        try {
            Entity e = plugin.mythic().spawn("VY_PracticeDummy", at);
            if (e == null) return;
            byPlayer.put(p.getUniqueId(), e.getUniqueId());
            Msg.send(p, "A practice dummy appears for <white>3 minutes</white>.");
            Bukkit.getScheduler().runTaskLater(plugin, () -> { e.remove(); byPlayer.remove(p.getUniqueId()); }, LIFETIME_TICKS);
        } catch (Exception ex) { plugin.getLogger().warning("Practice dummy failed: " + ex.getMessage()); }
    }

    public void shutdown() {
        for (UUID id : byPlayer.values()) { Entity e = Bukkit.getEntity(id); if (e != null) e.remove(); }
        byPlayer.clear();
    }
}
