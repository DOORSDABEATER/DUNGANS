package net.des.vyrnth.integration;

import io.lumine.mythic.bukkit.MythicBukkit;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.inventory.ItemStack;

/** All MythicMobs API calls live here so the rest of the plugin never touches the API directly. */
public final class MythicHook {
    private final boolean present = Bukkit.getPluginManager().isPluginEnabled("MythicMobs");

    public boolean present() { return present; }

    public Entity spawn(String mobId, Location loc) throws Exception {
        if (!present) throw new IllegalStateException("MythicMobs is not installed/enabled");
        return MythicBukkit.inst().getAPIHelper().spawnMythicMob(mobId, loc);
    }

    public ItemStack item(String id) {
        if (!present) return null;
        return MythicBukkit.inst().getItemManager().getItemStack(id);
    }
}
