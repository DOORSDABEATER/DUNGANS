package net.des.vyrnth.live;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.data.CurrencyService;
import net.des.vyrnth.data.InboxService;
import net.des.vyrnth.dungeon.Difficulty;
import net.des.vyrnth.dungeon.DungeonDefinition;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.temporal.IsoFields;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/**
 * Achievements, daily/weekly challenges, daily/weekly dungeon rotation, weekly encounter modifier, limited-time events and the
 * seasonal cosmetic reward track. Achievement-style records only: no levels, classes or abilities.
 */
public final class LiveContentService {
    public record Ach(String id, String display, String desc, String type, String dungeon, Difficulty diff, long target, long reward, boolean hidden) {}
    public record Challenge(String id, String display, String type, String dungeon, Difficulty diff, int target, long reward, boolean weekly) {}
    public record RunCtx(String dungeon, Difficulty diff, long ms, int deaths, int partySize, boolean raid) {}
    public record SeasonTier(String id, int points, String display, long currency, byte[] item) {}
    public record Event(String id, String display, long startMs, long endMs, double multiplier, String message) {}
    public record Result(List<Ach> achievements, List<Challenge> completed, List<SeasonTier> tiers) {}
    public record SeasonView(int points, Set<String> claimed) {}

    public static final Map<String, String> MODIFIERS = new LinkedHashMap<>();
    static {
        MODIFIERS.put("BOUNTY", "+30% currency rewards");
        MODIFIERS.put("FRAGILE", "Players take +25% damage");
        MODIFIERS.put("MOB_HASTE", "Enemies move faster");
        MODIFIERS.put("SWARM", "+50% enemy spawns");
    }

    private final VyrnthPlugin plugin;
    private final Map<String, Ach> achs = new LinkedHashMap<>();
    private final List<Challenge> dailyPool = new ArrayList<>(), weeklyPool = new ArrayList<>();
    private final List<Event> events = new ArrayList<>();
    private final List<SeasonTier> tiers = new ArrayList<>();
    private String seasonId = "", seasonName = "";
    private long seasonStart, seasonEnd;
    private final Map<Difficulty, Integer> seasonPoints = new EnumMap<>(Difficulty.class);
    private int raidMult = 3;

    public LiveContentService(VyrnthPlugin plugin) { this.plugin = plugin; }

    // ------------------------------------------------------------ config
    public void reload() {
        achs.clear(); dailyPool.clear(); weeklyPool.clear(); events.clear(); tiers.clear();
        ConfigurationSection a = load("achievements.yml").getConfigurationSection("achievements");
        if (a != null) for (String k : a.getKeys(false)) {
            try {
                ConfigurationSection s = a.getConfigurationSection(k);
                achs.put(k, new Ach(k, s.getString("display", k), s.getString("description", ""), s.getString("type", "").toUpperCase(),
                        s.getString("dungeon", ""), Difficulty.parse(s.getString("difficulty", "")), s.getLong("target", s.getLong("seconds", 1)),
                        s.getLong("reward", 0), s.getBoolean("hidden", false)));
            } catch (Exception e) { plugin.getLogger().log(Level.WARNING, "Bad achievement " + k, e); }
        }
        YamlConfiguration c = load("challenges.yml");
        readChallenges(c.getConfigurationSection("daily"), dailyPool, false);
        readChallenges(c.getConfigurationSection("weekly"), weeklyPool, true);

        ConfigurationSection ev = load("events.yml").getConfigurationSection("events");
        if (ev != null) for (String k : ev.getKeys(false)) {
            try {
                ConfigurationSection e = ev.getConfigurationSection(k);
                events.add(new Event(k, e.getString("display", k), day(e.getString("start"), false), day(e.getString("end"), true),
                        e.getDouble("currency-multiplier", 1.0), e.getString("message", "")));
            } catch (Exception e) { plugin.getLogger().log(Level.WARNING, "Bad event " + k, e); }
        }
        ConfigurationSection se = load("season.yml").getConfigurationSection("season");
        if (se != null) try {
            seasonId = se.getString("id", "");
            seasonName = se.getString("name", seasonId);
            seasonStart = day(se.getString("start"), false);
            seasonEnd = day(se.getString("end"), true);
            raidMult = se.getInt("raid-multiplier", 3);
            for (Difficulty d : Difficulty.values()) seasonPoints.put(d, se.getInt("points-per-clear." + d.name(), 10));
            ConfigurationSection ts = se.getConfigurationSection("tiers");
            if (ts != null) for (String k : ts.getKeys(false)) {
                ConfigurationSection t = ts.getConfigurationSection(k);
                byte[] item = null;
                if (!t.getString("item", "").isBlank()) {
                    ItemStack st = plugin.loot().resolve(t.getString("item"), t.getInt("amount", 1));
                    if (st != null) item = st.serializeAsBytes();
                }
                tiers.add(new SeasonTier(k, t.getInt("points", 0), t.getString("display", k), t.getLong("currency", 0), item));
            }
            tiers.sort(Comparator.comparingInt(SeasonTier::points));
        } catch (Exception e) { plugin.getLogger().log(Level.WARNING, "Bad season.yml", e); seasonId = ""; }
        plugin.getLogger().info("Live content: " + achs.size() + " achievements, " + dailyPool.size() + " daily / " + weeklyPool.size()
                + " weekly challenges, " + events.size() + " events, season '" + seasonId + "' with " + tiers.size() + " tiers.");
    }

    private static long day(String iso, boolean endInclusive) {
        LocalDate d = LocalDate.parse(iso);
        return (endInclusive ? d.plusDays(1) : d).atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli();
    }

    private YamlConfiguration load(String name) {
        File f = new File(plugin.getDataFolder(), name);
        if (!f.exists()) plugin.saveResource(name, false);
        return YamlConfiguration.loadConfiguration(f);
    }

    private void readChallenges(ConfigurationSection sec, List<Challenge> out, boolean weekly) {
        if (sec == null) return;
        for (String k : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(k);
            out.add(new Challenge(k, s.getString("display", k), s.getString("type", "CLEAR_ANY").toUpperCase(), s.getString("dungeon", ""),
                    Difficulty.parse(s.getString("difficulty", "")), Math.max(1, s.getInt("target", 1)), s.getLong("reward", 0), weekly));
        }
    }

    public Collection<Ach> achievements() { return achs.values(); }
    public List<SeasonTier> seasonTiers() { return tiers; }
    public String seasonName() { return seasonName; }
    public boolean seasonActive() {
        long now = System.currentTimeMillis();
        return !seasonId.isBlank() && now >= seasonStart && now < seasonEnd && !tiers.isEmpty();
    }
    public long seasonEndMs() { return seasonEnd; }

    // ------------------------------------------------------------ rotation, modifiers, events
    public static String dayKey() { return LocalDate.now(ZoneOffset.UTC).toString(); }
    public static String weekKey() {
        LocalDate d = LocalDate.now(ZoneOffset.UTC);
        return d.get(IsoFields.WEEK_BASED_YEAR) + "-W" + String.format("%02d", d.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR));
    }

    private List<DungeonDefinition> pool() {
        return plugin.dungeons().all().stream().filter(d -> !d.raid && plugin.dungeons().isEnabled(d.id))
                .sorted(Comparator.comparing(d -> d.id)).toList();
    }

    private DungeonDefinition pickOrOverride(String overridePath, String seed) {
        String o = plugin.getConfig().getString(overridePath, "auto");
        if (o != null && !o.equalsIgnoreCase("auto") && !o.isBlank()) { DungeonDefinition d = plugin.dungeons().get(o); if (d != null) return d; }
        List<DungeonDefinition> l = pool();
        return l.isEmpty() ? null : l.get(Math.floorMod(seed.hashCode(), l.size()));
    }

    /** Daily/weekly rotation only features regular dungeons; raids are scheduled separately. */
    public DungeonDefinition dailyDungeon() { return pickOrOverride("live.daily-override", "d" + dayKey()); }
    public DungeonDefinition weeklyFeatured() { return pickOrOverride("live.weekly-override", "w" + weekKey()); }

    public double rotationMultiplier(DungeonDefinition def) {
        double m = 1.0;
        DungeonDefinition d = dailyDungeon(), w = weeklyFeatured();
        if (d != null && d.id.equals(def.id)) m += plugin.getConfig().getDouble("live.daily-dungeon-bonus", 0.25);
        if (w != null && w.id.equals(def.id)) m += plugin.getConfig().getDouble("live.weekly-featured-bonus", 0.5);
        return m;
    }

    public String weeklyModifier() {
        if (!plugin.getConfig().getBoolean("live.modifiers-enabled", true)) return null;
        String o = plugin.getConfig().getString("live.modifier-override", "auto");
        if (o != null && MODIFIERS.containsKey(o.toUpperCase(Locale.ROOT))) return o.toUpperCase(Locale.ROOT);
        List<String> keys = new ArrayList<>(MODIFIERS.keySet());
        return keys.get(Math.floorMod(("m" + weekKey()).hashCode(), keys.size()));
    }

    public List<Event> activeEvents() {
        long now = System.currentTimeMillis();
        return events.stream().filter(e -> now >= e.startMs() && now < e.endMs()).toList();
    }

    /** Rotation x events x BOUNTY modifier. */
    public double currencyMultiplier(DungeonDefinition def, String modifier) {
        double m = rotationMultiplier(def);
        for (Event e : activeEvents()) m *= e.multiplier();
        if ("BOUNTY".equals(modifier)) m *= 1.3;
        return m;
    }

    private List<Challenge> pick(List<Challenge> pool, String seed, int n) {
        List<Challenge> l = new ArrayList<>(pool);
        l.sort(Comparator.comparing(Challenge::id));
        Collections.shuffle(l, new Random(seed.hashCode()));
        return new ArrayList<>(l.subList(0, Math.min(n, l.size())));
    }

    public List<Challenge> activeDaily() { return pick(dailyPool, "D" + dayKey(), plugin.getConfig().getInt("live.daily-count", 3)); }
    public List<Challenge> activeWeekly() { return pick(weeklyPool, "W" + weekKey(), plugin.getConfig().getInt("live.weekly-count", 2)); }

    // ------------------------------------------------------------ matching
    private static boolean base(String dungeon, Difficulty need, RunCtx x) {
        return (dungeon.isBlank() || dungeon.equals(x.dungeon())) && (need == null || x.diff().ordinal() >= need.ordinal());
    }

    private boolean matches(Ach a, RunCtx x, long total) {
        return switch (a.type()) {
            case "CLEAR_DUNGEON", "CLEAR_DIFFICULTY" -> base(a.dungeon(), a.diff(), x);
            case "CLEAR_RAID" -> x.raid() && base(a.dungeon(), a.diff(), x);
            case "CLEARS_TOTAL" -> total >= a.target();
            case "FAST_CLEAR" -> base(a.dungeon(), a.diff(), x) && x.ms() <= a.target() * 1000L;
            case "FLAWLESS" -> base(a.dungeon(), a.diff(), x) && x.deaths() == 0;
            default -> false;
        };
    }

    private boolean matches(Challenge c, RunCtx x, DungeonDefinition daily, DungeonDefinition featured) {
        return switch (c.type()) {
            case "CLEAR_ANY" -> true;
            case "CLEAR_DUNGEON", "CLEAR_DIFFICULTY" -> base(c.dungeon(), c.diff(), x);
            case "CLEAR_RAID" -> x.raid() && base(c.dungeon(), c.diff(), x);
            case "FLAWLESS" -> x.deaths() == 0 && base(c.dungeon(), c.diff(), x);
            case "CLEAR_DAILY" -> daily != null && daily.id.equals(x.dungeon());
            case "CLEAR_FEATURED" -> featured != null && featured.id.equals(x.dungeon());
            case "CLEAR_PARTY" -> x.partySize() >= Math.max(2, c.target());
            default -> false;
        };
    }

    // ------------------------------------------------------------ evaluation (one atomic transaction per player per clear)
    public CompletableFuture<Result> onClear(UUID id, RunCtx ctx) {
        DungeonDefinition daily = dailyDungeon(), featured = weeklyFeatured();
        List<Challenge> active = new ArrayList<>(activeDaily());
        active.addAll(activeWeekly());
        String dKey = "D:" + dayKey(), wKey = "W:" + weekKey();
        boolean season = seasonActive();
        String sid = seasonId;
        int pts = seasonPoints.getOrDefault(ctx.diff(), 10) * (ctx.raid() ? raidMult : 1);
        List<SeasonTier> tierList = List.copyOf(tiers);
        return plugin.db().tx(c -> {
            long total = 0;
            try (PreparedStatement ps = c.prepareStatement("SELECT COALESCE(SUM(clears),0) FROM clears WHERE uuid=?")) {
                ps.setString(1, id.toString());
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) total = rs.getLong(1); }
            }
            List<Ach> gotA = new ArrayList<>();
            for (Ach a : achs.values()) {
                if (!matches(a, ctx, total)) continue;
                try (PreparedStatement ps = c.prepareStatement("INSERT OR IGNORE INTO achievements(uuid,id,ts) VALUES(?,?,?)")) {
                    ps.setString(1, id.toString()); ps.setString(2, a.id()); ps.setLong(3, System.currentTimeMillis());
                    if (ps.executeUpdate() == 1) {
                        gotA.add(a);
                        if (a.reward() > 0) CurrencyService.add(c, id, a.reward(), "achievement:" + a.id());
                    }
                }
            }
            List<Challenge> gotC = new ArrayList<>();
            for (Challenge ch : active) {
                if (!matches(ch, ctx, daily, featured)) continue;
                String period = ch.weekly() ? wKey : dKey;
                int progress = 0; boolean done = false;
                try (PreparedStatement ps = c.prepareStatement("SELECT progress, done FROM challenge_progress WHERE uuid=? AND period=? AND cid=?")) {
                    ps.setString(1, id.toString()); ps.setString(2, period); ps.setString(3, ch.id());
                    try (ResultSet rs = ps.executeQuery()) { if (rs.next()) { progress = rs.getInt(1); done = rs.getInt(2) == 1; } }
                }
                if (done) continue;
                progress++;
                boolean nowDone = progress >= ch.target();
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO challenge_progress(uuid,period,cid,progress,done) VALUES(?,?,?,?,?) "
                                + "ON CONFLICT(uuid,period,cid) DO UPDATE SET progress=excluded.progress, done=excluded.done")) {
                    ps.setString(1, id.toString()); ps.setString(2, period); ps.setString(3, ch.id());
                    ps.setInt(4, progress); ps.setInt(5, nowDone ? 1 : 0); ps.executeUpdate();
                }
                if (nowDone) {
                    gotC.add(ch);
                    if (ch.reward() > 0) CurrencyService.add(c, id, ch.reward(), "challenge:" + ch.id() + ":" + period);
                }
            }
            List<SeasonTier> gotT = new ArrayList<>();
            if (season) {
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO season_points(uuid,season,points) VALUES(?,?,?) ON CONFLICT(uuid,season) DO UPDATE SET points = points + excluded.points")) {
                    ps.setString(1, id.toString()); ps.setString(2, sid); ps.setInt(3, pts); ps.executeUpdate();
                }
                int sp = 0;
                try (PreparedStatement ps = c.prepareStatement("SELECT points FROM season_points WHERE uuid=? AND season=?")) {
                    ps.setString(1, id.toString()); ps.setString(2, sid);
                    try (ResultSet rs = ps.executeQuery()) { if (rs.next()) sp = rs.getInt(1); }
                }
                for (SeasonTier t : tierList) {
                    if (sp < t.points()) break;
                    try (PreparedStatement ps = c.prepareStatement("INSERT OR IGNORE INTO season_claims(uuid,season,tier) VALUES(?,?,?)")) {
                        ps.setString(1, id.toString()); ps.setString(2, sid); ps.setString(3, t.id());
                        if (ps.executeUpdate() == 1) {
                            gotT.add(t);
                            if (t.currency() > 0) CurrencyService.add(c, id, t.currency(), "season:" + sid + ":" + t.id());
                            if (t.item() != null) InboxService.insert(c, id, t.item(), "season:" + sid);
                        }
                    }
                }
            }
            return new Result(gotA, gotC, gotT);
        });
    }

    // ------------------------------------------------------------ reads for menus
    public CompletableFuture<Set<String>> earned(UUID id) {
        return plugin.db().submit(c -> {
            Set<String> out = new HashSet<>();
            try (PreparedStatement ps = c.prepareStatement("SELECT id FROM achievements WHERE uuid=?")) {
                ps.setString(1, id.toString());
                try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(rs.getString(1)); }
            }
            return out;
        });
    }

    /** challenge id -> {progress, done} for the current day and week. */
    public CompletableFuture<Map<String, int[]>> progress(UUID id) {
        String dKey = "D:" + dayKey(), wKey = "W:" + weekKey();
        return plugin.db().submit(c -> {
            Map<String, int[]> out = new HashMap<>();
            try (PreparedStatement ps = c.prepareStatement("SELECT cid, progress, done FROM challenge_progress WHERE uuid=? AND period IN (?,?)")) {
                ps.setString(1, id.toString()); ps.setString(2, dKey); ps.setString(3, wKey);
                try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.put(rs.getString(1), new int[]{rs.getInt(2), rs.getInt(3)}); }
            }
            return out;
        });
    }

    public CompletableFuture<SeasonView> seasonView(UUID id) {
        String sid = seasonId;
        return plugin.db().submit(c -> {
            int pts = 0;
            Set<String> claimed = new HashSet<>();
            try (PreparedStatement ps = c.prepareStatement("SELECT points FROM season_points WHERE uuid=? AND season=?")) {
                ps.setString(1, id.toString()); ps.setString(2, sid);
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) pts = rs.getInt(1); }
            }
            try (PreparedStatement ps = c.prepareStatement("SELECT tier FROM season_claims WHERE uuid=? AND season=?")) {
                ps.setString(1, id.toString()); ps.setString(2, sid);
                try (ResultSet rs = ps.executeQuery()) { while (rs.next()) claimed.add(rs.getString(1)); }
            }
            return new SeasonView(pts, claimed);
        });
    }
}
