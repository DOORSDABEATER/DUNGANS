package net.des.vyrnth.data;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.dungeon.Difficulty;
import net.des.vyrnth.dungeon.DungeonDefinition;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/** Completion records, difficulty unlocks, best times. No levels, no classes: achievement-style records only. */
public final class ProgressionService {
    public record ClearResult(boolean firstClear, boolean newBest, long totalClears, long bestMs, long currency, boolean serverFirst) {}
    public record TopEntry(UUID player, long bestMs) {}

    private final VyrnthPlugin plugin;
    private final Database db;
    private final Map<UUID, Map<String, long[]>> cache = new ConcurrentHashMap<>(); // key -> {clears, bestMs}

    public ProgressionService(VyrnthPlugin plugin, Database db) { this.plugin = plugin; this.db = db; }

    private static String key(String dungeon, Difficulty d) { return dungeon + "|" + d.name(); }

    public void load(UUID id) {
        db.submit(c -> {
            Map<String, long[]> m = new HashMap<>();
            try (PreparedStatement ps = c.prepareStatement("SELECT dungeon, difficulty, clears, best_ms FROM clears WHERE uuid = ?")) {
                ps.setString(1, id.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) m.put(rs.getString(1) + "|" + rs.getString(2), new long[]{rs.getLong(3), rs.getLong(4)});
                }
            }
            return m;
        }).whenComplete((m, err) -> {
            if (err != null) { plugin.getLogger().warning("Progress load failed for " + id + ": " + err); return; }
            cache.put(id, new ConcurrentHashMap<>(m));
        });
    }

    public void unload(UUID id) { cache.remove(id); }
    public boolean loaded(UUID id) { return cache.containsKey(id); }

    public long[] record(UUID id, String dungeon, Difficulty d) {
        Map<String, long[]> m = cache.get(id);
        return m == null ? null : m.get(key(dungeon, d));
    }

    public boolean isUnlocked(UUID id, DungeonDefinition def, Difficulty d) {
        Map<String, long[]> m = cache.get(id);
        if (m == null) return false;
        if (!def.requires.isBlank()) {
            boolean any = false;
            for (Difficulty x : Difficulty.values()) any |= m.containsKey(key(def.requires, x));
            if (!any) return false;
        }
        Difficulty prev = d.previous();
        return prev == null || m.containsKey(key(def.id, prev));
    }

    /**
     * One transaction: claims the run reward slot (idempotent per run+player), updates records,
     * credits currency and stores loot in the inbox. Returns null if this run was already rewarded.
     */
    public CompletableFuture<ClearResult> recordClear(UUID id, UUID runId, String dungeon, Difficulty d,
                                                      long ms, long base, long firstBonus, List<byte[]> items) {
        return db.tx(c -> {
            try (PreparedStatement ps = c.prepareStatement("INSERT OR IGNORE INTO run_rewards(run_id, uuid) VALUES(?,?)")) {
                ps.setString(1, runId.toString()); ps.setString(2, id.toString());
                if (ps.executeUpdate() == 0) return null;
            }
            boolean first = true; long clears = 0, best = 0;
            try (PreparedStatement ps = c.prepareStatement("SELECT clears, best_ms FROM clears WHERE uuid=? AND dungeon=? AND difficulty=?")) {
                ps.setString(1, id.toString()); ps.setString(2, dungeon); ps.setString(3, d.name());
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) { first = false; clears = rs.getLong(1); best = rs.getLong(2); } }
            }
            boolean newBest = first || ms < best;
            long bestMs = newBest ? ms : best;
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO clears(uuid, dungeon, difficulty, clears, best_ms, first_ts) VALUES(?,?,?,1,?,?) "
                            + "ON CONFLICT(uuid, dungeon, difficulty) DO UPDATE SET clears = clears + 1, best_ms = ?")) {
                ps.setString(1, id.toString()); ps.setString(2, dungeon); ps.setString(3, d.name());
                ps.setLong(4, bestMs); ps.setLong(5, System.currentTimeMillis()); ps.setLong(6, bestMs);
                ps.executeUpdate();
            }
            boolean serverFirst = false;
            try (PreparedStatement ps = c.prepareStatement("INSERT OR IGNORE INTO server_firsts(dungeon,difficulty,uuid,ts) VALUES(?,?,?,?)")) {
                ps.setString(1, dungeon); ps.setString(2, d.name()); ps.setString(3, id.toString()); ps.setLong(4, System.currentTimeMillis());
                serverFirst = ps.executeUpdate() == 1;
            }
            long award = base + (first ? firstBonus : 0);
            if (award > 0) CurrencyService.add(c, id, award, "clear:" + dungeon + ":" + d.name());
            for (byte[] item : items) {
                try (PreparedStatement ps = c.prepareStatement("INSERT INTO inbox(uuid, item, source, ts) VALUES(?,?,?,?)")) {
                    ps.setString(1, id.toString()); ps.setBytes(2, item); ps.setString(3, "clear:" + dungeon);
                    ps.setLong(4, System.currentTimeMillis()); ps.executeUpdate();
                }
            }
            return new ClearResult(first, newBest, clears + 1, bestMs, award, serverFirst);
        }).whenComplete((res, err) -> {
            if (res != null) {
                Map<String, long[]> m = cache.get(id);
                if (m != null) m.put(key(dungeon, d), new long[]{res.totalClears(), res.bestMs()});
            }
        });
    }

    /** Pays a secret once per player, ever (INSERT OR IGNORE gates the reward). @return true if this was the first discovery. */
    public CompletableFuture<Boolean> recordSecret(UUID id, String dungeon, String secret, long reward, byte[] item) {
        return db.tx(c -> {
            try (PreparedStatement ps = c.prepareStatement("INSERT OR IGNORE INTO secrets_found(uuid,dungeon,secret_id,ts) VALUES(?,?,?,?)")) {
                ps.setString(1, id.toString()); ps.setString(2, dungeon); ps.setString(3, secret); ps.setLong(4, System.currentTimeMillis());
                if (ps.executeUpdate() == 0) return false;
            }
            if (reward > 0) CurrencyService.add(c, id, reward, "secret:" + dungeon + ":" + secret);
            if (item != null) InboxService.insert(c, id, item, "secret:" + secret);
            return true;
        });
    }

    /** "dungeon|secretId" for every secret/data log this player has ever found. */
    public CompletableFuture<Set<String>> secretsFound(UUID id) {
        return db.submit(c -> {
            Set<String> out = new HashSet<>();
            try (PreparedStatement ps = c.prepareStatement("SELECT dungeon, secret_id FROM secrets_found WHERE uuid=?")) {
                ps.setString(1, id.toString());
                try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(rs.getString(1) + "|" + rs.getString(2)); }
            }
            return out;
        });
    }

    public CompletableFuture<List<TopEntry>> top(String dungeon, Difficulty d, int limit) {
        return db.submit(c -> {
            List<TopEntry> out = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT uuid, best_ms FROM clears WHERE dungeon=? AND difficulty=? AND best_ms IS NOT NULL ORDER BY best_ms ASC LIMIT ?")) {
                ps.setString(1, dungeon); ps.setString(2, d.name()); ps.setInt(3, limit);
                try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(new TopEntry(UUID.fromString(rs.getString(1)), rs.getLong(2))); }
            }
            return out;
        });
    }

    public CompletableFuture<List<String>> summary(UUID id) {
        return db.submit(c -> {
            List<String> out = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement("SELECT dungeon, difficulty, clears, best_ms FROM clears WHERE uuid=? ORDER BY dungeon, difficulty")) {
                ps.setString(1, id.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) out.add(rs.getString(1) + " " + rs.getString(2) + ": " + rs.getLong(3) + " clears, best " + rs.getLong(4) / 1000 + "s");
                }
            }
            return out;
        });
    }
}
