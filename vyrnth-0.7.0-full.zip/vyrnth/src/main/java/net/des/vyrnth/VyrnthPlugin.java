package net.des.vyrnth;

import net.des.vyrnth.command.VyrnthCommand;
import net.des.vyrnth.data.*;
import net.des.vyrnth.dungeon.*;
import net.des.vyrnth.economy.GachaService;
import net.des.vyrnth.economy.ShopService;
import net.des.vyrnth.hub.*;
import net.des.vyrnth.instance.InstanceListener;
import net.des.vyrnth.instance.InstanceManager;
import net.des.vyrnth.integration.MythicHook;
import net.des.vyrnth.live.LiveContentService;
import net.des.vyrnth.party.PartyCommand;
import net.des.vyrnth.party.PartyManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.command.RemoteConsoleCommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.List;
import java.util.logging.Level;

public final class VyrnthPlugin extends JavaPlugin {
    private Database db;
    private CurrencyService currency;
    private ProgressionService progression;
    private InboxService inbox;
    private DungeonRegistry dungeons;
    private LootService loot;
    private PartyManager parties;
    private InstanceManager instances;
    private EntryService entry;
    private MenuService menus;
    private PortalService portals;
    private MythicHook mythic;
    private ShopService shop;
    private GachaService gacha;
    private LiveContentService live;
    private net.des.vyrnth.hub.MatchmakingService matchmaking;
    private net.des.vyrnth.hub.HubSecrets hubSecrets;
    private net.des.vyrnth.build.MapBuilder mapBuilder;
    private net.des.vyrnth.hub.PracticeService practice;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "dungeons.yml").exists()) saveResource("dungeons.yml", false);
        try { db = new Database(new File(getDataFolder(), "vyrnth.db")); }
        catch (Exception e) {
            getLogger().log(Level.SEVERE, "Database init failed; disabling VYRNTH", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        mythic = new MythicHook();
        currency = new CurrencyService(db);
        progression = new ProgressionService(this, db);
        inbox = new InboxService(this, db);
        dungeons = new DungeonRegistry(this); dungeons.reload();
        loot = new LootService(this);
        shop = new ShopService(this); shop.reload();
        gacha = new GachaService(this); gacha.reload();
        live = new LiveContentService(this); live.reload();
        parties = new PartyManager(this);
        instances = new InstanceManager(this);
        entry = new EntryService(this);
        matchmaking = new net.des.vyrnth.hub.MatchmakingService(this);
        menus = new MenuService(this);
        portals = new PortalService(this); portals.reload();

        var pm = getServer().getPluginManager();
        pm.registerEvents(new InstanceListener(this), this);
        pm.registerEvents(new MenuListener(this), this);
        mapBuilder = new net.des.vyrnth.build.MapBuilder(this); mapBuilder.reload();
        practice = new net.des.vyrnth.hub.PracticeService(this);
        hubSecrets = new net.des.vyrnth.hub.HubSecrets(this); hubSecrets.reload();
        pm.registerEvents(hubSecrets, this);
        pm.registerEvents(portals, this);

        VyrnthCommand admin = new VyrnthCommand(this);
        getCommand("vyrnth").setExecutor(admin);
        getCommand("vyrnth").setTabCompleter(admin);
        PartyCommand party = new PartyCommand(this);
        getCommand("party").setExecutor(party);
        getCommand("party").setTabCompleter(party);

        instances.purgeLeftovers();
        Bukkit.getScheduler().runTaskTimer(this, instances::tick, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, instances::fastTick, 4L, 4L);
        Bukkit.getScheduler().runTaskTimer(this, matchmaking::tick, 40L, 40L);
        for (Player p : Bukkit.getOnlinePlayers()) progression.load(p.getUniqueId());

        getLogger().info("VYRNTH enabled. MythicMobs=" + mythic.present()
                + " ModelEngine=" + pm.isPluginEnabled("ModelEngine") + " Sift=" + pm.isPluginEnabled("Sift"));
        if (!mythic.present()) getLogger().warning("MythicMobs missing: bosses cannot spawn.");
    }

    @Override
    public void onDisable() {
        if (practice != null) practice.shutdown();
        if (instances != null) instances.shutdown();
        if (db != null) db.close();
    }

    // ------------------------------------------------------------ accessors
    public Database db() { return db; }
    public CurrencyService currency() { return currency; }
    public ProgressionService progression() { return progression; }
    public InboxService inbox() { return inbox; }
    public DungeonRegistry dungeons() { return dungeons; }
    public LootService loot() { return loot; }
    public PartyManager parties() { return parties; }
    public InstanceManager instances() { return instances; }
    public EntryService entry() { return entry; }
    public MenuService menus() { return menus; }
    public PortalService portals() { return portals; }
    public MythicHook mythic() { return mythic; }
    public ShopService shop() { return shop; }
    public GachaService gacha() { return gacha; }
    public LiveContentService live() { return live; }
    public net.des.vyrnth.hub.MatchmakingService matchmaking() { return matchmaking; }
    public net.des.vyrnth.hub.HubSecrets hubSecrets() { return hubSecrets; }
    public net.des.vyrnth.build.MapBuilder mapBuilder() { return mapBuilder; }
    public net.des.vyrnth.hub.PracticeService practice() { return practice; }

    /** Raids (and any dungeon with `days:`) are only open on their scheduled UTC days unless an admin overrides it. */
    public List<String> openDays(DungeonDefinition def) {
        List<String> o = getConfig().getStringList("schedule-override." + def.id);
        return o.isEmpty() ? def.days : o;
    }

    public boolean openToday(DungeonDefinition def) {
        List<String> days = openDays(def);
        if (days.isEmpty()) return true;
        for (String d : days) if (d.equalsIgnoreCase("ALWAYS")) return true;
        String today = java.time.LocalDate.now(java.time.ZoneOffset.UTC).getDayOfWeek().name();
        for (String d : days) if (d.equalsIgnoreCase(today)) return true;
        return false;
    }

    // ------------------------------------------------------------ helpers
    public void sync(Runnable r) { if (isEnabled()) Bukkit.getScheduler().runTask(this, r); }

    /** OP-only. A permission plugin granting vyrnth.* does NOT make someone an admin. */
    public static boolean isAdmin(CommandSender s) {
        if (s instanceof Player p) return p.isOp();
        return s instanceof ConsoleCommandSender || s instanceof RemoteConsoleCommandSender;
    }

    public boolean maintenance() { return getConfig().getBoolean("maintenance", false); }
    public void setMaintenance(boolean on) { getConfig().set("maintenance", on); saveConfig(); }
    public String currencyName() { return getConfig().getString("currency-name", "Vyrn Shards"); }
    public int livesFor(Difficulty d) { return getConfig().getInt("difficulty." + d.name() + ".lives", 3); }
    public double rewardMultiplier(Difficulty d) { return getConfig().getDouble("difficulty." + d.name() + ".reward-multiplier", 1.0); }
    public int bonusRolls(Difficulty d) { return getConfig().getInt("difficulty." + d.name() + ".bonus-rolls", 0); }

    public Location readLocation(String path) {
        ConfigurationSection s = getConfig().getConfigurationSection(path);
        if (s == null) return null;
        World w = Bukkit.getWorld(s.getString("world", ""));
        if (w == null) return null;
        return new Location(w, s.getDouble("x"), s.getDouble("y"), s.getDouble("z"), (float) s.getDouble("yaw"), (float) s.getDouble("pitch"));
    }

    public void writeLocation(String path, Location l) {
        getConfig().set(path + ".world", l.getWorld().getName());
        getConfig().set(path + ".x", l.getX()); getConfig().set(path + ".y", l.getY()); getConfig().set(path + ".z", l.getZ());
        getConfig().set(path + ".yaw", l.getYaw()); getConfig().set(path + ".pitch", l.getPitch());
        saveConfig();
    }

    public Location hubSpawn() {
        Location l = readLocation("hub.spawn");
        return l != null ? l : Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    public Location lobbySpawn() {
        Location l = readLocation("lobby.spawn");
        return l != null ? l : Bukkit.getWorlds().get(0).getSpawnLocation();
    }
}
