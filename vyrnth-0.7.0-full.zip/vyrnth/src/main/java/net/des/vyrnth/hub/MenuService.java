package net.des.vyrnth.hub;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.data.InboxService;
import net.des.vyrnth.dungeon.Difficulty;
import net.des.vyrnth.dungeon.DungeonDefinition;
import net.des.vyrnth.economy.GachaService;
import net.des.vyrnth.economy.ShopService;
import net.des.vyrnth.instance.Instance;
import net.des.vyrnth.live.LiveContentService;
import net.des.vyrnth.party.PartyManager.Party;
import net.des.vyrnth.util.Items;
import net.des.vyrnth.util.Msg;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;

public final class MenuService {
    private final VyrnthPlugin plugin;

    public MenuService(VyrnthPlugin plugin) { this.plugin = plugin; }

    public void openDungeon(Player p, DungeonDefinition def) {
        UUID id = p.getUniqueId();
        Menu m = new Menu(Msg.c("<#2DD4BF><bold>" + def.display), 4);
        Party party = plugin.parties().of(id);
        String partyLine = party == null ? "Solo run" : "Party of " + party.members.size()
                + (party.leader.equals(id) ? " (you lead)" : " (leader launches)");
        boolean open = plugin.openToday(def);
        boolean enabled = plugin.dungeons().isEnabled(def.id) && !plugin.maintenance() && open;
        m.set(4, Items.make(Material.NETHER_STAR, "<white><bold>" + def.display,
                "Players: " + def.minPlayers + "-" + def.maxPlayers, partyLine,
                def.raid ? "<light_purple>RAID" : "",
                open ? "" : "<red>Open on: " + String.join(", ", plugin.openDays(def)) + " (UTC)",
                enabled ? "" : "<red>Currently unavailable"), null);
        if (!plugin.progression().loaded(id)) {
            m.set(13, Items.make(Material.CLOCK, "<yellow>Loading your records...", "Re-open the gateway in a moment."), null);
            m.open(p);
            return;
        }
        int[] slots = {10, 12, 14, 16};
        for (Difficulty d : Difficulty.values()) {
            boolean unlocked = plugin.progression().isUnlocked(id, def, d);
            int slot = slots[d.ordinal()];
            if (!unlocked) {
                String need = d.previous() != null ? "Clear " + d.previous().display + " to unlock." : "Locked by dungeon requirement.";
                m.set(slot, Items.make(Material.BARRIER, "<red>" + d.display + " <dark_gray>(locked)", need), null);
                continue;
            }
            int lives = plugin.livesFor(d);
            long[] rec = plugin.progression().record(id, def.id, d);
            ItemStack it = Items.make(d.icon, d.color + "<bold>" + d.display,
                    "Lives: " + (lives < 0 ? "unlimited" : String.valueOf(lives)),
                    "Rewards: x" + plugin.rewardMultiplier(d) + ", +" + plugin.bonusRolls(d) + " bonus loot rolls",
                    rec == null ? "Not cleared yet" : "Clears: " + rec[0] + " · Best: " + Msg.fmt(rec[1]),
                    "", enabled ? "<yellow>Click to launch" : "<red>Unavailable");
            m.set(slot, it, enabled ? pl -> { pl.closeInventory(); plugin.entry().request(pl, def, d); } : null);
            if (enabled && def.maxPlayers > 1 && party == null) {
                int waiting = plugin.matchmaking().size(def.id, d);
                boolean inQ = plugin.matchmaking().queued(id);
                m.set(slot + 9, Items.make(Material.COMPASS, inQ ? "<red>Leave group finder" : "<aqua>Find a group",
                        d.display + " · " + waiting + " waiting", "Matches you with other players."), pl -> {
                    pl.closeInventory();
                    if (plugin.matchmaking().queued(pl.getUniqueId())) { plugin.matchmaking().leave(pl.getUniqueId()); Msg.send(pl, "Left the group finder."); }
                    else {
                        String err = plugin.matchmaking().join(pl, def, d);
                        Msg.send(pl, err != null ? "<red>" + err : "<green>Searching for a group... (" + plugin.matchmaking().size(def.id, d) + " waiting)");
                    }
                });
            }
        }
        m.open(p);
    }

    public void openReady(Player p, DungeonDefinition def, Difficulty d) {
        Menu m = new Menu(Msg.c("<#2DD4BF><bold>READY CHECK"), 3);
        m.set(4, Items.make(Material.NETHER_STAR, "<white>" + def.display, d.color + d.display), null);
        m.set(11, Items.make(Material.LIME_CONCRETE, "<green><bold>READY"), pl -> { pl.closeInventory(); plugin.entry().respond(pl, true); });
        m.set(15, Items.make(Material.RED_CONCRETE, "<red><bold>DECLINE"), pl -> { pl.closeInventory(); plugin.entry().respond(pl, false); });
        m.open(p);
    }

    public void openAbandon(Player p) {
        Menu m = new Menu(Msg.c("<red><bold>Abandon expedition?"), 3);
        m.set(4, Items.make(Material.NETHER_STAR, "<white>This cannot be undone", "You forfeit rewards and cannot rejoin."), null);
        m.set(11, Items.make(Material.RED_CONCRETE, "<red><bold>ABANDON"), pl -> {
            pl.closeInventory();
            Instance i = plugin.instances().of(pl.getUniqueId());
            if (i != null) plugin.instances().leave(i, pl.getUniqueId(), "abandoned");
        });
        m.set(15, Items.make(Material.LIME_CONCRETE, "<green><bold>STAY"), Player::closeInventory);
        m.open(p);
    }

    public void openInbox(Player p) {
        plugin.inbox().list(p.getUniqueId()).thenAccept(entries -> plugin.sync(() -> {
            if (!p.isOnline()) return;
            Menu m = new Menu(Msg.c("<#2DD4BF><bold>Reward Collection"), 6);
            if (entries.isEmpty()) m.set(22, Items.make(Material.BARRIER, "<gray>Nothing to collect"), null);
            int slot = 0;
            for (InboxService.Entry e : entries) {
                ItemStack it = ItemStack.deserializeBytes(e.data());
                ItemStack shown = it.clone();
                var meta = shown.getItemMeta();
                var lore = meta.lore() == null ? new java.util.ArrayList<net.kyori.adventure.text.Component>() : new java.util.ArrayList<>(meta.lore());
                lore.add(Msg.c("<yellow>Click to claim"));
                meta.lore(lore);
                shown.setItemMeta(meta);
                long rowId = e.id();
                m.set(slot++, shown, pl -> plugin.inbox().claimAndGive(pl, rowId, () -> openInbox(pl)));
            }
            m.open(p);
        }));
    }

    // ------------------------------------------------------------ shop
    public void openShop(Player p) {
        plugin.currency().balance(p.getUniqueId()).thenAccept(bal -> plugin.sync(() -> {
            if (!p.isOnline()) return;
            Menu m = new Menu(Msg.c("<#2DD4BF><bold>Dungeon Shop"), 4);
            m.set(4, Items.make(Material.AMETHYST_SHARD, "<white>Balance: <aqua>" + bal + " " + plugin.currencyName(),
                    "Rotating stock changes daily (UTC)."), null);
            int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
            int n = 0;
            for (ShopService.Item it : plugin.shop().available()) {
                if (n >= slots.length) break;
                ItemStack icon = Items.make(it.icon(), "<white>" + it.display(),
                        "Price: " + it.price() + " " + plugin.currencyName(),
                        it.dailyLimit() > 0 ? "Limit: " + it.dailyLimit() + " per day" : "No limit",
                        it.rotating() ? "<light_purple>Today's rotation" : "",
                        it.untilMs() > 0 ? "<gold>Limited time" : "", "<yellow>Click to buy");
                String key = it.key();
                m.set(slots[n++], icon, pl -> plugin.shop().buy(pl, key, () -> openShop(pl)));
            }
            m.open(p);
        }));
    }

    // ------------------------------------------------------------ gacha
    public void openGachaSelect(Player p) {
        Menu m = new Menu(Msg.c("<#2DD4BF><bold>Gacha Chamber"), 3);
        int slot = 10;
        for (GachaService.Pool pool : plugin.gacha().pools()) {
            if (slot > 16) break;
            String id = pool.id();
            m.set(slot++, Items.make(Material.END_CRYSTAL, "<light_purple><bold>" + pool.display(),
                    "Single: " + pool.cost() + " · x" + pool.multi() + ": " + pool.multiCost(), "<yellow>Click to open"),
                    pl -> openGacha(pl, id));
        }
        m.open(p);
    }

    public void openGacha(Player p, String poolId) {
        GachaService.Pool pool = plugin.gacha().pool(poolId);
        if (pool == null) { Msg.send(p, "<red>This chamber is not linked to a reward pool."); return; }
        UUID id = p.getUniqueId();
        plugin.currency().balance(id).thenCombine(plugin.gacha().pity(id, pool), (bal, pity) -> new long[]{bal, pity})
                .thenAccept(v -> plugin.sync(() -> {
                    if (!p.isOnline()) return;
                    Menu m = new Menu(Msg.c("<light_purple><bold>" + pool.display()), 3);
                    m.set(4, Items.make(Material.AMETHYST_SHARD, "<white>Balance: <aqua>" + v[0] + " " + plugin.currencyName(),
                            pool.pity() > 0 ? "Pity: " + v[1] + "/" + pool.pity() + " (rare guaranteed at the cap)" : "No pity"), null);
                    m.set(11, Items.make(Material.LIME_CONCRETE, "<green><bold>Draw x1", "Cost: " + pool.cost()), pl -> draw(pl, pool, 1));
                    m.set(13, Items.make(Material.BOOK, "<white><bold>View odds", "Exact drop chances for every reward."), pl -> openOdds(pl, pool));
                    m.set(15, Items.make(Material.GOLD_BLOCK, "<gold><bold>Draw x" + pool.multi(), "Cost: " + pool.multiCost()), pl -> draw(pl, pool, pool.multi()));
                    m.open(p);
                }));
    }

    private void draw(Player p, GachaService.Pool pool, int times) {
        p.closeInventory();
        plugin.gacha().draw(p.getUniqueId(), pool, times).whenComplete((o, err) -> plugin.sync(() -> {
            if (err != null) { plugin.getLogger().log(java.util.logging.Level.SEVERE, "Gacha draw failed", err); Msg.send(p, "<red>Draw failed. Nothing was charged."); return; }
            if (o.error() != null) { Msg.send(p, "<red>Not enough " + plugin.currencyName() + "."); return; }
            plugin.gacha().announce(p, pool, o);
        }));
    }

    public void openOdds(Player p, GachaService.Pool pool) {
        Menu m = new Menu(Msg.c("<white><bold>Odds: " + pool.display()), 3);
        double total = pool.total();
        int slot = 0;
        for (GachaService.Entry e : pool.entries()) {
            if (slot > 26) break;
            ItemStack icon = ItemStack.deserializeBytes(e.data()).clone();
            var meta = icon.getItemMeta();
            meta.displayName(Msg.c((e.rare() ? "<gold>" : "<white>") + e.display()).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
            meta.lore(List.of(
                    Msg.c(String.format("<gray>Chance: <white>%.2f%%", e.weight() / total * 100)).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false),
                    Msg.c(e.rare() ? "<gold>Rare (counts for pity)" : "<gray>Common").decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false),
                    Msg.c(e.unique() ? "<gray>Unique: duplicates refund " + e.refund() : "<gray>Repeatable").decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false)));
            icon.setItemMeta(meta);
            m.set(slot++, icon, null);
        }
        m.open(p);
    }

    // ------------------------------------------------------------ challenges & achievements
    private static String bar(int v, int max) {
        int filled = (int) Math.round(10.0 * Math.min(v, max) / max);
        return "<green>" + "|".repeat(filled) + "<dark_gray>" + "|".repeat(10 - filled) + " <gray>" + Math.min(v, max) + "/" + max;
    }

    public void openChallenges(Player p) {
        plugin.live().progress(p.getUniqueId()).thenAccept(prog -> plugin.sync(() -> {
            if (!p.isOnline()) return;
            LiveContentService live = plugin.live();
            Menu m = new Menu(Msg.c("<#2DD4BF><bold>Challenge Board"), 4);
            DungeonDefinition daily = live.dailyDungeon(), feat = live.weeklyFeatured();
            m.set(4, Items.make(Material.COMPASS, "<white><bold>Today's rotation",
                    "Daily dungeon: " + (daily == null ? "none" : daily.display) + " <green>(+" + Math.round(plugin.getConfig().getDouble("live.daily-dungeon-bonus", 0.25) * 100) + "%)",
                    "Weekly featured: " + (feat == null ? "none" : feat.display) + " <green>(+" + Math.round(plugin.getConfig().getDouble("live.weekly-featured-bonus", 0.5) * 100) + "%)",
                    "Resets daily/weekly at 00:00 UTC."), null);
            int slot = 9;
            for (boolean weekly : new boolean[]{false, true}) {
                for (var ch : weekly ? live.activeWeekly() : live.activeDaily()) {
                    int[] pr = prog.getOrDefault(ch.id(), new int[]{0, 0});
                    boolean done = pr[1] == 1;
                    m.set(slot++, Items.make(done ? Material.LIME_DYE : weekly ? Material.PURPLE_DYE : Material.YELLOW_DYE,
                            (done ? "<green>✔ " : weekly ? "<light_purple>" : "<yellow>") + ch.display(),
                            weekly ? "Weekly" : "Daily", bar(pr[0], ch.target()), "Reward: " + ch.reward() + " " + plugin.currencyName()), null);
                }
                slot = 18;
            }
            m.open(p);
        }));
    }

    public void openAchievements(Player p) {
        plugin.live().earned(p.getUniqueId()).thenAccept(got -> plugin.sync(() -> {
            if (!p.isOnline()) return;
            Menu m = new Menu(Msg.c("<#2DD4BF><bold>Achievement Gallery <gray>(" + got.size() + "/" + plugin.live().achievements().size() + ")"), 6);
            int slot = 0;
            for (var a : plugin.live().achievements()) {
                if (slot > 53) break;
                boolean have = got.contains(a.id());
                if (have) m.set(slot++, Items.make(Material.NETHER_STAR, "<gold><bold>" + a.display(), a.desc(), "Reward: " + a.reward() + " " + plugin.currencyName()), null);
                else if (a.hidden()) m.set(slot++, Items.make(Material.GRAY_DYE, "<dark_gray>???", "A hidden achievement."), null);
                else m.set(slot++, Items.make(Material.GRAY_DYE, "<gray>" + a.display(), a.desc(), "Reward: " + a.reward() + " " + plugin.currencyName()), null);
            }
            m.open(p);
        }));
    }

    // ------------------------------------------------------------ leaderboards
    public void openLeaderboards(Player p) {
        Menu m = new Menu(Msg.c("<#2DD4BF><bold>Leaderboards"), 3);
        int slot = 0;
        for (DungeonDefinition def : plugin.dungeons().all()) {
            if (slot > 17) break;
            m.set(slot++, Items.make(def.raid ? Material.DRAGON_HEAD : Material.NETHER_STAR, "<white>" + def.display, "Fastest clears", "<yellow>Click"), pl -> openBoardDifficulty(pl, def));
        }
        m.open(p);
    }

    private void openBoardDifficulty(Player p, DungeonDefinition def) {
        Menu m = new Menu(Msg.c("<#2DD4BF><bold>" + def.display), 3);
        int[] slots = {10, 12, 14, 16};
        for (Difficulty d : Difficulty.values())
            m.set(slots[d.ordinal()], Items.make(d.icon, d.color + "<bold>" + d.display, "Top 10 fastest times"), pl -> showBoard(pl, def, d));
        m.set(22, Items.make(Material.ARROW, "<gray>Back"), this::openLeaderboards);
        m.open(p);
    }

    private void showBoard(Player p, DungeonDefinition def, Difficulty d) {
        plugin.progression().top(def.id, d, 10).thenAccept(list -> plugin.sync(() -> {
            if (!p.isOnline()) return;
            Menu m = new Menu(Msg.c("<#2DD4BF><bold>" + def.display + " · " + d.display), 3);
            if (list.isEmpty()) m.set(13, Items.make(Material.BARRIER, "<gray>No clears yet"), null);
            int n = 0;
            for (var e : list) {
                String name = String.valueOf(plugin.getServer().getOfflinePlayer(e.player()).getName());
                m.set(n, Items.make(n == 0 ? Material.GOLD_INGOT : n < 3 ? Material.IRON_INGOT : Material.COPPER_INGOT, "<white>#" + (n + 1) + " " + name, "Best: " + Msg.fmt(e.bestMs())), null);
                n++;
            }
            m.set(22, Items.make(Material.ARROW, "<gray>Back"), pl -> openBoardDifficulty(pl, def));
            m.open(p);
        }));
    }

    // ------------------------------------------------------------ personal statistics
    public void openStats(Player p) {
        UUID id = p.getUniqueId();
        plugin.currency().balance(id).thenCombine(plugin.live().earned(id), (bal, earned) -> new Object[]{bal, earned})
                .thenCombine(plugin.progression().secretsFound(id), (a, secrets) -> new Object[]{a[0], a[1], secrets})
                .thenAccept(v -> plugin.sync(() -> {
                    if (!p.isOnline()) return;
                    Menu m = new Menu(Msg.c("<#2DD4BF><bold>Personal Statistics"), 3);
                    m.set(10, Items.make(Material.AMETHYST_SHARD, "<aqua>" + plugin.currencyName(), "Balance: " + v[0]), null);
                    m.set(11, Items.make(Material.NETHER_STAR, "<gold>Achievements", ((java.util.Set<?>) v[1]).size() + "/" + plugin.live().achievements().size()), null);
                    m.set(12, Items.make(Material.ENDER_EYE, "<light_purple>Secrets found", String.valueOf(((java.util.Set<?>) v[2]).size())), null);
                    List<String> lines = new java.util.ArrayList<>();
                    for (DungeonDefinition def : plugin.dungeons().all())
                        for (Difficulty d : Difficulty.values()) {
                            long[] r = plugin.progression().record(id, def.id, d);
                            if (r != null && lines.size() < 14) lines.add(def.id + " " + d.display + ": " + r[0] + "x · best " + Msg.fmt(r[1]));
                        }
                    if (lines.isEmpty()) lines.add("No clears yet.");
                    m.set(14, Items.make(Material.WRITABLE_BOOK, "<white>Records", lines.toArray(new String[0])), null);
                    m.open(p);
                }));
    }

    // ------------------------------------------------------------ boss trophies
    public void openTrophies(Player p) {
        UUID id = p.getUniqueId();
        Menu m = new Menu(Msg.c("<#2DD4BF><bold>Boss Trophies"), 3);
        int slot = 0;
        for (DungeonDefinition def : plugin.dungeons().all()) {
            if (def.bossName.isBlank() || slot > 26) continue;
            List<String> won = new java.util.ArrayList<>();
            long best = Long.MAX_VALUE;
            for (Difficulty d : Difficulty.values()) {
                long[] r = plugin.progression().record(id, def.id, d);
                if (r != null) { won.add(d.display); best = Math.min(best, r[1]); }
            }
            if (won.isEmpty()) m.set(slot++, Items.make(Material.GRAY_DYE, "<dark_gray>???", "Defeat the boss of " + def.display + "."), null);
            else m.set(slot++, Items.make(def.raid ? Material.DRAGON_HEAD : Material.WITHER_SKELETON_SKULL, "<gold><bold>" + def.bossName,
                    def.display, "Defeated on: " + String.join(", ", won), "Best: " + Msg.fmt(best)), null);
        }
        m.open(p);
    }

    // ------------------------------------------------------------ lore archive
    public void openLore(Player p) {
        plugin.progression().secretsFound(p.getUniqueId()).thenAccept(found -> plugin.sync(() -> {
            if (!p.isOnline()) return;
            Menu m = new Menu(Msg.c("<#2DD4BF><bold>Lore Archive"), 6);
            int slot = 0;
            for (DungeonDefinition def : plugin.dungeons().all())
                for (var sec : def.layout.secrets) {
                    if (!sec.type().equals("DATA_LOG") || slot > 53) continue;
                    if (found.contains(def.id + "|" + sec.id())) {
                        m.set(slot++, Items.make(Material.WRITTEN_BOOK, "<aqua>" + sec.title(), def.display, "<yellow>Click to read"), pl -> {
                            pl.closeInventory();
                            pl.sendMessage(Msg.c("<aqua><bold>" + sec.title()));
                            for (String line : sec.text()) pl.sendMessage(Msg.c("<dark_aqua>▎ <gray>" + line));
                        });
                    } else m.set(slot++, Items.make(Material.GRAY_DYE, "<dark_gray>Undiscovered log", def.display), null);
                }
            m.open(p);
        }));
    }

    // ------------------------------------------------------------ seasonal track
    public void openSeason(Player p) {
        LiveContentService live = plugin.live();
        if (!live.seasonActive()) {
            Menu m = new Menu(Msg.c("<#2DD4BF><bold>Season"), 3);
            m.set(13, Items.make(Material.BARRIER, "<gray>No season is running right now."), null);
            m.open(p);
            return;
        }
        live.seasonView(p.getUniqueId()).thenAccept(view -> plugin.sync(() -> {
            if (!p.isOnline()) return;
            Menu m = new Menu(Msg.c("<#2DD4BF><bold>" + live.seasonName()), 3);
            long days = Math.max(0, (live.seasonEndMs() - System.currentTimeMillis()) / 86_400_000L);
            m.set(4, Items.make(Material.CLOCK, "<white>Season points: <aqua>" + view.points(), "Earned from clears (more on higher difficulty, x3 in raids).", "Ends in " + days + " day(s)."), null);
            int slot = 9;
            for (var t : live.seasonTiers()) {
                if (slot > 26) break;
                boolean got = view.claimed().contains(t.id());
                m.set(slot++, Items.make(got ? Material.LIME_DYE : Material.GRAY_DYE, (got ? "<green>✔ " : "<gray>") + t.display(),
                        "Needs " + t.points() + " points", got ? "Unlocked (delivered to your inbox)" : (t.points() - view.points()) + " to go"), null);
            }
            m.open(p);
        }));
    }

    // ------------------------------------------------------------ spectate
    public void openSpectate(Player p) {
        Menu m = new Menu(Msg.c("<#2DD4BF><bold>Spectator Gallery"), 3);
        int slot = 0;
        for (Instance i : plugin.instances().all()) {
            if (i.state != Instance.State.ACTIVE || slot > 26) continue;
            m.set(slot++, Items.make(Material.ENDER_EYE, "<white>" + i.def.display, i.difficulty.color + i.difficulty.display,
                    "Players: " + i.members.size(), "Elapsed: " + Msg.fmt(System.currentTimeMillis() - i.startMs), "<yellow>Click to watch"), pl -> {
                pl.closeInventory();
                String err = plugin.instances().spectate(pl, i);
                if (err != null) Msg.send(pl, "<red>" + err);
            });
        }
        if (slot == 0) m.set(13, Items.make(Material.BARRIER, "<gray>No expeditions in progress."), null);
        m.open(p);
    }
}
