package net.des.vyrnth.util;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;

import java.util.List;

/** Block-coordinate box, inclusive of both corner blocks. */
public record Cuboid(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
    public static Cuboid of(double ax, double ay, double az, double bx, double by, double bz) {
        return new Cuboid(Math.min(ax, bx), Math.min(ay, by), Math.min(az, bz),
                Math.max(ax, bx), Math.max(ay, by), Math.max(az, bz));
    }

    public boolean contains(Location l) {
        return l.getX() >= minX && l.getX() < maxX + 1
                && l.getY() >= minY && l.getY() < maxY + 1
                && l.getZ() >= minZ && l.getZ() < maxZ + 1;
    }

    public static Cuboid read(ConfigurationSection s) {
        List<Double> a = s.getDoubleList("min"), b = s.getDoubleList("max");
        if (a.size() != 3 || b.size() != 3) throw new IllegalArgumentException("region needs min/max [x,y,z]");
        return of(a.get(0), a.get(1), a.get(2), b.get(0), b.get(1), b.get(2));
    }

    public void write(ConfigurationSection s) {
        s.set("min", List.of(minX, minY, minZ));
        s.set("max", List.of(maxX, maxY, maxZ));
    }
}
