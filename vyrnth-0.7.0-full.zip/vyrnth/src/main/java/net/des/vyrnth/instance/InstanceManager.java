package net.des.vyrnth.instance;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.dungeon.Difficulty;
import net.des.vyrnth.dungeon.DungeonDefinition;
import net.des.vyrnth.dungeon.VoidGenerator;
import net.des.vyrnth.instance.Instance.State;
import net.des.vyrnth.util.Items;
import net.des.vyrnth.util.Msg;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

public final class InstanceManager {
    public static final String PREFIX = "vyrnth_inst_";

    private final VyrnthPlugin plugin;
    private final Map<UUID, Instance> byRun = new LinkedHashMap<>();
    private final Map<UUID, Instance> byPlayer = new HashMap<>();
    private final Set<UUID> internalTp = new HashSet<>();
    public final NamespacedKey exitKey;
    private final RoomManager rooms;
    private final MechanicsManager mech;

    public InstanceManager(VyrnthPlugin plugin) {
        this.plugin = plugin;
        this.exitKey = new NamespacedKey(plugin, "exit_beacon");
        this.rooms = new RoomManager(plugin);
        this.mech = new MechanicsManager(plugin);
    }

    // ---------------------------------------------------------------- lookups
    public RoomManager rooms() { return rooms; }
    public Collection<Instance> all() { return List.copyOf(byRun.values()); }
    public Instance of(UUID player) { return byPlayer.get(player); }
    public boolean isInternalTeleport(UUID id) { return internalTp.contains(id); }

    public Instance ofWorld(World w) {
        for (Instance i : byRun.values()) if (i.world != null && i.world.equals(w)) return i;
        return null;
    }

    public Instance ofBoss(UUID entity) {
        for (Instance i : byRun.values()) if (entity.equals(i.bossId)) return i;
        return null;
    }

    // ---------------------------------------------------------------- start
    /** @return an error message, or null if the run is being prepared. Must be called on the main thread. */
    public String start(DungeonDefinition def, Difficulty diff, List<Player> players, boolean force) {
        if (plugin.maintenance() && !force) return "VYRNTH is in maintenance mode.";
        if (!plugin.dungeons().isEnabled(def.id) && !force) return "This dungeon is currently disabled.";
        if (!force && !plugin.openToday(def)) return def.display + " is only open on: " + String.join(", ", plugin.openDays(def)) + " (UTC).";
        if (byRun.size() >= plugin.getConfig().getInt("max-active-instances", 8)) return "All expedition slots are busy. Try again shortly.";
        int n = players.size();
        if (n < def.minPlayers || n > def.maxPlayers) return def.display + " needs " + def.minPlayers + "-" + def.maxPlayers + " players.";
        File template = new File(Bukkit.getWorldContainer(), def.templateWorld);
        if (!new File(template, "level.dat").isFile()) return "The dungeon map is not installed yet (missing template world '" + def.templateWorld + "').";
        if (Bukkit.getWorld(def.templateWorld) != null) return "The dungeon map is currently open for editing.";
        for (Player p : players) {
            if (of(p.getUniqueId()) != null) return p.getName() + " is already in an expedition.";
            if (!force && !plugin.progression().isUnlocked(p.getUniqueId(), def, diff)) return p.getName() + " has not unlocked " + diff.display + " here.";
            if (p.getInventory().firstEmpty() == -1) return p.getName() + " needs at least one free inventory slot.";
        }
        String name = PREFIX + def.id.toLowerCase(Locale.ROOT) + "_" + UUID.randomUUID().toString().substring(0, 8);
        Instance inst = new Instance(def, diff, name);
        inst.modifier = plugin.live().weeklyModifier();
        int lives = plugin.livesFor(diff);
        for (Player p : players) {
            UUID id = p.getUniqueId();
            inst.members.add(id); inst.lives.put(id, lives); byPlayer.put(id, inst);
            Msg.send(p, "Preparing <white>" + def.display + "</white>...");
        }
        byRun.put(inst.runId, inst);
        Path src = template.toPath(), dst = new File(Bukkit.getWorldContainer(), name).toPath();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try { copyTree(src, dst); plugin.sync(() -> load(inst)); }
            catch (Exception ex) {
                plugin.getLogger().log(Level.SEVERE, "Instance copy failed for " + name, ex);
                plugin.sync(() -> abort(inst, "Failed to prepare the dungeon map."));
            }
        });
        return null;
    }

    private void load(Instance i) {
        if (i.state != State.PREPARING) { deleteAsync(i.worldName); return; }
        World w;
        try {
            w = new WorldCreator(i.worldName).environment(World.Environment.NORMAL)
                    .generator(new VoidGenerator()).generateStructures(false).createWorld();
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "World creation failed for " + i.worldName, e);
            w = null;
        }
        if (w == null) { abort(i, "Failed to load the dungeon world."); return; }
        i.world = w;
        configure(w, i.def);
        Location spawn = i.def.spawn.at(w);
        i.checkpoint = spawn;
        w.setSpawnLocation(spawn);

        List<CompletableFuture<Boolean>> tps = new ArrayList<>();
        for (UUID id : new ArrayList<>(i.members)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) { i.disconnectedAt.put(id, System.currentTimeMillis()); continue; }
            prepare(p, i);
            tps.add(teleport(p, spawn));
        }
        CompletableFuture.allOf(tps.toArray(new CompletableFuture[0])).whenComplete((v, t) -> plugin.sync(() -> {
            if (i.state != State.PREPARING) return;
            i.state = State.ACTIVE;
            i.startMs = System.currentTimeMillis();
            for (UUID id : i.members) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) {
                    Msg.title(p, "<#2DD4BF><bold>" + i.def.display, i.difficulty.color + i.difficulty.display);
                    if (i.modifier != null) Msg.send(p, "<light_purple>Weekly modifier: <white>" + i.modifier + " <gray>(" + net.des.vyrnth.live.LiveContentService.MODIFIERS.get(i.modifier) + ")");
                }
            }
        }));
    }

    private void configure(World w, DungeonDefinition def) {
        w.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        w.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        w.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        w.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS, false);
        w.setGameRule(GameRule.DO_IMMEDIATE_RESPAWN, true);
        w.setGameRule(GameRule.MOB_GRIEFING, false);
        w.setTime(def.timeOfDay);
        w.setStorm(false);
    }

    private void prepare(Player p, Instance i) {
        UUID id = p.getUniqueId();
        GameMode prev = p.getGameMode();
        i.prevMode.put(id, prev);
        String rid = i.runId.toString();
        plugin.db().submit(c -> {
            try (var ps = c.prepareStatement("INSERT OR REPLACE INTO in_run(uuid, run_id, prev_mode, ts) VALUES(?,?,?,?)")) {
                ps.setString(1, id.toString()); ps.setString(2, rid); ps.setString(3, prev.name()); ps.setLong(4, System.currentTimeMillis());
                ps.executeUpdate();
            }
            return null;
        }).exceptionally(t -> { plugin.getLogger().log(Level.WARNING, "in_run write failed", t); return null; });
        try { p.setGameMode(GameMode.valueOf(plugin.getConfig().getString("instance-gamemode", "ADVENTURE").toUpperCase(Locale.ROOT))); }
        catch (IllegalArgumentException e) { p.setGameMode(GameMode.ADVENTURE); }
        giveBeacon(p);
    }

    private void giveBeacon(Player p) {
        ItemStack beacon = Items.make(Material.NETHER_STAR, "<red><bold>Exit Beacon", "Right-click to leave this expedition.", "Players cannot rejoin a run they abandoned.");
        var meta = beacon.getItemMeta();
        meta.getPersistentDataContainer().set(exitKey, PersistentDataType.BYTE, (byte) 1);
        beacon.setItemMeta(meta);
        p.getInventory().addItem(beacon);
    }

    // ---------------------------------------------------------------- tick
    public void tick() {
        long now = System.currentTimeMillis();
        for (Instance i : new ArrayList<>(byRun.values())) {
            switch (i.state) {
                case ACTIVE -> tickActive(i, now);
                case COMPLETED, FAILED -> { if (now >= i.closeAtMs) close(i); }
                default -> { }
            }
        }
    }

    private void updateBossPhase(Instance i) {
        if (i.bossId == null) return;
        Entity e = Bukkit.getEntity(i.bossId);
        if (!(e instanceof LivingEntity le) || le.isDead()) return;
        AttributeInstance a = le.getAttribute(Attribute.MAX_HEALTH);
        if (a == null || a.getValue() <= 0) return;
        double pct = le.getHealth() / a.getValue() * 100.0;
        int phase = 1;
        for (int th : i.def.bossPhases) if (pct <= th) phase++;
        if (phase > i.bossPhase) {
            i.bossPhase = phase;
            for (UUID id : i.members) {
                Player p = Bukkit.getPlayer(id);
                if (p == null) continue;
                Msg.title(p, "<gold><bold>THE ARENA SHIFTS", "<gray>Phase " + phase);
                p.playSound(p.getLocation(), Sound.BLOCK_END_PORTAL_SPAWN, 0.6f, 1.5f);
            }
        }
    }

    /** Ambient loop every musicSeconds; swaps to boss music when the boss spawns. Sounds come from the resource pack. */
    private void music(Instance i, List<Player> alive, long now) {
        var def = i.def;
        if (def.music.isBlank() && def.bossMusic.isBlank()) return;
        boolean boss = i.bossSpawned && !def.bossMusic.isBlank();
        if (boss && !i.bossMusicOn) {
            i.bossMusicOn = true;
            i.nextMusicMs = 0;
            if (!def.music.isBlank()) for (Player p : alive) p.stopSound(net.kyori.adventure.sound.SoundStop.named(net.kyori.adventure.key.Key.key(def.music)));
        }
        if (now < i.nextMusicMs) return;
        String key = boss ? def.bossMusic : def.music;
        if (key.isBlank()) return;
        i.nextMusicMs = now + def.musicSeconds * 1000L;
        var snd = net.kyori.adventure.sound.Sound.sound(net.kyori.adventure.key.Key.key(key), net.kyori.adventure.sound.Sound.Source.MUSIC, 0.7f, 1f);
        for (Player p : alive) p.playSound(snd);
    }

    public List<Player> aliveIn(Instance i) {
        List<Player> out = new ArrayList<>();
        for (UUID id : i.members) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && !i.spectators.contains(id) && p.getWorld().equals(i.world)) out.add(p);
        }
        return out;
    }

    /** 5 Hz tick for machinery that needs smooth timing. Cheap: skips instances without crushers/conveyors/platforms. */
    public void fastTick() {
        if (byRun.isEmpty()) return;
        long now = System.currentTimeMillis();
        for (Instance i : byRun.values()) {
            if (i.state != State.ACTIVE || !i.def.layout.hasMotion()) continue;
            mech.fast(i, aliveIn(i), now);
        }
    }

    private void tickActive(Instance i, long now) {
        if (i.def.timeLimitMin > 0 && now - i.startMs > i.def.timeLimitMin * 60_000L) { fail(i, "The time limit expired."); return; }

        long grace = plugin.getConfig().getLong("disconnect-grace-seconds", 120) * 1000L;
        List<UUID> expired = new ArrayList<>();
        for (Map.Entry<UUID, Long> e : i.disconnectedAt.entrySet()) if (now - e.getValue() > grace) expired.add(e.getKey());
        for (UUID id : expired) leave(i, id, "disconnected too long");
        if (i.state != State.ACTIVE) return;
        if (i.members.isEmpty() || isWiped(i)) { fail(i, "The team has been wiped."); return; }

        List<Player> alive = new ArrayList<>();
        for (UUID id : i.members) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && !i.spectators.contains(id) && p.getWorld().equals(i.world)) alive.add(p);
        }
        if (!i.bossQueued) {
            for (Player p : alive) if (i.def.bossTrigger.contains(p.getLocation())) { queueBoss(i); break; }
        }
        updateBossPhase(i);
        music(i, alive, now);
        rooms.tick(i, alive, now);
        mech.slow(i, alive, now);
        var cps = i.def.checkpoints;
        for (int k = i.checkpointIndex + 1; k < cps.size(); k++) {
            var cp = cps.get(k);
            boolean hit = false;
            for (Player p : alive) if (cp.region().contains(p.getLocation())) { hit = true; break; }
            if (hit) {
                i.checkpointIndex = k;
                i.checkpoint = cp.spawn().at(i.world);
                for (Player p : alive) { Msg.send(p, "<green>Checkpoint reached."); p.playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.6f, 1.6f); }
                break;
            }
        }
    }

    // ---------------------------------------------------------------- encounter
    private void queueBoss(Instance i) {
        i.bossQueued = true;
        for (UUID id : i.members) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            Msg.title(p, "<red><bold>WARNING", "<gray>Something stirs in the dark...");
            p.playSound(p.getLocation(), Sound.ENTITY_WARDEN_EMERGE, 1f, 0.6f);
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> spawnBoss(i), 60L);
    }

    private void spawnBoss(Instance i) {
        if (i.state != State.ACTIVE || i.bossSpawned) return;
        String mob = i.def.bossMobs.get(i.difficulty);
        try {
            Entity boss = plugin.mythic().spawn(mob, i.def.bossSpawn.at(i.world));
            if (boss == null) throw new IllegalStateException("MythicMobs returned no entity for '" + mob + "'");
            i.bossSpawned = true;
            i.bossPhase = 1;
            i.bossId = boss.getUniqueId();
            if (boss instanceof LivingEntity le) scaleHealth(i, le);
        } catch (Exception ex) {
            plugin.getLogger().log(Level.SEVERE, "Boss spawn failed (" + mob + ") in " + i.worldName, ex);
            for (Player op : Bukkit.getOnlinePlayers()) if (op.isOp()) Msg.send(op, "<red>Boss spawn failed in " + i.worldName + ": " + ex.getMessage());
            fail(i, "The encounter failed to start. No penalty applied; an admin has been notified.");
        }
    }

    public void scaleHealth(Instance i, LivingEntity le) {
        double per = plugin.getConfig().getDouble("scaling.health-per-extra-player", 0.5);
        int alive = (int) i.members.stream().filter(m -> !i.spectators.contains(m)).count();
        double mult = 1 + per * Math.max(0, alive - 1);
        AttributeInstance a = le.getAttribute(Attribute.MAX_HEALTH);
        if (a != null && mult > 1.0) { a.setBaseValue(a.getBaseValue() * mult); le.setHealth(a.getBaseValue()); }
    }

    // ---------------------------------------------------------------- outcome
    public void complete(Instance i) {
        if (i.state != State.ACTIVE) return;
        i.state = State.COMPLETED;
        long now = System.currentTimeMillis();
        i.closeAtMs = now + plugin.getConfig().getLong("completion-close-delay-seconds", 30) * 1000L;
        long ms = now - i.startMs;
        for (UUID id : List.copyOf(i.members)) {
            Player p = Bukkit.getPlayer(id);
            reward(i, id, p, ms);
            if (p != null) {
                Msg.title(p, "<green><bold>EXPEDITION COMPLETE", "<gray>" + Msg.fmt(ms) + " · " + i.difficulty.display);
                p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            }
        }
    }

    private void reward(Instance i, UUID id, Player online, long ms) {
        DungeonDefinition def = i.def;
        Difficulty d = i.difficulty;
        double mult = plugin.rewardMultiplier(d);
        long base = Math.round(def.baseCurrency * mult * plugin.live().currencyMultiplier(def, i.modifier)), first = Math.round(def.firstClearBonus * mult);
        String name = online != null ? online.getName() : String.valueOf(Bukkit.getOfflinePlayer(id).getName());
        List<byte[]> blobs = new ArrayList<>();
        for (ItemStack it : plugin.loot().roll(def, d, name)) blobs.add(it.serializeAsBytes());
        plugin.progression().recordClear(id, i.runId, def.id, d, ms, base, first, blobs).whenComplete((res, err) -> plugin.sync(() -> {
            Player p = Bukkit.getPlayer(id);
            if (err != null) {
                plugin.getLogger().log(Level.SEVERE, "Reward transaction failed for " + id + " run " + i.runId, err);
                if (p != null) Msg.send(p, "<red>Reward error. Please report this to an admin (run " + i.shortId() + ").");
                return;
            }
            if (res == null) return;
            if (res.serverFirst()) Bukkit.broadcast(Msg.c("<#2DD4BF><bold>VYRNTH</bold> <dark_gray>»</dark_gray> <gold><bold>SERVER FIRST!</bold> <white>" + name
                    + "</white> <gray>cleared <white>" + def.display + "</white> on " + d.color + d.display + "<gray>."));
            runLive(i, id, ms);
            if (p == null) return;
            String cur = plugin.currencyName();
            Msg.send(p, "<green>+" + res.currency() + " " + cur + "</green>" + (res.firstClear() ? " <gold>(first clear!)" : "")
                    + (res.newBest() ? " <light_purple>New best: " + Msg.fmt(res.bestMs()) : ""));
            plugin.inbox().deliverAll(p);
        }));
    }

    private void runLive(Instance i, UUID id, long ms) {
        var ctx = new net.des.vyrnth.live.LiveContentService.RunCtx(i.def.id, i.difficulty, ms, i.deathsBy.getOrDefault(id, 0), i.members.size(), i.def.raid);
        plugin.live().onClear(id, ctx).whenComplete((r, err) -> plugin.sync(() -> {
            if (err != null) { plugin.getLogger().log(Level.SEVERE, "Live-content evaluation failed for " + id, err); return; }
            Player p = Bukkit.getPlayer(id);
            if (p == null) return;
            for (var a : r.achievements()) Msg.send(p, "<gold>★ Achievement: <white>" + a.display() + "</white> <gray>(+" + a.reward() + ")");
            for (var ch : r.completed()) Msg.send(p, "<green>✔ Challenge complete: <white>" + ch.display() + "</white> <gray>(+" + ch.reward() + ")");
            for (var t : r.tiers()) { Msg.send(p, "<aqua>✦ Season reward unlocked: <white>" + t.display()); plugin.inbox().deliverAll(p); }
        }));
    }

    public void fail(Instance i, String reason) {
        if (i.state != State.ACTIVE && i.state != State.PREPARING) return;
        i.state = State.FAILED;
        i.closeAtMs = System.currentTimeMillis() + plugin.getConfig().getLong("failure-close-delay-seconds", 8) * 1000L;
        if (i.bossId != null) { Entity b = Bukkit.getEntity(i.bossId); if (b != null) b.remove(); }
        for (UUID id : i.members) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) { Msg.title(p, "<red><bold>EXPEDITION FAILED", "<gray>" + reason); p.playSound(p.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.5f, 1.2f); }
        }
    }

    // ---------------------------------------------------------------- players
    public boolean isWiped(Instance i) {
        for (UUID id : i.members) {
            if (i.spectators.contains(id)) continue;
            if (Bukkit.getPlayer(id) != null || i.disconnectedAt.containsKey(id)) return false;
        }
        return true;
    }

    public void handleDisconnect(Instance i, Player p) {
        if (!i.members.contains(p.getUniqueId())) return;
        i.disconnectedAt.put(p.getUniqueId(), System.currentTimeMillis());
        broadcast(i, "<yellow>" + p.getName() + " disconnected. " + plugin.getConfig().getLong("disconnect-grace-seconds", 120) + "s to return.");
    }

    public void handleDeath(Instance i, PlayerDeathEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        boolean keep = plugin.getConfig().getBoolean("death.keep-inventory", true);
        e.setKeepInventory(keep);
        e.setKeepLevel(keep);
        if (keep) { e.getDrops().clear(); e.setDroppedExp(0); }
        e.deathMessage(null);
        i.deaths++;
        i.deathsBy.merge(id, 1, Integer::sum);
        int cur = i.lives.getOrDefault(id, 0);
        boolean unlimited = cur < 0;
        if (!unlimited) { cur--; i.lives.put(id, cur); }
        boolean out = !unlimited && cur <= 0;
        if (out) i.spectators.add(id);
        broadcast(i, "<red>" + p.getName() + " has fallen.</red> " + (out ? "<dark_red>Out of lives." : unlimited ? "" : "<gray>Lives left: " + cur));
        if (i.state == State.ACTIVE && isWiped(i)) fail(i, "The team has been wiped.");
    }

    public void handleRespawn(Instance i, PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        if (i.checkpoint != null) e.setRespawnLocation(i.checkpoint);
        if (i.spectators.contains(p.getUniqueId())) {
            Bukkit.getScheduler().runTask(plugin, () -> { if (p.isOnline()) p.setGameMode(GameMode.SPECTATOR); });
        }
    }

    /** Voluntary or forced removal from the run. Never refunds anything and the player can't rejoin. */
    public String spectate(Player p, Instance i) {
        UUID id = p.getUniqueId();
        if (of(id) != null) return "You are already in an expedition.";
        if ((i.state != State.ACTIVE && i.state != State.COMPLETED) || i.world == null || i.checkpoint == null) return "That expedition can't be watched right now.";
        if (i.watchers.size() >= plugin.getConfig().getInt("spectate.max-watchers", 6)) return "Too many spectators already.";
        if (p.getInventory().firstEmpty() == -1) return "Free one inventory slot first (you get an Exit Beacon).";
        i.watchers.add(id);
        byPlayer.put(id, i);
        GameMode prev = p.getGameMode();
        i.prevMode.put(id, prev);
        String rid = i.runId.toString();
        plugin.db().submit(c -> {
            try (var ps = c.prepareStatement("INSERT OR REPLACE INTO in_run(uuid, run_id, prev_mode, ts) VALUES(?,?,?,?)")) {
                ps.setString(1, id.toString()); ps.setString(2, rid); ps.setString(3, prev.name()); ps.setLong(4, System.currentTimeMillis());
                ps.executeUpdate();
            }
            return null;
        }).exceptionally(t -> { plugin.getLogger().log(Level.WARNING, "in_run write failed", t); return null; });
        p.setGameMode(GameMode.SPECTATOR);
        giveBeacon(p);
        Location at = i.checkpoint;
        for (UUID m : i.members) { Player mp = Bukkit.getPlayer(m); if (mp != null && mp.getWorld().equals(i.world)) { at = mp.getLocation(); break; } }
        teleport(p, at);
        Msg.send(p, "Spectating. Use the Exit Beacon to leave.");
        return null;
    }

    public void leave(Instance i, UUID id, String reason) {
        if (i.watchers.remove(id)) {
            byPlayer.remove(id);
            Player w = Bukkit.getPlayer(id);
            if (w != null) exit(w, i, true);
            return;
        }
        if (!i.members.remove(id)) return;
        i.spectators.remove(id); i.lives.remove(id); i.disconnectedAt.remove(id);
        byPlayer.remove(id);
        plugin.parties().silentRemove(id);
        Player p = Bukkit.getPlayer(id);
        String name = p != null ? p.getName() : String.valueOf(Bukkit.getOfflinePlayer(id).getName());
        if (p != null) exit(p, i, true);   // offline members keep their in_run row and are moved on next join
        broadcast(i, "<yellow>" + name + " left the expedition (" + reason + ").");
        if (i.state == State.ACTIVE || i.state == State.PREPARING) {
            if (i.members.isEmpty()) close(i);
            else if (isWiped(i)) fail(i, "The team has been wiped.");
        }
    }

    private CompletableFuture<Boolean> exit(Player p, Instance i, boolean clearRow) {
        UUID id = p.getUniqueId();
        p.setGameMode(i.prevMode.getOrDefault(id, GameMode.SURVIVAL));
        stripBeacon(p);
        p.setFireTicks(0);
        p.setFallDistance(0);
        if (clearRow) clearRow(id);
        return teleport(p, plugin.hubSpawn());
    }

    public void clearRow(UUID id) {
        plugin.db().submit(c -> {
            try (var ps = c.prepareStatement("DELETE FROM in_run WHERE uuid = ?")) { ps.setString(1, id.toString()); ps.executeUpdate(); }
            return null;
        }).exceptionally(t -> { plugin.getLogger().log(Level.WARNING, "in_run delete failed", t); return null; });
    }

    /** Used when a player logs in and the DB says they were mid-run but no live instance owns them. */
    public void restoreStranded(Player p, GameMode prev) {
        p.setGameMode(prev);
        stripBeacon(p);
        clearRow(p.getUniqueId());
        teleport(p, plugin.hubSpawn());
        Msg.send(p, "Your previous expedition ended while you were away.");
    }

    public void stripBeacon(Player p) {
        ItemStack[] c = p.getInventory().getContents();
        for (int s = 0; s < c.length; s++) {
            ItemStack it = c[s];
            if (it != null && it.hasItemMeta() && it.getItemMeta().getPersistentDataContainer().has(exitKey, PersistentDataType.BYTE)) {
                p.getInventory().setItem(s, null);
            }
        }
    }

    public boolean isBeacon(ItemStack it) {
        return it != null && it.hasItemMeta() && it.getItemMeta().getPersistentDataContainer().has(exitKey, PersistentDataType.BYTE);
    }

    /** Puts a player into the configured in-run game mode (used on revival). */
    public void setRunMode(Player p) {
        try { p.setGameMode(GameMode.valueOf(plugin.getConfig().getString("instance-gamemode", "ADVENTURE").toUpperCase(Locale.ROOT))); }
        catch (IllegalArgumentException e) { p.setGameMode(GameMode.ADVENTURE); }
    }

    public CompletableFuture<Boolean> teleport(Player p, Location to) {
        UUID id = p.getUniqueId();
        internalTp.add(id);
        CompletableFuture<Boolean> f = p.teleportAsync(to);
        f.whenComplete((ok, t) -> plugin.sync(() -> internalTp.remove(id)));
        return f;
    }

    public void broadcast(Instance i, String msg) {
        for (UUID id : i.members) { Player p = Bukkit.getPlayer(id); if (p != null) Msg.send(p, msg); }
    }

    // ---------------------------------------------------------------- close / cleanup
    public void close(Instance i) {
        if (i.state == State.CLOSING) return;
        i.state = State.CLOSING;
        List<CompletableFuture<Boolean>> fs = new ArrayList<>();
        for (UUID id : new ArrayList<>(i.members)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) fs.add(exit(p, i, true));
        }
        for (UUID id : new ArrayList<>(i.watchers)) {
            Player w = Bukkit.getPlayer(id);
            if (w != null) fs.add(exit(w, i, true));
            byPlayer.remove(id);
        }
        if (i.world != null) {
            for (Player p : i.world.getPlayers()) if (!i.members.contains(p.getUniqueId()) && !i.watchers.contains(p.getUniqueId())) fs.add(teleport(p, plugin.hubSpawn()));
        }
        for (UUID id : i.members) byPlayer.remove(id);
        byRun.remove(i.runId);
        CompletableFuture.allOf(fs.toArray(new CompletableFuture[0])).whenComplete((v, t) -> plugin.sync(() -> destroyWorld(i)));
    }

    private void destroyWorld(Instance i) {
        World w = i.world;
        if (w != null) {
            for (Player p : w.getPlayers()) p.teleport(plugin.hubSpawn());   // last-resort evacuation
            if (!Bukkit.unloadWorld(w, false)) plugin.getLogger().warning("Could not unload " + i.worldName + "; will be purged on next start.");
        }
        deleteAsync(i.worldName);
    }

    private void abort(Instance i, String msg) {
        for (UUID id : i.members) {
            byPlayer.remove(id);
            Player p = Bukkit.getPlayer(id);
            if (p != null) Msg.send(p, "<red>" + msg);
        }
        i.members.clear();
        byRun.remove(i.runId);
        i.state = State.CLOSING;
        deleteAsync(i.worldName);
    }

    public void purgeLeftovers() {
        File[] dirs = Bukkit.getWorldContainer().listFiles((d, n) -> n.startsWith(PREFIX));
        if (dirs == null) return;
        for (File d : dirs) { deleteTree(d.toPath()); plugin.getLogger().info("Purged leftover instance " + d.getName()); }
    }

    /** Synchronous shutdown path: nobody is left stranded in a world we're about to delete. */
    public void shutdown() {
        for (Instance i : new ArrayList<>(byRun.values())) {
            Set<UUID> everyone = new LinkedHashSet<>(i.members);
            everyone.addAll(i.watchers);
            for (UUID id : everyone) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) {
                    p.setGameMode(i.prevMode.getOrDefault(id, GameMode.SURVIVAL));
                    stripBeacon(p);
                    internalTp.add(id);
                    p.teleport(plugin.hubSpawn());
                    clearRow(id);
                }
            }
            if (i.world != null) {
                for (Player p : i.world.getPlayers()) p.teleport(plugin.hubSpawn());
                Bukkit.unloadWorld(i.world, false);
            }
            deleteTree(new File(Bukkit.getWorldContainer(), i.worldName).toPath());
        }
        byRun.clear(); byPlayer.clear();
    }

    private void deleteAsync(String worldName) {
        Path p = new File(Bukkit.getWorldContainer(), worldName).toPath();
        if (!plugin.isEnabled()) { deleteTree(p); return; }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> deleteTree(p));
    }

    private static void copyTree(Path src, Path dst) throws IOException {
        Set<String> skip = Set.of("session.lock", "uid.dat", "playerdata", "stats", "advancements");
        Files.walkFileTree(src, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes a) throws IOException {
                if (!dir.equals(src) && skip.contains(dir.getFileName().toString())) return FileVisitResult.SKIP_SUBTREE;
                Files.createDirectories(dst.resolve(src.relativize(dir).toString()));
                return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFile(Path f, BasicFileAttributes a) throws IOException {
                if (skip.contains(f.getFileName().toString())) return FileVisitResult.CONTINUE;
                Files.copy(f, dst.resolve(src.relativize(f).toString()), StandardCopyOption.REPLACE_EXISTING);
                return FileVisitResult.CONTINUE;
            }
        });
    }

    private static void deleteTree(Path p) {
        if (!Files.exists(p)) return;
        try (var s = Files.walk(p)) {
            s.sorted(Comparator.reverseOrder()).forEach(x -> { try { Files.deleteIfExists(x); } catch (IOException ignored) { } });
        } catch (IOException ignored) { }
    }
}
