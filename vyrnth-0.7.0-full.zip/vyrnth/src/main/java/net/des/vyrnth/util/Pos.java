package net.des.vyrnth.util;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

public record Pos(double x, double y, double z, float yaw, float pitch) {
    public Location at(World w) { return new Location(w, x, y, z, yaw, pitch); }

    public static Pos read(ConfigurationSection s) {
        if (s == null) throw new IllegalArgumentException("missing position section");
        return new Pos(s.getDouble("x"), s.getDouble("y"), s.getDouble("z"),
                (float) s.getDouble("yaw"), (float) s.getDouble("pitch"));
    }
}
