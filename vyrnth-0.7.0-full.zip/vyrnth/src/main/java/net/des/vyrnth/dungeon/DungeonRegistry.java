package net.des.vyrnth.dungeon;

import net.des.vyrnth.VyrnthPlugin;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;
import java.util.logging.Level;

public final class DungeonRegistry {
    private final VyrnthPlugin plugin;
    private final Map<String, DungeonDefinition> map = new LinkedHashMap<>();

    public DungeonRegistry(VyrnthPlugin plugin) { this.plugin = plugin; }

    public void reload() {
        map.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "dungeons.yml"));
        ConfigurationSection root = y.getConfigurationSection("dungeons");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            try { map.put(id, DungeonDefinition.load(id, root.getConfigurationSection(id))); }
            catch (Exception e) { plugin.getLogger().log(Level.SEVERE, "Invalid dungeon '" + id + "' in dungeons.yml", e); }
        }
        plugin.getLogger().info("Loaded " + map.size() + " dungeon definition(s).");
    }

    public DungeonDefinition get(String id) { return map.get(id); }
    public Collection<DungeonDefinition> all() { return map.values(); }

    public boolean isEnabled(String id) { return !plugin.getConfig().getStringList("disabled-dungeons").contains(id); }

    public void setEnabled(String id, boolean enabled) {
        List<String> l = new ArrayList<>(plugin.getConfig().getStringList("disabled-dungeons"));
        l.remove(id);
        if (!enabled) l.add(id);
        plugin.getConfig().set("disabled-dungeons", l);
        plugin.saveConfig();
    }
}
