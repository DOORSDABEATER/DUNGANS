package net.des.vyrnth.data;

import java.io.File;
import java.sql.*;
import java.util.concurrent.*;

/** Single SQLite connection owned by one worker thread: no main-thread I/O, no lock contention. */
public final class Database implements AutoCloseable {
    @FunctionalInterface public interface SqlTask<T> { T run(Connection c) throws Exception; }

    private final Connection conn;
    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "vyrnth-db"); t.setDaemon(true); return t;
    });

    public Database(File file) throws SQLException {
        file.getParentFile().mkdirs();
        conn = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement s = conn.createStatement()) {
            s.execute("PRAGMA journal_mode=WAL");
            s.execute("PRAGMA synchronous=NORMAL");
            s.execute("CREATE TABLE IF NOT EXISTS balances(uuid TEXT PRIMARY KEY, balance INTEGER NOT NULL DEFAULT 0 CHECK(balance >= 0))");
            s.execute("CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT NOT NULL, delta INTEGER NOT NULL, reason TEXT NOT NULL, ts INTEGER NOT NULL)");
            s.execute("CREATE INDEX IF NOT EXISTS ledger_uuid ON ledger(uuid)");
            s.execute("CREATE TABLE IF NOT EXISTS clears(uuid TEXT NOT NULL, dungeon TEXT NOT NULL, difficulty TEXT NOT NULL, clears INTEGER NOT NULL DEFAULT 0, best_ms INTEGER, first_ts INTEGER, PRIMARY KEY(uuid, dungeon, difficulty))");
            s.execute("CREATE TABLE IF NOT EXISTS run_rewards(run_id TEXT NOT NULL, uuid TEXT NOT NULL, PRIMARY KEY(run_id, uuid))");
            s.execute("CREATE TABLE IF NOT EXISTS inbox(id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT NOT NULL, item BLOB NOT NULL, source TEXT, ts INTEGER NOT NULL)");
            s.execute("CREATE INDEX IF NOT EXISTS inbox_uuid ON inbox(uuid)");
            s.execute("CREATE TABLE IF NOT EXISTS shop_purchases(uuid TEXT NOT NULL, item_key TEXT NOT NULL, day TEXT NOT NULL, count INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(uuid, item_key, day))");
            s.execute("CREATE TABLE IF NOT EXISTS gacha_pity(uuid TEXT NOT NULL, pool TEXT NOT NULL, count INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(uuid, pool))");
            s.execute("CREATE TABLE IF NOT EXISTS owned(uuid TEXT NOT NULL, item_key TEXT NOT NULL, PRIMARY KEY(uuid, item_key))");
            s.execute("CREATE TABLE IF NOT EXISTS gacha_history(id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT NOT NULL, pool TEXT NOT NULL, entry TEXT NOT NULL, ts INTEGER NOT NULL)");
            s.execute("CREATE TABLE IF NOT EXISTS achievements(uuid TEXT NOT NULL, id TEXT NOT NULL, ts INTEGER NOT NULL, PRIMARY KEY(uuid, id))");
            s.execute("CREATE TABLE IF NOT EXISTS challenge_progress(uuid TEXT NOT NULL, period TEXT NOT NULL, cid TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0, done INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(uuid, period, cid))");
            s.execute("CREATE TABLE IF NOT EXISTS secrets_found(uuid TEXT NOT NULL, dungeon TEXT NOT NULL, secret_id TEXT NOT NULL, ts INTEGER NOT NULL, PRIMARY KEY(uuid, dungeon, secret_id))");
            s.execute("CREATE TABLE IF NOT EXISTS season_points(uuid TEXT NOT NULL, season TEXT NOT NULL, points INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(uuid, season))");
            s.execute("CREATE TABLE IF NOT EXISTS season_claims(uuid TEXT NOT NULL, season TEXT NOT NULL, tier TEXT NOT NULL, PRIMARY KEY(uuid, season, tier))");
            s.execute("CREATE TABLE IF NOT EXISTS server_firsts(dungeon TEXT NOT NULL, difficulty TEXT NOT NULL, uuid TEXT NOT NULL, ts INTEGER NOT NULL, PRIMARY KEY(dungeon, difficulty))");
            s.execute("CREATE TABLE IF NOT EXISTS in_run(uuid TEXT PRIMARY KEY, run_id TEXT NOT NULL, prev_mode TEXT NOT NULL, ts INTEGER NOT NULL)");
        }
    }

    public <T> CompletableFuture<T> submit(SqlTask<T> task) {
        CompletableFuture<T> f = new CompletableFuture<>();
        try {
            exec.execute(() -> {
                try { f.complete(task.run(conn)); } catch (Throwable t) { f.completeExceptionally(t); }
            });
        } catch (RejectedExecutionException e) { f.completeExceptionally(e); }
        return f;
    }

    /** Runs the task in one transaction; any exception rolls everything back. */
    public <T> CompletableFuture<T> tx(SqlTask<T> task) {
        return submit(c -> {
            c.setAutoCommit(false);
            try {
                T r = task.run(c);
                c.commit();
                return r;
            } catch (Exception e) {
                try { c.rollback(); } catch (SQLException ignored) {}
                throw e;
            } finally {
                c.setAutoCommit(true);
            }
        });
    }

    @Override public void close() {
        exec.shutdown();
        try { exec.awaitTermination(10, TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
        try { conn.close(); } catch (SQLException ignored) {}
    }
}
