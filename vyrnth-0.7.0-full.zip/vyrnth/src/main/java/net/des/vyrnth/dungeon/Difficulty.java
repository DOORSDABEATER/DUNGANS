package net.des.vyrnth.dungeon;

import org.bukkit.Material;

import java.util.Locale;

public enum Difficulty {
    NORMAL("Normal", "<green>", Material.LIME_CONCRETE),
    HARD("Hard", "<yellow>", Material.YELLOW_CONCRETE),
    NIGHTMARE("Nightmare", "<gold>", Material.ORANGE_CONCRETE),
    CATACLYSM("Cataclysm", "<red>", Material.RED_CONCRETE);

    public final String display, color;
    public final Material icon;

    Difficulty(String display, String color, Material icon) {
        this.display = display; this.color = color; this.icon = icon;
    }

    public Difficulty previous() { return ordinal() == 0 ? null : values()[ordinal() - 1]; }

    public static Difficulty parse(String s) {
        try { return valueOf(s.toUpperCase(Locale.ROOT)); } catch (Exception e) { return null; }
    }
}
