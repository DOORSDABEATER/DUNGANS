package net.des.vyrnth.instance;

import net.des.vyrnth.VyrnthPlugin;
import net.des.vyrnth.dungeon.Difficulty;
import net.des.vyrnth.dungeon.Layout;
import net.des.vyrnth.util.Cuboid;
import net.des.vyrnth.util.Msg;
import org.bukkit.*;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Industrial and anomalous machinery: turrets, crushers (crush/arc), conveyors, slide/phase platforms, gravity and teleport
 * anomalies, cold and heat zones. slow() runs at 1 Hz, fast() at 5 Hz, and only for instances that define machinery.
 */
public final class MechanicsManager {
    public static final class CrushState { long cycle = -1, sounded = -1; final Set<UUID> hit = new HashSet<>(); }
    public static final class PlatState {
        int pos, dir = 1, phase;
        long nextMs;
        List<int[]> cells;
        List<BlockData> saved;
    }

    private final VyrnthPlugin plugin;
    private final Map<String, PotionEffectType> effects = new HashMap<>();

    public MechanicsManager(VyrnthPlugin plugin) { this.plugin = plugin; }

    private PotionEffectType fx(String key) {
        return effects.computeIfAbsent(key, k -> PotionEffectType.getByKey(NamespacedKey.minecraft(k)));
    }

    private boolean done(Instance i, String id) {
        RoomState s = i.rooms.get(id);
        return (s != null && s.complete) || i.foundSecrets.contains(id);
    }

    private boolean on(Instance i, Layout.Cond c, Difficulty min) {
        if (i.difficulty.ordinal() < min.ordinal()) return false;
        if (!c.disabledBy().isBlank() && done(i, c.disabledBy())) return false;
        if (!c.after().isBlank() && !done(i, c.after())) return false;
        String d = c.during();
        if (d.isBlank()) return true;
        if (d.equals("boss")) return i.bossSpawned;
        if (d.startsWith("boss-phase-")) return i.bossSpawned && i.bossPhase >= Integer.parseInt(d.substring(11));
        if (d.startsWith("boss-only-")) return i.bossSpawned && i.bossPhase == Integer.parseInt(d.substring(10));
        RoomState s = i.rooms.get(d);
        return s != null && s.active && !s.complete;
    }

    // ------------------------------------------------------------------ 1 Hz: turrets, heat visuals
    public void slow(Instance i, List<Player> alive, long now) {
        for (Layout.Turret t : i.def.layout.turrets) {
            if (!on(i, t.cond(), t.minDiff())) continue;
            if (now < i.nextFire.getOrDefault(t.id(), 0L)) continue;
            Location o = new Location(i.world, t.x() + 0.5, t.y() + 0.5, t.z() + 0.5);
            Player target = null;
            double best = t.range();
            for (Player p : alive) {
                Location eye = p.getEyeLocation();
                double d = eye.distance(o);
                if (d > best || d < 0.5) continue;
                Vector dir = eye.toVector().subtract(o.toVector()).normalize();
                RayTraceResult hit = i.world.rayTraceBlocks(o, dir, d, FluidCollisionMode.NEVER, true);
                if (hit != null) continue;   // no line of sight
                best = d; target = p;
            }
            if (target == null) { i.nextFire.put(t.id(), now + 1000); continue; }
            double interval = Math.max(1.5, t.interval() - t.intervalReduction() * i.difficulty.ordinal());
            i.nextFire.put(t.id(), now + (long) (interval * 1000));
            fire(i, t, o, target);
        }
        for (Layout.Heat h : i.def.layout.heat) {
            if (!heatActive(i, h, now)) continue;
            Cuboid r = h.region();
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            for (int k = 0; k < 6; k++)
                i.world.spawnParticle(Particle.FLAME, rnd.nextDouble(r.minX(), r.maxX() + 1), r.minY() + 0.3, rnd.nextDouble(r.minZ(), r.maxZ() + 1), 1, 0.1, 0.1, 0.1, 0.01);
        }
    }

    /** Telegraph (red line + hiss) now, hit 1s later at the position the player was in: moving ~1.5 blocks dodges it. */
    private void fire(Instance i, Layout.Turret t, Location o, Player target) {
        Location aim = target.getLocation().clone();
        UUID tid = target.getUniqueId();
        line(o, target.getEyeLocation(), true);
        i.world.playSound(o, Sound.ENTITY_CREEPER_PRIMED, 1.2f, 1.8f);
        double dmg = t.damage() + t.damagePerDiff() * i.difficulty.ordinal();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (i.state != Instance.State.ACTIVE) return;
            Player p = Bukkit.getPlayer(tid);
            if (p == null || !p.getWorld().equals(i.world) || i.spectators.contains(tid)) return;
            line(o, p.getEyeLocation(), false);
            i.world.playSound(o, Sound.ENTITY_BLAZE_SHOOT, 1.2f, 1.2f);
            if (p.getLocation().distanceSquared(aim) <= 1.5 * 1.5) p.damage(dmg);
        }, 20L);
    }

    private void line(Location a, Location b, boolean warn) {
        Vector v = b.toVector().subtract(a.toVector());
        double len = v.length();
        if (len < 0.1) return;
        v.normalize();
        int pts = (int) Math.min(40, len * 2);
        Particle.DustOptions opt = new Particle.DustOptions(warn ? Color.RED : Color.ORANGE, 1.2f);
        for (int k = 1; k <= pts; k++)
            a.getWorld().spawnParticle(Particle.DUST, a.clone().add(v.clone().multiply(len * k / pts)), 1, 0, 0, 0, 0, opt);
    }

    // ------------------------------------------------------------------ 5 Hz
    public void fast(Instance i, List<Player> alive, long now) {
        Layout L = i.def.layout;
        for (Layout.Crusher c : L.crushers) if (on(i, c.cond(), c.minDiff())) crush(i, c, alive, now);
        for (Layout.Conveyor c : L.conveyors) if (on(i, c.cond(), c.minDiff())) convey(i, c, alive);
        for (Layout.Platform p : L.platforms) {
            PlatState s = i.plats.computeIfAbsent(p.id(), k -> new PlatState());
            if (!on(i, p.cond(), p.minDiff())) {
                if (p.type().equals("PHASE") && s.phase != 0 && s.saved != null) applyPhase(i, p, s, 0);   // leave the arena in its original state
                continue;
            }
            if (p.type().equals("SLIDE")) slide(i, p, s, alive, now); else phase(i, p, s, now);
        }
        for (Layout.Anomaly a : L.anomalies) if (on(i, a.cond(), a.minDiff())) anomaly(i, a, alive, now);
        for (Layout.Cold c : L.cold) if (on(i, c.cond(), c.minDiff())) cold(i, c, alive, now);
    }

    private void crush(Instance i, Layout.Crusher c, List<Player> alive, long now) {
        double period = Math.max(4, c.period() - c.periodReduction() * i.difficulty.ordinal());
        double elapsed = (now - i.startMs) / 1000.0;
        double t = elapsed % period;
        long cycle = (long) (elapsed / period);
        CrushState cs = i.crush.computeIfAbsent(c.id(), k -> new CrushState());
        if (cs.cycle != cycle) { cs.cycle = cycle; cs.hit.clear(); }
        double activeStart = period - c.active(), warnStart = activeStart - c.warn();
        Cuboid r = c.region();
        boolean arc = c.style().equals("ARC");
        if (t >= activeStart) {
            if (cs.sounded != cycle) {
                cs.sounded = cycle;
                Location mid = new Location(i.world, (r.minX() + r.maxX()) / 2, (r.minY() + r.maxY()) / 2, (r.minZ() + r.maxZ()) / 2);
                i.world.playSound(mid, arc ? Sound.ENTITY_LIGHTNING_BOLT_IMPACT : Sound.BLOCK_ANVIL_LAND, 2f, arc ? 1.6f : 0.6f);
            }
            for (Player p : alive) if (r.contains(p.getLocation()) && cs.hit.add(p.getUniqueId())) {
                p.damage(c.damage());
                p.setVelocity(new Vector(0, 0.45, 0));
            }
            if (arc) {
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                for (int k = 0; k < 12; k++)
                    i.world.spawnParticle(Particle.ELECTRIC_SPARK, rnd.nextDouble(r.minX(), r.maxX() + 1), rnd.nextDouble(r.minY(), r.maxY() + 1), rnd.nextDouble(r.minZ(), r.maxZ() + 1), 1, 0, 0, 0, 0.05);
            }
        } else if (t >= warnStart) {
            Particle.DustOptions opt = new Particle.DustOptions(arc ? Color.AQUA : Color.RED, 1.6f);
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            for (int k = 0; k < 10; k++)
                i.world.spawnParticle(Particle.DUST, rnd.nextDouble(r.minX(), r.maxX() + 1), r.minY() + 0.2, rnd.nextDouble(r.minZ(), r.maxZ() + 1), 1, 0, 0, 0, 0, opt);
        }
    }

    private void convey(Instance i, Layout.Conveyor c, List<Player> alive) {
        double sp = c.speed() + c.speedPerDiff() * i.difficulty.ordinal();
        for (Player p : alive) {
            if (!c.region().contains(p.getLocation())) continue;
            Vector v = p.getVelocity().add(new Vector(c.dx() * sp, c.dy() * sp, c.dz() * sp));
            double h = Math.hypot(v.getX(), v.getZ());
            if (h > 0.55) { double k = 0.55 / h; v.setX(v.getX() * k); v.setZ(v.getZ() * k); }
            p.setVelocity(v);
        }
    }

    private static List<int[]> cells(Cuboid c) {
        List<int[]> out = new ArrayList<>();
        for (int x = (int) c.minX(); x <= (int) c.maxX(); x++)
            for (int y = (int) c.minY(); y <= (int) c.maxY(); y++)
                for (int z = (int) c.minZ(); z <= (int) c.maxZ(); z++) out.add(new int[]{x, y, z});
        return out;
    }

    private void slide(Instance i, Layout.Platform p, PlatState s, List<Player> alive, long now) {
        if (now < s.nextMs) return;
        int ux = Integer.signum(p.mx()), uy = Integer.signum(p.my()), uz = Integer.signum(p.mz());
        int steps = Math.abs(p.mx() + p.my() + p.mz());
        if ((s.dir > 0 && s.pos >= steps) || (s.dir < 0 && s.pos <= 0)) {   // reached an end: pause, then reverse
            s.dir = -s.dir;
            s.nextMs = now + (long) (p.pause() * 1000);
            return;
        }
        if (s.cells == null) s.cells = cells(p.region());
        int ox = ux * s.pos, oy = uy * s.pos, oz = uz * s.pos;
        int sx = ux * s.dir, sy = uy * s.dir, sz = uz * s.dir;
        Cuboid r = p.region();
        List<Player> riders = new ArrayList<>();
        for (Player pl : alive) {
            Location l = pl.getLocation();
            if (l.getX() >= r.minX() + ox && l.getX() < r.maxX() + ox + 1 && l.getZ() >= r.minZ() + oz && l.getZ() < r.maxZ() + oz + 1
                    && l.getY() >= r.maxY() + oy + 0.5 && l.getY() < r.maxY() + oy + 3) riders.add(pl);
        }
        List<BlockData> data = new ArrayList<>(s.cells.size());
        for (int[] c : s.cells) data.add(i.world.getBlockAt(c[0] + ox, c[1] + oy, c[2] + oz).getBlockData());
        for (int[] c : s.cells) i.world.getBlockAt(c[0] + ox, c[1] + oy, c[2] + oz).setType(Material.AIR, false);
        for (int k = 0; k < s.cells.size(); k++) {
            int[] c = s.cells.get(k);
            i.world.getBlockAt(c[0] + ox + sx, c[1] + oy + sy, c[2] + oz + sz).setBlockData(data.get(k), false);
        }
        for (Player pl : riders) { pl.teleport(pl.getLocation().add(sx, sy, sz)); pl.setFallDistance(0); }
        s.pos += s.dir;
        s.nextMs = now + p.stepTicks() * 50L;
    }

    private void phase(Instance i, Layout.Platform p, PlatState s, long now) {
        double cycle = p.on() + p.warn() + p.off();
        double t = ((now - i.startMs) / 1000.0 + p.offset()) % cycle;
        int phase = t < p.on() ? 0 : t < p.on() + p.warn() ? 1 : 2;
        if (phase == s.phase) return;
        applyPhase(i, p, s, phase);
    }

    private void applyPhase(Instance i, Layout.Platform p, PlatState s, int phase) {
        if (s.cells == null) s.cells = cells(p.region());
        if (s.saved == null) {   // remember the original blocks the first time we alter them
            s.saved = new ArrayList<>();
            for (int[] c : s.cells) s.saved.add(i.world.getBlockAt(c[0], c[1], c[2]).getBlockData());
        }
        Material warn = Material.matchMaterial(p.warnMaterial());
        if (warn == null) warn = Material.RED_CONCRETE;
        for (int k = 0; k < s.cells.size(); k++) {
            int[] c = s.cells.get(k);
            var b = i.world.getBlockAt(c[0], c[1], c[2]);
            switch (phase) {
                case 0 -> b.setBlockData(s.saved.get(k), false);
                case 1 -> { if (!s.saved.get(k).getMaterial().isAir()) b.setType(warn, false); }
                default -> b.setType(Material.AIR, false);
            }
        }
        if (phase == 1) i.world.playSound(new Location(i.world, p.region().minX(), p.region().minY(), p.region().minZ()), Sound.BLOCK_NOTE_BLOCK_BASS, 1.5f, 0.5f);
        s.phase = phase;
    }

    private void anomaly(Instance i, Layout.Anomaly a, List<Player> alive, long now) {
        if (a.type().equals("GRAVITY")) {
            if (a.period() > 0 && ((now - i.startMs) / 1000.0) % a.period() >= a.active()) return;
            PotionEffectType slowFall = fx("slow_falling"), jump = fx("jump_boost"), slow = fx("slowness"), lev = fx("levitation");
            for (Player p : alive) {
                if (!a.region().contains(p.getLocation())) continue;
                switch (a.mode()) {
                    case "HEAVY" -> {
                        if (slow != null) p.addPotionEffect(new PotionEffect(slow, 20, 1, true, false, false));
                        if (jump != null) p.addPotionEffect(new PotionEffect(jump, 20, 250, true, false, false));   // can't jump
                    }
                    case "LIFT" -> { if (lev != null) p.addPotionEffect(new PotionEffect(lev, 20, 1, true, false, false)); }
                    default -> {
                        if (slowFall != null) p.addPotionEffect(new PotionEffect(slowFall, 20, 0, true, false, false));
                        if (jump != null) p.addPotionEffect(new PotionEffect(jump, 20, 3, true, false, false));
                    }
                }
                p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 2, 0.4, 0.5, 0.4, 0.01);
            }
        } else {   // TELEPORT: stepping on the pad moves you; Nightmare+ scrambles the destination
            boolean scramble = i.difficulty.ordinal() >= Difficulty.NIGHTMARE.ordinal() && a.to().size() > 1;
            for (Player p : alive) {
                if (!a.region().contains(p.getLocation())) continue;
                String key = a.id() + "|" + p.getUniqueId();
                if (now < i.tpCool.getOrDefault(key, 0L)) continue;
                i.tpCool.put(key, now + (long) (a.cooldown() * 1000));
                var dest = scramble ? a.to().get(ThreadLocalRandom.current().nextInt(a.to().size())) : a.to().get(0);
                i.world.spawnParticle(Particle.PORTAL, p.getLocation().add(0, 1, 0), 40, 0.4, 0.8, 0.4, 0.5);
                i.world.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
                plugin.instances().teleport(p, dest.at(i.world).add(0.5, 0, 0.5));
            }
        }
    }

    private boolean heatActive(Instance i, Layout.Heat h, long now) {
        if (!on(i, h.cond(), Difficulty.NORMAL)) return false;
        if (h.period() <= 0) return true;
        return ((now - i.startMs) / 1000.0 + h.offset()) % h.period() < h.active();
    }

    private void cold(Instance i, Layout.Cold c, List<Player> alive, long now) {
        int rate = c.rate() + 2 * i.difficulty.ordinal();
        for (Player p : alive) {
            if (!c.region().contains(p.getLocation())) continue;
            boolean warm = false;
            for (Layout.Heat h : i.def.layout.heat) if (heatActive(i, h, now) && h.region().contains(p.getLocation())) { warm = true; break; }
            int ft = p.getFreezeTicks();
            if (warm) { p.setFreezeTicks(Math.max(0, ft - 14)); continue; }
            p.setFreezeTicks(Math.min(p.getMaxFreezeTicks() + 20, ft + rate));
            if (ft > p.getMaxFreezeTicks() - 40) p.sendActionBar(Msg.c("<aqua>❄ You are freezing! Reach a heat source."));
        }
    }
}
