# How the maps and hub get built
`tools/gen_builds.py` reads the layouts in `dungeons.yml` and writes `src/main/resources/builds.yml` (halls sized from the rooms/machinery inside them, void gaps, decks, ramps, the secret annex + vault alcove,
and a palette per dungeon). `/vyrnth build <dungeon>` executes it in batches: shells, carved halls, pillars and lamps, gates, platforms, pads, turrets, pedestals and interactables, checkpoint pads, boss pad.
Everything is derived from the same coordinates the runtime uses, so rooms, gates, activators, turrets and platforms line up with the geometry.
Change a coordinate in dungeons.yml -> `python3 tools/gen_builds.py` -> copy builds.yml to the plugin folder -> `/vyrnth reload` -> `/vyrnth build <dungeon>` (rebuilds in place).
Hand-finish the result with `/vyrnth edit <dungeon>` (WorldEdit, detail, custom blocks), then `/vyrnth edit done`. Re-running a build overwrites the generated area, so do manual polish last.
What the generator produces is functional, themed, blocky architecture (corridors, halls, chasms, ramps, pillars, lamps), NOT hand-crafted art. Treat it as a playable graybox with identity.
Neon Grave has a real ramp-up / deck / ramp-down tower; Iron Veil has a lava channel; Eclipse Engine and Godsplitter are open floating architecture; Cryo-Theta has an ice-bridge chasm.
