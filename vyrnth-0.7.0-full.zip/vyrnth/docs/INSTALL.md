# Install (v0.7.0)
Verify your versions, do not assume: Java 21, Paper 1.21.x, MythicMobs 5.x, ModelEngine R4 (for models), Sift (see SIFT.md).
`pom.xml` targets Paper 1.21.4 / MythicMobs 5.6.1; change `paper.version` / `mythic.version` to yours.

1. `mvn package` -> `target/VYRNTH-0.7.0.jar` -> `plugins/`. Start once so configs (incl. `builds.yml`) generate.
2. Mythic: copy `mythicmobs/Mobs/*` and `mythicmobs/Skills/*` into `plugins/MythicMobs/`. `/mm reload`, read the console, fix what it rejects.
3. **Hub**: stand where you want the station centre (on flat ground in your hub world, ~80x80 free, 25 blocks of headroom) and run `/vyrnth build hub`.
   It builds the dome, 8 gateways, 11 terminals, return gateway, party lounge, practice arena and hidden vault; sets `hub.spawn`; registers every portal. Then at the lobby side: `/vyrnth set lobby` and a `LOBBY_TO_HUB` portal (`/vyrnth pos1`, `pos2`, `portal add lobby_in LOBBY_TO_HUB`).
4. **Maps**: `/vyrnth build all` (or `/vyrnth build <dungeon>`). It creates each void template world, builds the whole map from the layout, saves and unloads it. Lower `build.blocks-per-tick` in config.yml if the server stutters. Test with `/vyrnth run <dungeon> NORMAL`.
5. **Models** (optional, needs ModelEngine): copy `modelengine/blueprints/*` into `plugins/ModelEngine/blueprints/`, `/meg reload`, then use the Mythic files from `mythicmobs-modelengine/` instead of `mythicmobs/` (they add `model{mid=...}` lines). Do NOT use that folder without ModelEngine.
6. **Music/sounds**: merge `resourcepack/` into the mandatory DeS pack (16 generated loops are included).
7. Replace placeholder loot (`MATERIAL:`) with DeS items (`MYTHIC:id`) in dungeons.yml/gacha.yml/shop.yml.
