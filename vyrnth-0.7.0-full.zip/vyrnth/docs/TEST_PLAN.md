# Test plan and report
## Performed (static only, in the authoring sandbox)
- All YAML (configs, layouts, Mythic) parses; every skill line is a plain string.
- Every layout cross-reference validates (gates, room/secret ids, machinery conditions, phase numbers, sequence/routing ranges, unlock chain).
- Every Mythic mob, skill and Template referenced by layouts/skills exists (74 mobs, 138 skills).
- javac syntax pass over all Java; no missing members on the plugin's own classes. NOT compiled against Paper/MythicMobs.
- Generated assets verified structurally: 16 OGG loops decode, are 61s with small seam jumps; 49 .bbmodel files validate (bones, animators, textures); builds.yml halls/annexes pass sanity assertions.
## NOT performed (do these before calling anything complete)
Solo clear and full-party clear on every difficulty · multiple simultaneous instances · each boss phase transition and death/reward delivery ·
disconnect/reconnect (member and leader) · death, out-of-lives spectator, team wipe, revival beacon, checkpoint respawn · abandon via Exit Beacon · instance reset/close ·
currency and gacha transactions incl. insufficient funds and double-click · inbox claim with a full inventory · server restart mid-run (expect: run cancelled, players returned) ·
matchmaking with 2-4 queued players · spectating · raid schedule gate · season tier delivery · each machinery type (turret dodge, crusher, conveyor, slide + riders, phase, gravity, teleport, cold/heat) ·
ModelEngine models (none exist yet) · resource pack loading · Sift interaction with every custom block in a room · MythicMobs syntax acceptance per skill.
Record results here as you go.

Also test: `/vyrnth build hub` and `/vyrnth build all` (time, TPS during build, results), every gateway/terminal opening its menu, hub vault (press the two west panels B then A), practice pad, walking each dungeon on Normal end to end
(bridges, tower ramps, void chasms), annex + vault alcove per dungeon, ModelEngine loading all 49 blueprints, music playback and loop gaps in-game.
