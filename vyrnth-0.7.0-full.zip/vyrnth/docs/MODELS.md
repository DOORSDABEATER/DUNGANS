# Models
`tools/gen_models.py` generates 49 Blockbench `.bbmodel` blueprints in `modelengine/blueprints/`: all 8 bosses, 12 mini/secret bosses, and the minions. Each has a procedural 64x64 texture and these animations
(ModelEngine state names): idle, walk, attack, special, stagger, transition, spawn, death (minions have a subset; static nodes/turrets: idle, attack, spawn, death). Each has `root` and `hitbox` bones.
They are parametric blocky rigs (cubes + keyframes): good for playing with and as rigs to sculpt over. They are NOT final art. See docs/model_previews.png for the 8 bosses.
Open them in Blockbench to refine geometry/textures; keep the bone and animation names so the Mythic skills keep working.
`tools/enable_models.py` writes `mythicmobs-modelengine/` with `model{mid=...}` added to all 77 mobs. Attack/special animations are not triggered from skills yet: add ModelEngine animation mechanics (e.g. play `attack` in each skill) in Blockbench/Mythic as you refine.
Per boss mapping: rootmind, forge_prime, subject_zero, the_warden, absolute, the_parallax, admiral_vexar, xerath_null.
