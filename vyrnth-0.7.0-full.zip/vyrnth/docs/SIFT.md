# Sift / custom blocks
Not tested. The plugin itself never relies on note blocks or custom block states: gates and platforms use `setType(AIR)` / `setBlockData` on whatever blocks the map contains.
Before building maps with custom blocks, verify against Sift in a scratch world: (1) a custom block placed by the template survives the world copy; (2) it survives `setType(AIR)` removal and
`setBlockData` restore in phase platforms; (3) no Sift interaction handler swallows `PlayerInteractEvent` on puzzle blocks (activators, junctions, terminals, revival beacons, data logs);
(4) neighbouring note-block updates don't change the block. If any fail, use vanilla blocks for puzzle objects and keep custom blocks decorative.
