# VYRNTH v0.7.0 — dungeon and raid ecosystem for DeS

**Read this first (honest status).** Up to v0.4.0 the author reported the plugin built and worked on the DeS server. Everything added
after that (Iron Veil, machinery, dungeons 3-6, both raids, season/events/modifiers, matchmaking, spectating, hub boards,
revival, secret bosses, schedule) has only been statically checked: YAML parsing, cross-reference validation of every layout and
Mythic file, and a javac syntax pass. It has NOT been compiled against the Paper API or run on a server. Expect a few compile
fixes and some in-game tuning. Nothing in this repo is a finished game until maps, models and sounds exist (see "Needs supplying").

## What exists
| Area | Status |
|---|---|
| Core: OP-only admin, walk-in portals, per-run world instances, parties, ready checks, lives, checkpoints, spectating, disconnect/reconnect, cleanup, SQLite persistence | implemented |
| Economy: shop (rotating/limited), gacha (3 pools, pity, duplicates, odds view), reward inbox, atomic transactions | implemented |
| Live content: achievements, daily/weekly challenges, daily dungeon + weekly featured, weekly modifier, limited-time events, seasonal reward track, server-first announcements, raid schedule | implemented |
| Engine: rooms (CLEAR/WAVES/ACTIVATE/ROUTING/SEQUENCE/REACH/SURVIVE), hazards, gates, turrets, crushers/arcs, conveyors, slide+phase platforms, gravity/teleport anomalies, cold+heat zones, revival points, secrets, secret bosses, boss-phase arenas, music | implemented |
| 8 layouts: VERDANT-9, IRON VEIL, NULLPOINT, NEON GRAVE, CRYO-THETA, ECLIPSE ENGINE, The Last Armada, The Godsplitter Protocol | config written; coordinates are placeholders |
| 8 bosses + 8 secret/mini bosses + 55 minions as MythicMobs scaffolds, 4 difficulty variants each boss | written, unvalidated in-game |
| Hub features: gateways, shop, gacha, rewards, challenges, achievements, leaderboards, stats, trophies, lore archive, season track, spectator gallery, hidden hub secrets | menus implemented; the physical hub must be built |
| Group finder (matchmaking) | implemented (basic) |

## Newly generated in v0.7.0 (all untested in-game)
- `/vyrnth build <dungeon|all|hub>`: the plugin builds the hub (dome, gateways, terminals, lounge, practice arena, hidden vault) and all 8 dungeon/raid maps itself from the layouts. See BUILDING.md.
- 16 generated music loops, 49 ModelEngine blueprints with textures and animations, a practice dummy, secret bosses for all 8 dungeons.
- A few layouts were reworked so Normal difficulty is physically traversable (platform bridges, Neon Grave tower).

## Still needs a human
1. Compile + play-test everything (see TEST_PLAN.md). Nothing past v0.4.0 has run on a server.
2. Art quality: generated maps are themed graybox architecture; models are blocky rigs; music is synthesized. Polish or replace with real assets.
3. DeS custom items for loot (placeholders are vanilla), Sift/custom-block verification (SIFT.md).
4. ModelEngine: install it, copy blueprints, and use `mythicmobs-modelengine/`. Hook attack/special animations into skills.

## Not implemented
Cinematic camera sequences, a downed state (revival beacons instead), restart-survivable runs, equipment/cosmetic display cases in the hub, true smooth moving platforms, per-skill MythicMobs validation. Details: KNOWN_LIMITATIONS.md.

Docs: INSTALL.md · BUILDING.md · ADMIN.md · TEST_PLAN.md · KNOWN_LIMITATIONS.md · SIFT.md · UPGRADE.md · MODELS.md
