# Upgrade / migration
Database changes since v0.1 are additive (`CREATE TABLE IF NOT EXISTS`); upgrading in place is safe. Back up `plugins/VYRNTH/vyrnth.db` first.
Config: new keys are read with defaults, but replace `config.yml` and `dungeons.yml` wholesale if your copy predates v0.4 (new layout sections and room types; old `checkpoints:` still load).
Copy new resources: `shop.yml gacha.yml achievements.yml challenges.yml events.yml season.yml`. Re-copy `mythicmobs/` and `/mm reload`.
v0.6 changes: Mythic skill lines no longer contain `: ` (it turned list items into maps). Re-copy the Mythic files even if you changed nothing.
