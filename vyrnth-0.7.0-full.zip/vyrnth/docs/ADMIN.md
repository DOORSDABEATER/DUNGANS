# Admin commands (OP/console only; every subcommand re-checks; tab-complete is hidden from non-OPs)
`/vyrnth` help · `reload` (config, dungeons, portals, shop, gacha, live content, hub secrets) · `maintenance on|off` · `debug`
`dungeon list|enable|disable <id>` · `instances` · `close <runId|all>` · `run <dungeon> <difficulty>` · `boss <mythicMobId>`
`currency balance|give|take <player> [amount]` · `progress <player>` · `top <dungeon> <difficulty>` · `queue` · `shop` · `gacha`
`build <dungeon|all|hub>` (auto-build maps/hub) · `edit <dungeon>|edit done` · `set hub|lobby` · `pos1` `pos2` · `portal add|remove|list`
`room list|complete <id>|gate <id>` (inside an instance; soft-lock recovery)
`live` (today's rotation, challenges) · `rotation daily|weekly <dungeon|auto>` · `modifier <KEY|auto>` · `schedule <dungeon> <MON..SUN|always|reset>`

Player command: `/party invite|accept|decline|leave|kick|promote|list|ready|notready` (party management only; nothing here enters a dungeon).
Players enter ONLY through the lobby portal and hub gateways. Raids default to Fri-Sun (armada) / Sat-Sun (godsplitter) UTC; override with `/vyrnth schedule`.

## Configuration map
`config.yml` core rules, lives/multipliers, live-content knobs, revival, spectate, matchmaking, hub secrets · `dungeons.yml` all layouts, rewards, music, schedule ·
`shop.yml` `gacha.yml` economy · `achievements.yml` `challenges.yml` `events.yml` `season.yml` live content · Mythic files in `mythicmobs/`.
Layout building blocks (all in dungeons.yml): gates, hazards, rooms, secrets, secret-bosses, revival, turrets, crushers, conveyors, platforms, anomalies, cold, heat.
Machinery switches: `active-during: <room>|boss|boss-phase-N|boss-only-N`, `disabled-by: <room|secret>`, `after: <room|secret>`.
