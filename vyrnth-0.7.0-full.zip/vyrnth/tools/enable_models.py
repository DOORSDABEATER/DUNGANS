#!/usr/bin/env python3
"""Creates a copy of the Mythic files with ModelEngine `model{mid=...}` lines added to every mapped mob.
Use it ONLY after ModelEngine is installed (otherwise MythicMobs rejects the unknown `model` mechanic).
  python3 tools/enable_models.py            -> writes mythicmobs-modelengine/ next to mythicmobs/
Copy the blueprints from modelengine/blueprints/ into plugins/ModelEngine/blueprints/ and run /meg reload."""
import os, re, shutil
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC, DST = os.path.join(ROOT, 'mythicmobs'), os.path.join(ROOT, 'mythicmobs-modelengine')
MAP = {
 'V9_RootMind': 'rootmind', 'V9_Seedmother': 'seedmother', 'V9_SporeCrawler': 'spore_crawler', 'V9_InfectionNode': 'infection_node', 'V9_BloomShambler': 'bloom_shambler', 'V9_Thornwarden': 'thornwarden',
 'IV_ForgePrime': 'forge_prime', 'IV_Foreman': 'foreman', 'IV_Sentry': 'foundry_sentry', 'IV_Welder': 'welder_drone', 'IV_ArmorPlate': 'armor_plate', 'IV_Scrapking': 'scrapking',
 'NP_SubjectZero': 'subject_zero', 'NP_Specimen': 'specimen', 'NP_Specimen_Alpha': 'specimen', 'NP_FalseTarget': 'false_target', 'NP_Echo': 'echo', 'NP_Aberration': 'aberration', 'NP_Observer': 'observer',
 'NG_Warden': 'the_warden', 'NG_Drone': 'patrol_drone', 'NG_SecurityBot': 'security_bot', 'NG_Enforcer': 'enforcer', 'NG_DeployTurret': 'deploy_turret', 'NG_SupportNode': 'support_node', 'NG_BlackIce': 'black_ice',
 'CT_Absolute': 'absolute', 'CT_FrozenHusk': 'frozen_husk', 'CT_FrozenHusk_Elite': 'frozen_husk', 'CT_IceBarrier': 'ice_barrier', 'CT_FrostMinion': 'frost_minion', 'CT_Cryowarden': 'cryowarden', 'CT_Founder': 'frozen_founder',
 'EE_Parallax': 'the_parallax', 'EE_Drifter': 'phase_drifter', 'EE_ResonanceNode': 'resonance_node', 'EE_EchoOfNothing': 'echo_of_nothing',
 'AR_Vexar': 'admiral_vexar', 'AR_Trooper': 'armada_trooper', 'AR_Drone': 'armada_drone', 'AR_Heavy': 'siege_walker', 'AR_Commander': 'line_commander', 'AR_WeaponSystem': 'weapon_battery', 'AR_WeaponPlatform': 'weapon_battery', 'AR_Stowaway': 'stowaway',
 'GP_Xerath': 'xerath_null', 'GP_Drifter': 'fracture_drifter', 'GP_Sentinel': 'null_sentinel', 'GP_Anchor': 'containment_anchor', 'GP_ContainmentNode': 'containment_anchor', 'GP_Guardian': 'machine_guardian', 'GP_Remnant': 'remnant',
 'VY_PracticeDummy': 'practice_dummy',
}
def model_for(mob):
    if mob in MAP: return MAP[mob]
    base = re.sub(r'_(Hard|Nightmare|Cataclysm)$', '', mob)
    return MAP.get(base)
if os.path.exists(DST): shutil.rmtree(DST)
shutil.copytree(SRC, DST)
added = 0
for f in os.listdir(os.path.join(DST, 'Mobs')):
    path = os.path.join(DST, 'Mobs', f); out = []; mob = None
    for line in open(path).read().split('\n'):
        if re.match(r'^[A-Za-z0-9_]+:\s*$', line): mob = line[:-1].strip()
        if re.match(r'^\s*#\s*-\s*model\{', line): continue          # drop the commented placeholder lines
        out.append(line)
        if mob and re.match(r'^  Skills:\s*$', line) and model_for(mob):
            out.append('    - model{mid=%s} @self ~onSpawn' % model_for(mob)); added += 1
    open(path, 'w').write('\n'.join(out))
print('model lines added to', added, 'mobs ->', DST)
