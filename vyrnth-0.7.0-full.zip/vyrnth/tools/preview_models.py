#!/usr/bin/env python3
"""Validates .bbmodel files and renders a rough isometric preview sheet (docs/model_previews.png). Ignores per-cube rotation."""
import json, glob, os, io, base64, math, sys
from PIL import Image, ImageDraw
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
files = sorted(glob.glob(os.path.join(ROOT, 'modelengine/blueprints/*.bbmodel')))

def validate(path):
    d = json.load(open(path)); errs = []
    uu = {e['uuid'] for e in d['elements']}; gu = set()
    def walk(g):
        gu.add(g['uuid'])
        for c in g['children']:
            if isinstance(c, str):
                if c not in uu: errs.append('dangling child ' + c)
            else: walk(c)
    for g in d['outliner']: walk(g)
    placed = set()
    def walk2(g):
        for c in g['children']:
            if isinstance(c, str): placed.add(c)
            else: walk2(c)
    for g in d['outliner']: walk2(g)
    if placed != uu: errs.append('unplaced cubes: %d' % len(uu - placed))
    for a in d['animations']:
        for k in a['animators']:
            if k not in gu: errs.append('animator for unknown bone in ' + a['name'])
    for e in d['elements']:
        if any(e['from'][i] > e['to'][i] for i in range(3)): errs.append('inverted cube ' + e['name'])
    png = base64.b64decode(d['textures'][0]['source'].split(',')[1]); im = Image.open(io.BytesIO(png))
    if im.size != (64, 64): errs.append('bad texture size')
    names = {g['name'] for g in d['outliner']}
    allnames = set()
    def names_(g): allnames.add(g['name']); [names_(c) for c in g['children'] if isinstance(c, dict)]
    for g in d['outliner']: names_(g)
    for need in ('root', 'hitbox'):
        if need not in allnames: errs.append('missing bone ' + need)
    anim = {a['name'] for a in d['animations']}
    if not {'idle', 'spawn', 'death'} <= anim: errs.append('missing core animations')
    return d, im, errs

def render(d, im, size=300):
    tiles = [[tuple(int(v) for v in Image.Image.resize(im.crop(((i % 4) * 16, (i // 4) * 16, (i % 4) * 16 + 16, (i // 4) * 16 + 16)), (1, 1)).convert('RGB').getpixel((0, 0))) for i in range(16)]][0]
    els = [e for e in d['elements'] if not e['name'].startswith('hitbox')]
    pts = []
    def P(x, y, z): return ((x - z) * math.cos(math.radians(30)), (x + z) * math.sin(math.radians(30)) - y)
    polys = []
    for e in els:
        (x0, y0, z0), (x1, y1, z1) = e['from'], e['to']; col = tiles[e['faces']['north']['uv'][0] // 16 + (e['faces']['north']['uv'][1] // 16) * 4]
        depth = (x0 + x1) / 2 + (z0 + z1) / 2 + (y0 + y1) / 2 * 0.01
        top = [P(x0, y1, z0), P(x1, y1, z0), P(x1, y1, z1), P(x0, y1, z1)]; left = [P(x0, y0, z1), P(x1, y0, z1), P(x1, y1, z1), P(x0, y1, z1)]; right = [P(x1, y0, z0), P(x1, y0, z1), P(x1, y1, z1), P(x1, y1, z0)]
        polys.append((depth, [(top, tuple(min(255, int(c * 1.2)) for c in col)), (left, tuple(int(c * 0.8) for c in col)), (right, tuple(int(c * 0.6) for c in col))]))
        pts += top + left + right
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]; w = max(xs) - min(xs); h = max(ys) - min(ys); s = (size - 20) / max(w, h, 1)
    img = Image.new('RGB', (size, size), (14, 16, 24)); dr = ImageDraw.Draw(img)
    for _, fs in sorted(polys, key=lambda p: p[0]):
        for poly, col in fs: dr.polygon([((x - min(xs)) * s + 10, (y - min(ys)) * s + 10) for x, y in poly], fill=col, outline=(0, 0, 0))
    return img

bad = 0
for f in files:
    d, im, errs = validate(f)
    if errs: bad += 1; print('INVALID', os.path.basename(f), errs)
print('validated', len(files), 'models;', 'problems:', bad)
sheet = ['rootmind', 'forge_prime', 'subject_zero', 'the_warden', 'absolute', 'the_parallax', 'admiral_vexar', 'xerath_null']
S = 280; img = Image.new('RGB', (S * 4, S * 2))
for i, n in enumerate(sheet):
    d, im, _ = validate(os.path.join(ROOT, 'modelengine/blueprints', n + '.bbmodel'))
    img.paste(render(d, im, S), ((i % 4) * S, (i // 4) * S))
os.makedirs(os.path.join(ROOT, 'docs'), exist_ok=True); img.save(os.path.join(ROOT, 'docs/model_previews.png')); print('preview saved')
