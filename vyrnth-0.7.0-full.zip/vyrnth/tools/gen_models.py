#!/usr/bin/env python3
"""Generates ModelEngine-ready Blockbench (.bbmodel) blueprints with procedural textures and animations.
These are blocky, parametric models (cubes + keyframes), good enough to play with and to use as rigs; refine them in Blockbench for final art.
Output: modelengine/blueprints/<id>.bbmodel  ->  copy into plugins/ModelEngine/blueprints/"""
import json, uuid, math, base64, io, os, sys
import numpy as np
from PIL import Image

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'modelengine/blueprints')
os.makedirs(OUT, exist_ok=True)
def U(): return str(uuid.uuid4())

THEMES = {
 'verdant': dict(plate=(52, 86, 44),  dark=(28, 46, 26),  glow=(190, 255, 90),  accent=(122, 74, 42), detail=(86, 124, 62), eye=(255, 240, 80), core=(150, 255, 120), trim=(92, 62, 36)),
 'steel':   dict(plate=(92, 96, 104), dark=(40, 42, 48),  glow=(255, 140, 40),  accent=(176, 104, 52), detail=(130, 134, 142), eye=(255, 200, 60), core=(255, 110, 30), trim=(70, 74, 82)),
 'void':    dict(plate=(214, 210, 230), dark=(90, 60, 140), glow=(190, 90, 255), accent=(150, 110, 220), detail=(240, 236, 250), eye=(255, 255, 255), core=(220, 120, 255), trim=(120, 90, 180)),
 'neon':    dict(plate=(38, 44, 60),  dark=(18, 20, 30),  glow=(60, 230, 255), accent=(30, 120, 200), detail=(70, 80, 104), eye=(255, 60, 90), core=(80, 255, 255), trim=(24, 28, 40)),
 'ice':     dict(plate=(196, 226, 246), dark=(110, 160, 210), glow=(200, 255, 255), accent=(150, 200, 240), detail=(235, 248, 255), eye=(120, 220, 255), core=(180, 250, 255), trim=(90, 140, 190)),
 'cosmic':  dict(plate=(70, 40, 110), dark=(30, 16, 56),  glow=(255, 90, 220),  accent=(230, 190, 80), detail=(120, 80, 170), eye=(255, 240, 160), core=(255, 120, 240), trim=(190, 150, 60)),
 'crimson': dict(plate=(70, 24, 28),  dark=(26, 10, 12),  glow=(255, 70, 50),   accent=(214, 170, 60), detail=(110, 40, 44), eye=(255, 220, 80), core=(255, 90, 60), trim=(180, 140, 50)),
 'null':    dict(plate=(24, 16, 40),  dark=(8, 4, 16),    glow=(255, 60, 200),  accent=(110, 40, 180), detail=(60, 36, 100), eye=(255, 255, 255), core=(255, 80, 220), trim=(80, 40, 140)),
}

def texture(theme):
    t = THEMES[theme]; rng = np.random.default_rng(sum(map(ord, theme)))
    img = Image.new('RGBA', (64, 64))
    def patch(base, var=14, lines=None, stripes=None, radial=None, dots=False):
        a = np.zeros((16, 16, 4), dtype=np.uint8); a[..., 3] = 255
        n = rng.integers(-var, var + 1, (16, 16, 1))
        a[..., :3] = np.clip(np.array(base)[None, None, :] + n, 0, 255)
        if lines: a[0, :, :3] = np.clip(np.array(lines), 0, 255); a[:, 0, :3] = np.clip(np.array(lines), 0, 255); a[15, :, :3] = np.clip(np.array(lines) * 0.6, 0, 255); a[:, 15, :3] = np.clip(np.array(lines) * 0.6, 0, 255)
        if stripes:
            for y in range(16):
                if (y // 3) % 2 == 0: a[y, :, :3] = np.clip(np.array(stripes), 0, 255)
        if radial:
            yy, xx = np.mgrid[0:16, 0:16]; d = np.sqrt((xx - 7.5) ** 2 + (yy - 7.5) ** 2) / 8
            a[..., :3] = np.clip(np.array(radial)[None, None, :] * (1.15 - d[..., None] * 0.9) + np.array(base)[None, None, :] * d[..., None] * 0.5, 0, 255)
        if dots:
            for _ in range(6): a[rng.integers(1, 15), rng.integers(1, 15), :3] = np.clip(np.array(t['glow']), 0, 255)
        return Image.fromarray(a, 'RGBA')
    tiles = [patch(t['plate'], 12, lines=t['trim']), patch(t['dark'], 8), patch(t['glow'], 10, radial=t['glow']), patch(t['accent'], 12, stripes=t['trim']),
             patch(t['detail'], 14, dots=True), patch(t['eye'], 4, radial=t['eye']), patch(t['core'], 6, radial=t['core']), patch(t['trim'], 10, lines=t['dark'])]
    tiles += [patch(t['plate'], 18) for _ in range(8)]
    for i, p in enumerate(tiles): img.paste(p, ((i % 4) * 16, (i // 4) * 16))
    buf = io.BytesIO(); img.save(buf, 'PNG'); return base64.b64encode(buf.getvalue()).decode()

PLATE, DARK, GLOW, ACCENT, DETAIL, EYE, CORE, TRIM = range(8)

class M:
    def __init__(s, mid, theme): s.mid, s.theme, s.bones, s.cubes, s.anims = mid, theme, {}, [], []
    def bone(s, name, origin, parent=None): s.bones[name] = dict(origin=[float(x) for x in origin], parent=parent, uuid=U(), cubes=[]); return name
    def cube(s, bone, a, b, tile, rot=None):
        lo = [min(a[i], b[i]) for i in range(3)]; hi = [max(a[i], b[i]) for i in range(3)]
        for i in range(3):
            if hi[i] - lo[i] < 0.01: hi[i] = lo[i] + 0.25
        c = dict(uuid=U(), frm=lo, to=hi, tile=tile, rot=rot, name='%s_%d' % (bone, len(s.cubes)))
        s.cubes.append(c); s.bones[bone]['cubes'].append(c['uuid'])
    def anim(s, name, length, loop, tracks): s.anims.append((name, length, loop, tracks))
    def bbox(s):
        lo = [min(c['frm'][i] for c in s.cubes) for i in range(3)]; hi = [max(c['to'][i] for c in s.cubes) for i in range(3)]
        return [(hi[i] - lo[i]) / 16 for i in range(3)]

    def to_json(s):
        faces = lambda tile: {f: {'uv': [(tile % 4) * 16, (tile // 4) * 16, (tile % 4) * 16 + 16, (tile // 4) * 16 + 16], 'texture': 0} for f in ('north', 'east', 'south', 'west', 'up', 'down')}
        elements = []
        owner = {u: b for b, d in s.bones.items() for u in d['cubes']}
        for c in s.cubes:
            o = s.bones[owner[c['uuid']]]['origin']
            e = {'name': c['name'], 'box_uv': False, 'rescale': False, 'locked': False, 'light_emission': 0, 'render_order': 'default', 'allow_mirror_modeling': True,
                 'from': c['frm'], 'to': c['to'], 'autouv': 0, 'color': 0, 'origin': o, 'uuid': c['uuid'], 'faces': faces(c['tile']), 'type': 'cube'}
            if c['rot']: e['rotation'] = c['rot']
            elements.append(e)
        def group(name):
            b = s.bones[name]
            kids = list(b['cubes']) + [group(n) for n, d in s.bones.items() if d['parent'] == name]
            return {'name': name, 'origin': b['origin'], 'color': 0, 'uuid': b['uuid'], 'export': True, 'mirror_uv': False, 'isOpen': True, 'locked': False, 'visibility': True, 'autouv': 0, 'children': kids}
        outliner = [group(n) for n, d in s.bones.items() if d['parent'] is None]
        anims = []
        for name, length, loop, tracks in s.anims:
            animators = {}
            for bone, kfs in tracks.items():
                if bone not in s.bones: continue
                animators[s.bones[bone]['uuid']] = {'name': bone, 'type': 'bone', 'keyframes': [
                    {'channel': ch, 'data_points': [{'x': str(round(v[0], 3)), 'y': str(round(v[1], 3)), 'z': str(round(v[2], 3))}], 'uuid': U(), 'time': t, 'color': -1, 'interpolation': 'linear'} for ch, t, v in kfs]}
            anims.append({'uuid': U(), 'name': name, 'loop': loop, 'override': False, 'length': length, 'snapping': 20, 'selected': False, 'anim_time_update': '', 'blend_weight': '', 'start_delay': '', 'loop_delay': '', 'animators': animators})
        return {'meta': {'format_version': '4.10', 'model_format': 'free', 'box_uv': False}, 'name': s.mid, 'model_identifier': '', 'visible_box': [4, 4, 0], 'variable_placeholders': '',
                'variable_placeholder_buttons': [], 'timeline_setups': [], 'unhandled_root_fields': {}, 'resolution': {'width': 64, 'height': 64}, 'elements': elements, 'outliner': outliner,
                'textures': [{'path': '', 'name': s.mid + '.png', 'folder': '', 'namespace': '', 'id': '0', 'particle': False, 'render_mode': 'default', 'render_sides': 'auto', 'frame_time': 1,
                              'frame_order_type': 'loop', 'frame_order': '', 'frame_interpolate': False, 'visible': True, 'internal': True, 'saved': True, 'uuid': U(),
                              'source': 'data:image/png;base64,' + texture(s.theme)}], 'animations': anims}

def swing(bone, ch, amp, period, axis=0, phase=0.0, base=(0, 0, 0)):
    def v(a): r = list(base); r[axis] += a; return tuple(r)
    return {bone: [(ch, 0, v(amp * math.sin(phase))), (ch, period / 4, v(amp * math.sin(phase + math.pi / 2))), (ch, period / 2, v(amp * math.sin(phase + math.pi))),
                   (ch, 3 * period / 4, v(amp * math.sin(phase + 3 * math.pi / 2))), (ch, period, v(amp * math.sin(phase)))]}
def merge(*ds):
    out = {}
    for d in ds:
        for b, k in d.items(): out.setdefault(b, []).extend(k)
    return out
def spawn_death(m, root='root', height=40):
    m.anim('spawn', 1.0, 'once', {root: [('scale', 0, (0.01, 0.01, 0.01)), ('scale', 1.0, (1, 1, 1))]})
    m.anim('death', 2.0, 'hold', {root: [('rotation', 0, (0, 0, 0)), ('rotation', 1.2, (75, 0, 0)), ('position', 0, (0, 0, 0)), ('position', 1.2, (0, -height * 0.3, 0)),
                                         ('scale', 1.6, (1, 1, 1)), ('scale', 2.0, (0.01, 0.01, 0.01))]})

# ---------------------------------------------------------------- archetypes (units are pixels; 16 px = 1 block)
def mech(m, k=1.0, bulk=1.0, spikes=False, cannons=True, plate=PLATE):
    m.bone('root', (0, 0, 0)); m.bone('hitbox', (0, 0, 0), 'root'); m.cube('hitbox', (-9 * k * bulk, 0, -6 * k), (9 * k * bulk, 50 * k, 6 * k), DARK)
    for sx, nm in ((-1, 'leg_r'), (1, 'leg_l')):
        m.bone(nm, (sx * 4.5 * k * bulk, 24 * k, 0), 'root')
        m.cube(nm, (sx * 2 * k * bulk, 0, -3.5 * k), (sx * 7 * k * bulk, 24 * k, 3.5 * k), plate); m.cube(nm, (sx * 1.5 * k * bulk, 0, -5 * k), (sx * 7.5 * k * bulk, 3 * k, 5 * k), DARK)
    m.bone('body', (0, 24 * k, 0), 'root')
    m.cube('body', (-8 * k * bulk, 24 * k, -5 * k), (8 * k * bulk, 42 * k, 5 * k), plate); m.cube('body', (-5 * k, 28 * k, -5.6 * k), (5 * k, 36 * k, -4.9 * k), CORE)
    m.cube('body', (-9 * k * bulk, 38 * k, -5.5 * k), (9 * k * bulk, 42 * k, 5.5 * k), TRIM)
    if cannons:
        m.cube('body', (-7 * k, 34 * k, 5 * k), (-3 * k, 46 * k, 8 * k), DARK); m.cube('body', (3 * k, 34 * k, 5 * k), (7 * k, 46 * k, 8 * k), DARK)
    m.bone('head', (0, 42 * k, 0), 'body')
    m.cube('head', (-4.5 * k, 42 * k, -4.5 * k), (4.5 * k, 50 * k, 4.5 * k), plate); m.cube('head', (-3.5 * k, 45 * k, -4.9 * k), (3.5 * k, 47 * k, -4.5 * k), EYE)
    if spikes:
        for sx in (-1, 1):
            m.cube('body', (sx * 9 * k * bulk, 42 * k, -1 * k), (sx * 13 * k * bulk, 54 * k, 1 * k), DETAIL, rot=[0, 0, sx * 20]); m.cube('head', (sx * 2 * k, 50 * k, -1 * k), (sx * 4 * k, 58 * k, 1 * k), DETAIL)
    for sx, nm in ((-1, 'arm_r'), (1, 'arm_l')):
        m.bone(nm, (sx * 10.5 * k * bulk, 40 * k, 0), 'body')
        m.cube(nm, (sx * 8.5 * k * bulk, 28 * k, -3 * k), (sx * 13.5 * k * bulk, 42 * k, 3 * k), plate); m.cube(nm, (sx * 8 * k * bulk, 22 * k, -3.5 * k), (sx * 14 * k * bulk, 29 * k, 3.5 * k), ACCENT)
    m.cube('arm_r', (-14 * k * bulk, 12 * k, -2 * k), (-8 * k * bulk, 24 * k, 2 * k), DARK); m.cube('arm_r', (-12 * k * bulk, 8 * k, -1 * k), (-10 * k * bulk, 14 * k, 1 * k), GLOW)
    P = 1.2
    m.anim('idle', 3.0, 'loop', merge(swing('body', 'rotation', 2, 3, 0), swing('head', 'rotation', 4, 3, 1, 1.0), swing('arm_r', 'rotation', 4, 3, 0, 0.5), swing('arm_l', 'rotation', 4, 3, 0, 2.5)))
    m.anim('walk', P, 'loop', merge(swing('leg_r', 'rotation', 32, P, 0), swing('leg_l', 'rotation', 32, P, 0, math.pi), swing('arm_r', 'rotation', 24, P, 0, math.pi),
                                     swing('arm_l', 'rotation', 24, P, 0), {'body': [('position', 0, (0, 0, 0)), ('position', P / 4, (0, 1.5, 0)), ('position', P / 2, (0, 0, 0)), ('position', 3 * P / 4, (0, 1.5, 0)), ('position', P, (0, 0, 0))]}))
    m.anim('attack', 1.2, 'once', {'arm_r': [('rotation', 0, (0, 0, 0)), ('rotation', 0.35, (-110, 0, 0)), ('rotation', 0.6, (40, 0, 0)), ('rotation', 1.2, (0, 0, 0))],
                                   'body': [('rotation', 0, (0, 0, 0)), ('rotation', 0.35, (-8, 18, 0)), ('rotation', 0.6, (10, -12, 0)), ('rotation', 1.2, (0, 0, 0))]})
    m.anim('special', 2.5, 'once', {'arm_r': [('rotation', 0, (0, 0, 0)), ('rotation', 0.8, (-160, 0, -20)), ('rotation', 2.5, (0, 0, 0))], 'arm_l': [('rotation', 0, (0, 0, 0)), ('rotation', 0.8, (-160, 0, 20)), ('rotation', 2.5, (0, 0, 0))],
                                    'body': [('scale', 0, (1, 1, 1)), ('scale', 0.8, (1.08, 1.08, 1.08)), ('scale', 2.5, (1, 1, 1))]})
    m.anim('stagger', 0.6, 'once', {'body': [('rotation', 0, (0, 0, 0)), ('rotation', 0.15, (-14, 0, 0)), ('rotation', 0.6, (0, 0, 0))]})
    m.anim('transition', 3.0, 'once', {'body': [('scale', 0, (1, 1, 1)), ('scale', 1.2, (1.15, 1.15, 1.15)), ('scale', 3.0, (1, 1, 1))], 'head': [('rotation', 0, (0, 0, 0)), ('rotation', 1.2, (-25, 0, 0)), ('rotation', 3.0, (0, 0, 0))]})
    spawn_death(m, 'root', 50 * k)

def organism(m, k=1.0):
    m.bone('root', (0, 0, 0)); m.bone('hitbox', (0, 0, 0), 'root'); m.cube('hitbox', (-14 * k, 0, -14 * k), (14 * k, 56 * k, 14 * k), DARK)
    m.bone('trunk', (0, 0, 0), 'root')
    for lo, hi, w, tile in ((0, 14, 12, PLATE), (14, 30, 9.5, DETAIL), (30, 46, 7, PLATE), (46, 56, 5, ACCENT)):
        m.cube('trunk', (-w * k, lo * k, -w * k), (w * k, hi * k, w * k), tile)
    for i, a in enumerate((0, 120, 240)):
        x, z = 10 * k * math.sin(math.radians(a)), 10 * k * math.cos(math.radians(a))
        m.bone('organ%d' % (i + 1), (x, 20 * k + i * 8 * k, z), 'trunk'); m.cube('organ%d' % (i + 1), (x - 3 * k, 18 * k + i * 8 * k, z - 3 * k), (x + 3 * k, 24 * k + i * 8 * k, z + 3 * k), CORE)
    m.bone('maw', (0, 50 * k, -4 * k), 'trunk'); m.cube('maw', (-4 * k, 46 * k, -6 * k), (4 * k, 50 * k, -3 * k), DARK); m.cube('maw', (-3 * k, 50 * k, -6 * k), (3 * k, 53 * k, -3 * k), EYE)
    for i in range(6):
        a = math.radians(i * 60 + 30); parent = 'trunk'
        for seg in range(3):
            d = (13 + seg * 6) * k; half = (5 - seg * 1.2) * k; cx, cz = d * math.sin(a), d * math.cos(a)
            name = 't%d_%d' % (i, seg); m.bone(name, (cx, (4 + seg) * k, cz), parent)
            m.cube(name, (cx - half, (1 + seg * 1.5) * k, cz - half), (cx + half, (1 + seg * 1.5) * k + 2 * half, cz + half), DETAIL if seg % 2 else ACCENT)
            parent = name
    tr = {}
    for i in range(6):
        for seg in range(3): tr = merge(tr, swing('t%d_%d' % (i, seg), 'rotation', 14, 3.0, 2, i * 1.05 + seg * 0.5))
    m.anim('idle', 3.0, 'loop', merge(tr, swing('trunk', 'rotation', 2, 3.0, 2), swing('organ1', 'scale', 0.12, 1.5, 0, 0, (1, 1, 1))))
    m.anim('walk', 3.0, 'loop', tr)
    m.anim('attack', 1.4, 'once', {'maw': [('rotation', 0, (0, 0, 0)), ('rotation', 0.4, (-35, 0, 0)), ('rotation', 1.4, (0, 0, 0))], 'trunk': [('rotation', 0, (0, 0, 0)), ('rotation', 0.5, (-14, 0, 0)), ('rotation', 1.4, (0, 0, 0))]})
    m.anim('special', 2.5, 'once', {'trunk': [('scale', 0, (1, 1, 1)), ('scale', 1.0, (1.12, 1.12, 1.12)), ('scale', 2.5, (1, 1, 1))], 'maw': [('rotation', 0, (0, 0, 0)), ('rotation', 1.0, (-40, 0, 0)), ('rotation', 2.5, (0, 0, 0))]})
    m.anim('stagger', 0.6, 'once', {'trunk': [('rotation', 0, (0, 0, 0)), ('rotation', 0.15, (-10, 0, 6)), ('rotation', 0.6, (0, 0, 0))]})
    m.anim('transition', 3.0, 'once', {'trunk': [('scale', 0, (1, 1, 1)), ('scale', 1.4, (1.2, 1.2, 1.2)), ('scale', 3.0, (1, 1, 1))]})
    spawn_death(m, 'root', 56 * k)

def entity(m, k=1.0):
    m.bone('root', (0, 0, 0)); m.bone('hitbox', (0, 0, 0), 'root'); m.cube('hitbox', (-8 * k, 4 * k, -8 * k), (8 * k, 52 * k, 8 * k), DARK)
    m.bone('core', (0, 28 * k, 0), 'root'); m.cube('core', (-7 * k, 21 * k, -5 * k), (7 * k, 35 * k, 5 * k), PLATE); m.cube('core', (-3 * k, 25 * k, -5.6 * k), (3 * k, 31 * k, -4.9 * k), CORE)
    m.bone('head', (0, 37 * k, 0), 'core'); m.cube('head', (-4 * k, 36 * k, -4 * k), (4 * k, 44 * k, 4 * k), DETAIL)
    for sx in (-1.5, 0, 1.5): m.cube('head', (sx * 2 * k - 0.8 * k, 39 * k, -4.4 * k), (sx * 2 * k + 0.8 * k, 41 * k, -4 * k), EYE)
    for sx, nm in ((-1, 'arm_r'), (1, 'arm_l')):
        m.bone(nm, (sx * 7 * k, 33 * k, 0), 'core'); m.cube(nm, (sx * 6 * k, 8 * k, -1.5 * k), (sx * 9 * k, 33 * k, 1.5 * k), DETAIL); m.cube(nm, (sx * 5 * k, 3 * k, -3 * k), (sx * 10 * k, 9 * k, 3 * k), ACCENT)
    for i in range(4):
        a = math.radians(i * 90 + 20); x, z = 16 * k * math.sin(a), 16 * k * math.cos(a); nm = 'shard%d' % (i + 1)
        m.bone(nm, (0, 28 * k, 0), 'root'); m.cube(nm, (x - 3 * k, 22 * k + i * 4 * k, z - 3 * k), (x + 3 * k, 32 * k + i * 4 * k, z + 3 * k), GLOW if i % 2 else ACCENT, rot=[20 * i, 35, 15])
    orb = {('shard%d' % (i + 1)): [('rotation', 0, (0, 0, 0)), ('rotation', 6.0, (0, 360 if i % 2 else -360, 0))] for i in range(4)}
    m.anim('idle', 4.0, 'loop', merge(orb, swing('core', 'position', 1.5, 4.0, 1), swing('head', 'rotation', 8, 4.0, 1, 1.0)))
    m.anim('walk', 3.0, 'loop', merge(orb, swing('core', 'rotation', 10, 3.0, 0), swing('arm_r', 'rotation', 18, 3.0, 0), swing('arm_l', 'rotation', 18, 3.0, 0, math.pi)))
    m.anim('attack', 1.2, 'once', {'arm_r': [('rotation', 0, (0, 0, 0)), ('rotation', 0.3, (-120, 0, 0)), ('rotation', 0.55, (50, 0, 0)), ('rotation', 1.2, (0, 0, 0))], 'core': [('rotation', 0, (0, 0, 0)), ('rotation', 0.3, (0, 25, 0)), ('rotation', 1.2, (0, 0, 0))]})
    m.anim('special', 2.5, 'once', {'core': [('scale', 0, (1, 1, 1)), ('scale', 0.8, (1.2, 1.2, 1.2)), ('scale', 1.0, (0.85, 0.85, 0.85)), ('scale', 2.5, (1, 1, 1))], 'arm_r': [('rotation', 0, (0, 0, 0)), ('rotation', 0.8, (-170, 0, -25)), ('rotation', 2.5, (0, 0, 0))], 'arm_l': [('rotation', 0, (0, 0, 0)), ('rotation', 0.8, (-170, 0, 25)), ('rotation', 2.5, (0, 0, 0))]})
    m.anim('stagger', 0.6, 'once', {'core': [('rotation', 0, (0, 0, 0)), ('rotation', 0.15, (-16, 0, 10)), ('rotation', 0.6, (0, 0, 0))]})
    m.anim('transition', 3.0, 'once', {'core': [('scale', 0, (1, 1, 1)), ('scale', 1.4, (0.5, 0.5, 0.5)), ('scale', 3.0, (1, 1, 1))]})
    spawn_death(m, 'root', 52 * k)

def orbital(m, k=1.0):
    m.bone('root', (0, 0, 0)); m.bone('hitbox', (0, 0, 0), 'root'); m.cube('hitbox', (-12 * k, 0, -12 * k), (12 * k, 48 * k, 12 * k), DARK)
    m.bone('core', (0, 26 * k, 0), 'root'); m.cube('core', (-6 * k, 20 * k, -6 * k), (6 * k, 32 * k, 6 * k), PLATE); m.cube('core', (-3.5 * k, 22.5 * k, -6.5 * k), (3.5 * k, 29.5 * k, -5.9 * k), CORE)
    m.cube('core', (-1.2 * k, 32 * k, -1.2 * k), (1.2 * k, 44 * k, 1.2 * k), GLOW)
    ax = ((0, 1, 0), (1, 0, 0), (0, 0, 1)); rr = (11 * k, 15 * k, 19 * k)
    for ri in range(3):
        nm = 'ring%d' % (ri + 1); m.bone(nm, (0, 26 * k, 0), 'root')
        for j in range(10):
            a = math.radians(j * 36); px, py = rr[ri] * math.cos(a), rr[ri] * math.sin(a)
            c = [0, 26 * k, 0]; pos = [px, py, 0] if ri == 0 else ([0, py, px] if ri == 1 else [px, 0, py])
            m.cube(nm, (pos[0] - 1.6 * k, 26 * k + pos[1] - 1.6 * k, pos[2] - 1.6 * k), (pos[0] + 1.6 * k, 26 * k + pos[1] + 1.6 * k, pos[2] + 1.6 * k), ACCENT if j % 3 else GLOW)
    spin = {('ring%d' % (i + 1)): [('rotation', 0, (0, 0, 0)), ('rotation', 8.0 / (i + 1), tuple(360 * a * (1 if i != 1 else -1) for a in ax[i]))] for i in range(3)}
    m.anim('idle', 8.0, 'loop', merge(spin, swing('core', 'position', 2, 4.0, 1)))
    m.anim('walk', 8.0, 'loop', spin)
    m.anim('attack', 1.4, 'once', {'core': [('scale', 0, (1, 1, 1)), ('scale', 0.4, (1.3, 1.3, 1.3)), ('scale', 0.55, (0.9, 0.9, 0.9)), ('scale', 1.4, (1, 1, 1))]})
    m.anim('special', 3.0, 'once', {'ring1': [('scale', 0, (1, 1, 1)), ('scale', 1.2, (1.6, 1.6, 1.6)), ('scale', 3.0, (1, 1, 1))], 'ring2': [('scale', 0, (1, 1, 1)), ('scale', 1.2, (1.4, 1.4, 1.4)), ('scale', 3.0, (1, 1, 1))],
                                   'ring3': [('scale', 0, (1, 1, 1)), ('scale', 1.2, (1.25, 1.25, 1.25)), ('scale', 3.0, (1, 1, 1))]})
    m.anim('stagger', 0.6, 'once', {'core': [('rotation', 0, (0, 0, 0)), ('rotation', 0.15, (0, 0, 14)), ('rotation', 0.6, (0, 0, 0))]})
    m.anim('transition', 3.0, 'once', {'core': [('scale', 0, (1, 1, 1)), ('scale', 1.4, (0.4, 0.4, 0.4)), ('scale', 3.0, (1.1, 1.1, 1.1))]})
    spawn_death(m, 'root', 48 * k)

def bot(m, k=0.6, theme_tile=PLATE): mech(m, k, 1.0, False, False, theme_tile)

def crawler(m, k=1.0):
    m.bone('root', (0, 0, 0)); m.bone('hitbox', (0, 0, 0), 'root'); m.cube('hitbox', (-8 * k, 0, -10 * k), (8 * k, 10 * k, 10 * k), DARK)
    m.bone('body', (0, 6 * k, 0), 'root'); m.cube('body', (-5 * k, 3 * k, -8 * k), (5 * k, 10 * k, 5 * k), PLATE); m.cube('body', (-4 * k, 4 * k, 5 * k), (4 * k, 9 * k, 11 * k), ACCENT); m.cube('body', (-3 * k, 6 * k, -9 * k), (3 * k, 9 * k, -7 * k), EYE)
    for i in range(6):
        sx = -1 if i % 2 == 0 else 1; z = -5 + (i // 2) * 5; nm = 'leg%d' % i
        m.bone(nm, (sx * 5 * k, 6 * k, z * k), 'body'); m.cube(nm, (sx * 5 * k, 5 * k, (z - 0.8) * k), (sx * 13 * k, 7 * k, (z + 0.8) * k), DETAIL, rot=[0, 0, sx * 25])
    tr = {}
    for i in range(6): tr = merge(tr, swing('leg%d' % i, 'rotation', 22, 0.8, 1, (i % 3) * 2.1 + (math.pi if i % 2 else 0)))
    m.anim('idle', 2.0, 'loop', swing('body', 'position', 0.6, 2.0, 1)); m.anim('walk', 0.8, 'loop', tr)
    m.anim('attack', 0.8, 'once', {'body': [('position', 0, (0, 0, 0)), ('position', 0.2, (0, 2, -4)), ('position', 0.8, (0, 0, 0))]})
    m.anim('stagger', 0.5, 'once', {'body': [('rotation', 0, (0, 0, 0)), ('rotation', 0.12, (-18, 0, 0)), ('rotation', 0.5, (0, 0, 0))]})
    spawn_death(m, 'root', 10 * k)

def drone(m, k=1.0):
    m.bone('root', (0, 0, 0)); m.bone('hitbox', (0, 0, 0), 'root'); m.cube('hitbox', (-8 * k, 4 * k, -8 * k), (8 * k, 18 * k, 8 * k), DARK)
    m.bone('body', (0, 12 * k, 0), 'root'); m.cube('body', (-4 * k, 8 * k, -4 * k), (4 * k, 16 * k, 4 * k), PLATE); m.cube('body', (-2 * k, 11 * k, -4.6 * k), (2 * k, 13 * k, -4 * k), EYE)
    m.bone('wing_r', (-4 * k, 14 * k, 0), 'body'); m.cube('wing_r', (-14 * k, 13.5 * k, -3 * k), (-4 * k, 14.5 * k, 3 * k), DETAIL)
    m.bone('wing_l', (4 * k, 14 * k, 0), 'body'); m.cube('wing_l', (4 * k, 13.5 * k, -3 * k), (14 * k, 14.5 * k, 3 * k), DETAIL)
    m.bone('rotor', (0, 17 * k, 0), 'body'); m.cube('rotor', (-5 * k, 17 * k, -0.5 * k), (5 * k, 17.6 * k, 0.5 * k), ACCENT); m.cube('rotor', (-0.5 * k, 17 * k, -5 * k), (0.5 * k, 17.6 * k, 5 * k), ACCENT)
    fl = merge(swing('wing_r', 'rotation', 14, 0.5, 2), swing('wing_l', 'rotation', 14, 0.5, 2, math.pi), {'rotor': [('rotation', 0, (0, 0, 0)), ('rotation', 0.3, (0, 360, 0))]})
    m.anim('idle', 1.0, 'loop', merge(fl, swing('body', 'position', 1.2, 1.0, 1))); m.anim('walk', 0.6, 'loop', merge(fl, {'body': [('rotation', 0, (14, 0, 0)), ('rotation', 0.6, (14, 0, 0))]}))
    m.anim('attack', 0.7, 'once', {'body': [('rotation', 0, (0, 0, 0)), ('rotation', 0.2, (-24, 0, 0)), ('rotation', 0.7, (0, 0, 0))]}); spawn_death(m, 'root', 16 * k)

def turret(m, k=1.0):
    m.bone('root', (0, 0, 0)); m.bone('hitbox', (0, 0, 0), 'root'); m.cube('hitbox', (-7 * k, 0, -7 * k), (7 * k, 18 * k, 7 * k), DARK)
    m.cube('root', (-6 * k, 0, -6 * k), (6 * k, 6 * k, 6 * k), DARK); m.cube('root', (-4 * k, 6 * k, -4 * k), (4 * k, 10 * k, 4 * k), PLATE)
    m.bone('head', (0, 12 * k, 0), 'root'); m.cube('head', (-5 * k, 10 * k, -5 * k), (5 * k, 16 * k, 5 * k), PLATE); m.cube('head', (-2 * k, 12 * k, -5.6 * k), (2 * k, 14 * k, -5 * k), EYE)
    m.bone('barrel', (0, 13 * k, -5 * k), 'head'); m.cube('barrel', (-1.2 * k, 12 * k, -14 * k), (1.2 * k, 14.4 * k, -5 * k), ACCENT)
    m.anim('idle', 4.0, 'loop', swing('head', 'rotation', 28, 4.0, 1)); m.anim('attack', 0.5, 'once', {'barrel': [('position', 0, (0, 0, 0)), ('position', 0.1, (0, 0, 3 * k)), ('position', 0.5, (0, 0, 0))]}); spawn_death(m, 'root', 16 * k)

def node(m, k=1.0):
    m.bone('root', (0, 0, 0)); m.bone('hitbox', (0, 0, 0), 'root'); m.cube('hitbox', (-8 * k, 0, -8 * k), (8 * k, 34 * k, 8 * k), DARK)
    m.cube('root', (-7 * k, 0, -7 * k), (7 * k, 5 * k, 7 * k), DARK); m.cube('root', (-4 * k, 5 * k, -4 * k), (4 * k, 12 * k, 4 * k), PLATE)
    m.bone('crystal', (0, 22 * k, 0), 'root'); m.cube('crystal', (-3.5 * k, 14 * k, -3.5 * k), (3.5 * k, 30 * k, 3.5 * k), CORE, rot=[0, 45, 0]); m.cube('crystal', (-2 * k, 30 * k, -2 * k), (2 * k, 34 * k, 2 * k), GLOW, rot=[0, 45, 0])
    m.bone('ring', (0, 22 * k, 0), 'root')
    for j in range(8):
        a = math.radians(j * 45); x, z = 8 * k * math.cos(a), 8 * k * math.sin(a); m.cube('ring', (x - 1.2 * k, 21 * k, z - 1.2 * k), (x + 1.2 * k, 23.4 * k, z + 1.2 * k), ACCENT)
    m.anim('idle', 4.0, 'loop', merge({'ring': [('rotation', 0, (0, 0, 0)), ('rotation', 4.0, (0, 360, 0))], 'crystal': [('rotation', 0, (0, 0, 0)), ('rotation', 8.0, (0, -360, 0))]}, swing('crystal', 'scale', 0.1, 2.0, 0, 0, (1, 1, 1))))
    m.anim('attack', 0.8, 'once', {'crystal': [('scale', 0, (1, 1, 1)), ('scale', 0.3, (1.4, 1.4, 1.4)), ('scale', 0.8, (1, 1, 1))]}); spawn_death(m, 'root', 34 * k)

ARCH = dict(mech=mech, organism=organism, entity=entity, orbital=orbital, bot=bot, crawler=crawler, drone=drone, turret=turret, node=node)
# id: (archetype, theme, scale, kwargs)
MODELS = {
 # bosses (6 blocks / 4.5 blocks tall etc.)
 'rootmind': ('organism', 'verdant', 2.2, {}), 'forge_prime': ('mech', 'steel', 2.4, dict(bulk=1.25, spikes=False)), 'subject_zero': ('entity', 'void', 2.2, {}),
 'the_warden': ('mech', 'neon', 2.5, dict(bulk=1.15, spikes=True)), 'absolute': ('mech', 'ice', 2.6, dict(bulk=1.4, spikes=True, cannons=False)), 'the_parallax': ('orbital', 'cosmic', 2.6, {}),
 'admiral_vexar': ('mech', 'crimson', 2.6, dict(bulk=1.3, spikes=True)), 'xerath_null': ('orbital', 'null', 3.4, {}),
 # mini / secret bosses
 'foreman': ('mech', 'steel', 1.5, dict(bulk=1.3)), 'cryowarden': ('mech', 'ice', 1.6, dict(bulk=1.35, spikes=True, cannons=False)), 'aberration': ('entity', 'void', 1.5, {}),
 'machine_guardian': ('mech', 'null', 1.9, dict(bulk=1.3, spikes=True)), 'thornwarden': ('mech', 'verdant', 1.5, dict(bulk=1.3, spikes=True, cannons=False)), 'line_commander': ('mech', 'crimson', 1.4, dict(bulk=1.2)),
 'seedmother': ('organism', 'verdant', 1.3, {}), 'scrapking': ('mech', 'steel', 1.7, dict(bulk=1.5, spikes=True)), 'observer': ('entity', 'void', 1.6, {}), 'black_ice': ('entity', 'neon', 1.5, {}),
 'frozen_founder': ('entity', 'ice', 1.6, {}), 'echo_of_nothing': ('orbital', 'cosmic', 1.4, {}), 'stowaway': ('mech', 'crimson', 1.6, dict(bulk=1.3, spikes=True)), 'remnant': ('entity', 'null', 1.8, {}),
 # minions
 'spore_crawler': ('crawler', 'verdant', 1.0, {}), 'infection_node': ('node', 'verdant', 1.2, {}), 'bloom_shambler': ('mech', 'verdant', 1.1, dict(bulk=1.3, cannons=False)),
 'foundry_sentry': ('bot', 'steel', 0.65, {}), 'welder_drone': ('bot', 'steel', 0.6, {}), 'armor_plate': ('node', 'steel', 1.3, {}),
 'specimen': ('bot', 'void', 0.6, {}), 'false_target': ('bot', 'void', 0.6, {}), 'echo': ('entity', 'void', 1.0, {}),
 'patrol_drone': ('drone', 'neon', 1.0, {}), 'security_bot': ('bot', 'neon', 0.65, {}), 'enforcer': ('mech', 'neon', 1.2, dict(bulk=1.3)), 'deploy_turret': ('turret', 'neon', 1.0, {}), 'support_node': ('node', 'neon', 1.2, {}),
 'frozen_husk': ('bot', 'ice', 0.65, {}), 'ice_barrier': ('node', 'ice', 1.6, {}), 'frost_minion': ('bot', 'ice', 0.6, {}),
 'phase_drifter': ('drone', 'cosmic', 1.0, {}), 'resonance_node': ('node', 'cosmic', 1.4, {}),
 'armada_trooper': ('bot', 'crimson', 0.7, {}), 'armada_drone': ('drone', 'crimson', 1.0, {}), 'siege_walker': ('mech', 'crimson', 1.3, dict(bulk=1.4)), 'weapon_battery': ('turret', 'crimson', 1.8, {}),
 'null_sentinel': ('bot', 'null', 0.75, {}), 'fracture_drifter': ('drone', 'null', 1.0, {}), 'containment_anchor': ('node', 'null', 1.8, {}),
 'practice_dummy': ('bot', 'steel', 0.75, {}),
}

if __name__ == '__main__':
    only = sys.argv[1:]
    for mid, (arch, theme, k, kw) in MODELS.items():
        if only and mid not in only: continue
        m = M(mid, theme)
        ARCH[arch](m, k, **kw) if arch not in ('bot',) else ARCH[arch](m, k)
        data = m.to_json()
        with open(os.path.join(OUT, mid + '.bbmodel'), 'w') as f: json.dump(data, f, separators=(',', ':'))
        bb = m.bbox(); print('%-20s %-9s %-7s %4d cubes %2d anims  %.1f x %.1f x %.1f blocks' % (mid, arch, theme, len(m.cubes), len(m.anims), bb[0], bb[1], bb[2]))
