#!/usr/bin/env python3
"""Procedural music for VYRNTH. Writes seamless 64s stereo Ogg Vorbis loops to resourcepack/assets/vyrnth/sounds/music/.
These are synthesized atmospheric beds, not composed scores: replace with commissioned music whenever you like (same filenames)."""
import numpy as np, scipy.signal as sg, subprocess, os, wave, sys
SR = 32000; DUR = 64.0; N = int(SR * DUR)
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'resourcepack/assets/vyrnth/sounds/music')
os.makedirs(OUT, exist_ok=True)

def hz(m): return 440.0 * 2 ** ((m - 69) / 12)
def t_(n): return np.arange(n) / SR

def adsr(n, a, r):
    a = max(1, int(a * SR)); r = max(1, int(r * SR)); e = np.ones(n)
    a = min(a, n // 2); r = min(r, n // 2)
    e[:a] = np.linspace(0, 1, a) ** 2; e[n - r:] = np.linspace(1, 0, r) ** 2
    return e

def saw_pad(f, dur, harm=10, detune=0.003):
    n = int(dur * SR); t = t_(n); out = np.zeros(n)
    for d in (-detune, 0, detune):
        ff = f * (1 + d)
        for h in range(1, harm + 1): out += np.sin(2 * np.pi * ff * h * t) / h
    return out * adsr(n, dur * 0.35, dur * 0.35) / 4

def sine(f, dur, a=0.5, r=1.0):
    n = int(dur * SR); return np.sin(2 * np.pi * f * t_(n)) * adsr(n, a, r)

def bell(f, dur=4.0):
    n = int(dur * SR); t = t_(n); out = np.zeros(n)
    for k, (m, a, d) in enumerate([(1, 1.0, 1.0), (2.76, 0.6, 1.6), (5.4, 0.35, 2.4), (8.93, 0.2, 3.2)]):
        out += a * np.sin(2 * np.pi * f * m * t) * np.exp(-t * d * 1.1)
    return out * 0.5

def pluck(f, dur=0.6):
    n = int(dur * SR); t = t_(n)
    return (np.sin(2 * np.pi * f * t) + 0.4 * np.sin(2 * np.pi * 2 * f * t) + 0.2 * np.sin(2 * np.pi * 3 * f * t)) * np.exp(-t * 9) * 0.5

def saw(f, dur, harm=14):
    n = int(dur * SR); t = t_(n); out = np.zeros(n)
    for h in range(1, harm + 1): out += np.sin(2 * np.pi * f * h * t) / h
    return out * adsr(n, 0.01, dur * 0.5) * 0.5

def kick(dur=0.35):
    n = int(dur * SR); t = t_(n); f = 45 + 90 * np.exp(-t * 28)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 9)

def tom(f0=90, dur=0.6):
    n = int(dur * SR); t = t_(n); f = f0 * (1 + 0.8 * np.exp(-t * 20))
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 6)

def hat(rng, dur=0.08):
    n = int(dur * SR); x = rng.standard_normal(n)
    b, a = sg.butter(2, 7000 / (SR / 2), 'high'); return sg.lfilter(b, a, x) * np.exp(-t_(n) * 55) * 0.3

def clank(rng, f, dur=0.5):
    n = int(dur * SR); x = rng.standard_normal(n); q = 30
    b, a = sg.iirpeak(f / (SR / 2), q); y = sg.lfilter(b, a, x)
    return y / (np.max(np.abs(y)) + 1e-9) * np.exp(-t_(n) * 7) * 0.8

def wash(rng, lo, hi, amt, lfo_hz):
    x = rng.standard_normal(N)
    b, a = sg.butter(2, [lo / (SR / 2), hi / (SR / 2)], 'band'); y = sg.lfilter(b, a, x)
    return y * (0.55 + 0.45 * np.sin(2 * np.pi * lfo_hz * t_(N))) * amt

def place(buf, sig, start, pan=0.0, gain=1.0):
    s = int(start * SR)
    if s >= N: return
    e = min(N, s + len(sig)); seg = sig[:e - s] * gain
    l = np.sqrt(0.5 * (1 - pan)) * 2 ** 0.5 / 1.0; r = np.sqrt(0.5 * (1 + pan)) * 2 ** 0.5 / 1.0
    buf[s:e, 0] += seg * min(1, l); buf[s:e, 1] += seg * min(1, r)

def reverb(buf, wet=0.28, secs=2.2, seed=1):
    r = np.random.default_rng(seed); n = int(secs * SR)
    ir = r.standard_normal((n, 2)) * np.exp(-t_(n) * 2.6)[:, None]; ir /= np.sqrt(np.sum(ir ** 2, axis=0))
    out = np.zeros_like(buf)
    for c in range(2): out[:, c] = sg.fftconvolve(buf[:, c], ir[:, c])[:N]
    return buf * (1 - wet) + out * wet * 2.2

def loopify(buf, cf=3.0):
    c = int(cf * SR); body = buf[:N - c].copy()
    fade = np.linspace(0, 1, c)[:, None]
    body[:c] = body[:c] * fade + buf[N - c:] * (1 - fade)
    return np.concatenate([body, body[:c]])[:N] if False else np.concatenate([body, np.zeros((c, 2))])[:N - c]

def chord(root, scale, deg, size=4):
    return [root + scale[(deg + 2 * k) % len(scale)] + 12 * ((deg + 2 * k) // len(scale)) for k in range(size)]

def build(name, s):
    rng = np.random.default_rng(abs(hash(name)) % (2 ** 32)); buf = np.zeros((N, 2))
    root, scale, prog = s['root'], s['scale'], s['prog']; boss = s['kind'] == 'boss'
    seg = DUR / len(prog)
    for i, deg in enumerate(prog):                                   # pads follow the progression
        for k, note in enumerate(chord(root + 12, scale, deg)):
            place(buf, saw_pad(hz(note), seg + 3, s.get('harm', 8)), i * seg - 1.5 if i else 0, pan=(-0.5 + k * 0.33), gain=s.get('pad', 0.5))
        place(buf, sine(hz(root + scale[deg % len(scale)] - 12), seg + 2, 1.0, 2.0), i * seg, 0, 0.7)   # sub bass
    if s.get('drone'):
        for ff, g in ((hz(root - 12), 0.5), (hz(root - 12) * 1.004, 0.4), (hz(root - 5), 0.25)):
            place(buf, sine(ff, DUR, 3, 3), 0, 0, g)
    bpm = s['bpm']; beat = 60.0 / bpm; steps = int(DUR / beat)
    for b in range(steps):
        tt = b * beat
        if s.get('bell') and rng.random() < s['bell']:
            note = root + 24 + rng.choice(scale) + 12 * rng.integers(0, 2)
            place(buf, bell(hz(note)), tt + rng.random() * beat, rng.uniform(-0.8, 0.8), s.get('bellg', 0.22))
        if s.get('pluck') and rng.random() < s['pluck']:
            place(buf, pluck(hz(root + 12 + rng.choice(scale) + 12 * rng.integers(0, 2))), tt, rng.uniform(-0.6, 0.6), 0.22)
        p = s.get('pulse')
        if p in ('kick4', 'kick4arp') and b % 1 == 0: place(buf, kick(), tt, 0, 0.8)
        if p == 'tom' and b % 2 == 0: place(buf, tom(70 + 10 * (b % 4)), tt, 0, 0.7)
        if p == 'tom' and b % 8 == 6: place(buf, tom(55), tt, 0, 0.9)
        if p == 'clank' and rng.random() < s.get('clank', 0.18): place(buf, clank(rng, rng.choice([420, 700, 1100, 1800])), tt, rng.uniform(-0.7, 0.7), 0.35)
        if p in ('kick4', 'kick4arp'): place(buf, hat(rng), tt + beat / 2, 0.3, 0.5)
    if s.get('arp'):                                                  # 16th-note arpeggio on the current chord
        sixteenth = beat / 4 if s['arp'] == 16 else beat / 2
        for j in range(int(DUR / sixteenth)):
            tt = j * sixteenth; deg = prog[min(len(prog) - 1, int(tt / seg))]
            ch = chord(root + 12, scale, deg, 4); n_ = ch[(j * (3 if s.get('arp_skip') else 1)) % 4] + (12 if j % 8 >= 4 else 0)
            place(buf, saw(hz(n_), sixteenth * 1.3), tt, 0.3 * (-1) ** j, s.get('arpg', 0.2))
    if s.get('glitch'):
        for _ in range(int(DUR * s['glitch'])):
            n = int(rng.uniform(0.005, 0.03) * SR); x = rng.standard_normal(n) * np.exp(-np.linspace(0, 6, n))
            place(buf, x * 0.5, rng.uniform(0, DUR - 0.1), rng.uniform(-1, 1), 0.5)
    if s.get('noise'):
        lo, hi, amt, lf = s['noise']
        w = wash(rng, lo, hi, amt, lf); buf[:, 0] += w; buf[:, 1] += np.roll(w, 4000)
    if s.get('stab'):                                                 # brass-ish stabs at bar starts
        bar = beat * 4
        for j in range(int(DUR / bar)):
            if j % 2 == 0:
                deg = prog[min(len(prog) - 1, int(j * bar / seg))]
                for note in chord(root, scale, deg, 3): place(buf, saw(hz(note), 1.2, 18), j * bar, 0, 0.18)
    buf = reverb(buf, s.get('wet', 0.3), seed=len(name))
    buf = loopify(np.vstack([buf, np.zeros((0, 2))]))
    peak = np.max(np.abs(buf)) + 1e-9
    return (buf / peak * 0.72)

MIN = [0, 2, 3, 5, 7, 8, 10]; PENT = [0, 3, 5, 7, 10]; PHRY = [0, 1, 3, 5, 7, 8, 10]; WHOLE = [0, 2, 4, 6, 8, 10]
LYD = [0, 2, 4, 6, 7, 9, 11]; LOC = [0, 1, 3, 5, 6, 8, 10]
TRACKS = {
 # ---------- ambient
 'verdant9':      dict(kind='amb', root=38, scale=PENT, prog=[0, 2, 3, 1], bpm=60, bell=0.35, pluck=0.18, noise=(300, 1800, 0.05, 0.08), drone=True, wet=0.4),
 'ironveil':      dict(kind='amb', root=36, scale=PHRY, prog=[0, 1, 0, 5], bpm=70, pulse='clank', clank=0.28, drone=True, harm=14, noise=(80, 500, 0.06, 0.05)),
 'nullpoint':     dict(kind='amb', root=45, scale=WHOLE, prog=[0, 2, 4, 1], bpm=60, bell=0.4, glitch=0.9, bellg=0.2, wet=0.45),
 'neongrave':     dict(kind='amb', root=33, scale=MIN, prog=[0, 5, 3, 4], bpm=84, arp=16, arpg=0.1, pad=0.4, harm=12, wet=0.35),
 'cryotheta':     dict(kind='amb', root=40, scale=LYD, prog=[0, 3, 1, 4], bpm=56, bell=0.5, noise=(500, 4000, 0.09, 0.05), wet=0.5, bellg=0.25),
 'eclipse':       dict(kind='amb', root=38, scale=LOC, prog=[0, 3, 5, 1], bpm=50, bell=0.25, drone=True, harm=6, wet=0.55),
 'armada':        dict(kind='amb', root=38, scale=MIN, prog=[0, 5, 6, 4], bpm=66, pulse='tom', drone=True, harm=16, noise=(60, 400, 0.05, 0.04)),
 'godsplitter':   dict(kind='amb', root=42, scale=LOC, prog=[0, 1, 4, 3], bpm=48, bell=0.3, drone=True, glitch=0.5, harm=5, wet=0.6, noise=(100, 900, 0.07, 0.03)),
 # ---------- boss
 'rootmind':      dict(kind='boss', root=38, scale=PENT, prog=[0, 2, 0, 3, 0, 2, 3, 1], bpm=100, pulse='tom', pluck=0.4, drone=True, stab=True, harm=12),
 'forge_prime':   dict(kind='boss', root=36, scale=PHRY, prog=[0, 1, 0, 5, 0, 1, 3, 1], bpm=120, pulse='kick4', arp=8, arpg=0.18, drone=True, stab=True, harm=16),
 'subject_zero':  dict(kind='boss', root=45, scale=WHOLE, prog=[0, 2, 4, 1, 0, 3, 5, 2], bpm=128, pulse='kick4', arp=16, arp_skip=True, glitch=1.6, arpg=0.14),
 'the_warden':    dict(kind='boss', root=33, scale=MIN, prog=[0, 5, 3, 4, 0, 5, 6, 4], bpm=132, pulse='kick4', arp=16, arpg=0.2, drone=True, stab=True, harm=14),
 'absolute':      dict(kind='boss', root=40, scale=LYD, prog=[0, 3, 1, 4, 0, 6, 1, 3], bpm=90, pulse='tom', bell=0.6, noise=(500, 5000, 0.12, 0.06), drone=True, stab=True),
 'parallax':      dict(kind='boss', root=38, scale=LOC, prog=[0, 3, 5, 1, 0, 4, 2, 6], bpm=110, pulse='kick4', arp=16, arp_skip=True, drone=True, glitch=0.8, bell=0.3),
 'admiral_vexar': dict(kind='boss', root=38, scale=MIN, prog=[0, 5, 6, 4, 0, 3, 6, 4], bpm=110, pulse='tom', stab=True, drone=True, harm=18, arp=8, arpg=0.12),
 'xerath_null':   dict(kind='boss', root=42, scale=LOC, prog=[0, 1, 4, 3, 0, 5, 2, 1], bpm=140, pulse='kick4', arp=16, arp_skip=True, drone=True, glitch=1.2, stab=True, harm=14, noise=(100, 1200, 0.08, 0.04)),
}

if __name__ == '__main__':
    only = sys.argv[1:]
    for name, style in TRACKS.items():
        if only and name not in only: continue
        a = build(name, style); pcm = (a * 32767).astype(np.int16)
        wav = os.path.join(OUT, name + '.wav')
        with wave.open(wav, 'wb') as w: w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-c:a', 'libvorbis', '-q:a', '2', os.path.join(OUT, name + '.ogg')], check=True)
        os.remove(wav)
        print('wrote', name + '.ogg', round(len(a) / SR, 1), 's', os.path.getsize(os.path.join(OUT, name + '.ogg')) // 1024, 'KB')
