#!/usr/bin/env python3
"""Derives builds.yml (physical geometry) from the layouts in dungeons.yml.
Run: python3 tools/gen_builds.py   (re-run after changing coordinates in dungeons.yml, then copy builds.yml to the plugin folder)."""
import yaml, sys, os, math

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
D = yaml.safe_load(open(os.path.join(ROOT, 'src/main/resources/dungeons.yml')))['dungeons']

PAL = {
 'verdant9':      dict(floor='MOSS_BLOCK', floor2='MUD_BRICKS', wall='MOSSY_STONE_BRICKS', ceiling='MUD_BRICKS', accent='SHROOMLIGHT', light='SHROOMLIGHT', gate='MUDDY_MANGROVE_ROOTS', platform='MOSS_BLOCK', pad='GREEN_CONCRETE'),
 'ironveil':      dict(floor='SMOOTH_STONE', floor2='POLISHED_ANDESITE', wall='POLISHED_DEEPSLATE', ceiling='BLACKSTONE', accent='WAXED_COPPER_BLOCK', light='OCHRE_FROGLIGHT', gate='IRON_BLOCK', platform='WAXED_OXIDIZED_CUT_COPPER', pad='ORANGE_CONCRETE'),
 'nullpoint':     dict(floor='WHITE_CONCRETE', floor2='LIGHT_GRAY_CONCRETE', wall='QUARTZ_BLOCK', ceiling='SMOOTH_QUARTZ', accent='PURPLE_STAINED_GLASS', light='SEA_LANTERN', gate='PURPLE_CONCRETE', platform='QUARTZ_BLOCK', pad='PURPLE_GLAZED_TERRACOTTA'),
 'neongrave':     dict(floor='BLACK_CONCRETE', floor2='GRAY_CONCRETE', wall='DEEPSLATE_TILES', ceiling='BLACKSTONE', accent='CYAN_CONCRETE', light='PEARLESCENT_FROGLIGHT', gate='LIGHT_BLUE_CONCRETE', platform='CYAN_CONCRETE', pad='CYAN_GLAZED_TERRACOTTA'),
 'cryotheta':     dict(floor='PACKED_ICE', floor2='SNOW_BLOCK', wall='BLUE_ICE', ceiling='SNOW_BLOCK', accent='WHITE_CONCRETE', light='SEA_LANTERN', gate='BLUE_ICE', platform='PACKED_ICE', pad='LIGHT_BLUE_CONCRETE'),
 'eclipseengine': dict(floor='PURPUR_BLOCK', floor2='END_STONE_BRICKS', wall='END_STONE_BRICKS', ceiling='OBSIDIAN', accent='CRYING_OBSIDIAN', light='SEA_LANTERN', gate='PURPLE_STAINED_GLASS', platform='PURPUR_BLOCK', pad='MAGENTA_GLAZED_TERRACOTTA'),
 'armada':        dict(floor='SMOOTH_BASALT', floor2='POLISHED_BLACKSTONE', wall='DEEPSLATE_BRICKS', ceiling='POLISHED_BLACKSTONE', accent='RED_CONCRETE', light='OCHRE_FROGLIGHT', gate='RED_CONCRETE', platform='GRAY_CONCRETE', pad='RED_GLAZED_TERRACOTTA'),
 'godsplitter':   dict(floor='OBSIDIAN', floor2='BLACKSTONE', wall='BLACKSTONE', ceiling='BLACK_CONCRETE', accent='AMETHYST_BLOCK', light='SEA_LANTERN', gate='PURPLE_STAINED_GLASS', platform='CRYING_OBSIDIAN', pad='PURPLE_GLAZED_TERRACOTTA'),
}
OPEN = {'eclipseengine', 'godsplitter'}                      # floating architecture: no walls/ceilings
GAPS = {'ironveil': [(128, 173, 'LAVA')], 'cryotheta': [(144, 181, 'AIR')], 'eclipseengine': [(10, 61, 'AIR')], 'godsplitter': [(176, 254, 'AIR')]}
FLOOR = 64

def corners(c): return (c['min'][0], c['max'][0], c['min'][1], c['max'][1], c['min'][2], c['max'][2])

def features(d):
    f = []   # (xmin,xmax,ymax,zmin,zmax)
    def add_c(c): x0,x1,y0,y1,z0,z1 = corners(c); f.append((x0,x1,y1,z0,z1))
    def add_p(x,y,z): f.append((x,x,y,z,z))
    for r in d['rooms'].values():
        add_c(r['trigger'])
        if 'goal' in r: add_c(r['goal'])
        for h in r.get('hazards',{}).values(): add_c(h['region'])
        for sp in r.get('spawns',{}).values(): add_p(sp['pos'][0], sp['pos'][1], sp['pos'][2])
        for a in r.get('activators',[]): add_p(*a)
        if 'routing' in r:
            for j in r['routing']['junctions']: add_p(*j)
        if 'sequence' in r:
            for j in r['sequence']['buttons']: add_p(*j)
        if 'checkpoint' in r: add_p(r['checkpoint']['x'], r['checkpoint']['y'], r['checkpoint']['z'])
    for h in d.get('hazards',{}).values(): add_c(h['region'])
    for t in d.get('turrets',{}).values(): add_p(*t['pos'])
    for m in d.get('crushers',{}).values(): add_c(m['region'])
    for m in d.get('conveyors',{}).values():
        x0,x1,y0,y1,z0,z1 = corners(m['region']); f.append((x0,x1,y0+6,z0,z1))
    for p in d.get('platforms',{}).values():
        x0,x1,y0,y1,z0,z1 = corners(p['region'])
        if p['type']=='SLIDE':
            mx,my,mz = p['move']; z1 += max(mz,0); z0 += min(mz,0); x1 += max(mx,0); x0 += min(mx,0)
        f.append((x0,x1,y1,z0,z1))
    for a in d.get('anomalies',{}).values():
        x0,x1,y0,y1,z0,z1 = corners(a['region']); f.append((x0,x1,(y1 if a['type']=='TELEPORT' else 0),z0,z1))
        for t in a.get('to',[]): add_p(*t)
    for h in d.get('heat',{}).values(): add_c(h['region'])
    for rv in d.get('revival',{}).values(): add_p(*rv['pos'])
    for sx in d.get('secrets',{}).values():
        if sx['type']!='SWITCH': add_p(*sx['pos'])
    add_c(d['boss']['trigger'])
    return f

def sec_range(feats, z0, z1):
    sel = [x for x in feats if not (x[4] < z0 or x[3] > z1)]
    hw = max([max(abs(x[0]),abs(x[1])) for x in sel] + [6]) + 2
    ymax = max([x[2] for x in sel] + [70])
    return hw, ymax

out = {}
for did, d in D.items():
    pal = PAL[did]
    gates = d['gates']
    def is_side(c): return min(abs(c['min'][0]), abs(c['max'][0])) >= 15
    side_gates = [g for g,c in gates.items() if is_side(c)]
    ordered = sorted([(g,c) for g,c in gates.items() if not is_side(c)], key=lambda kv: kv[1]['min'][2])
    feats = features(d)
    spawn_z = int(d['spawn']['z'])
    halls = {}
    z_start = -8
    boundaries = []
    for g,c in ordered:
        boundaries.append((z_start, c['min'][2]-1, g)); z_start = c['max'][2]+1
    boss_z = int(d['boss']['spawn']['z'])
    boundaries.append((z_start, boss_z+24, 'arena'))
    arena_open = did in OPEN
    for idx,(z0,z1,name) in enumerate(boundaries):
        hw, ymax = sec_range(feats, z0, z1)
        if name=='arena':
            hw = max(hw, 22); ymax = max(ymax, 82)
        hw = min(max(hw, 8), 36)
        ymax = min(max(ymax+3, 72), 92)
        halls['h%d_%s' % (idx, name)] = dict(min=[-hw, FLOOR+1, z0], max=[hw, ymax, z1], open=did in OPEN)
    # secret annex + vault alcove
    extras = {}
    if side_gates:
        w = gates[side_gates[0]]; sw = next((s for s in d['secrets'].values() if s['type']=='SWITCH'), None)
        sign = -1 if w['min'][0] < 0 else 1
        # main hall half-width at the switch's z
        swz = sw['pos'][2]
        hall = next(h for h in halls.values() if h['min'][2] <= swz <= h['max'][2])
        hw = hall['max'][0]
        wall_inner = (w['max'][0] + 1) if sign < 0 else (w['min'][0] - 1)   # first interior column on the hall side of the wall
        a0, a1 = sorted([wall_inner, sign*(hw+2)])
        z0 = min(w['min'][2], swz) - 3; z1 = max(w['max'][2], swz) + 3
        extras['annex'] = dict(min=[a0, FLOOR+1, z0], max=[a1, FLOOR+5, z1], door=dict(x=sign*(hw+1), z=[swz-1, swz+1]))
        if abs(a1 - a0) < 1: print('WARN annex too narrow', did, a0, a1)
        sb = next(iter(d.get('secret-bosses',{}).values()), None)
        alcove_inner = (w['min'][0] - 1) if sign < 0 else (w['max'][0] + 1)
        far_edge = (sb['pos'][0] if sb else alcove_inner + sign*10) + sign*8
        b0, b1 = sorted([far_edge, alcove_inner])
        zc = (w['min'][2]+w['max'][2])//2
        extras['alcove'] = dict(min=[b0, FLOOR+1, zc-7], max=[b1, FLOOR+7, zc+7])
    gaps = {}
    for k,(z0,z1,fill) in enumerate(GAPS.get(did, [])):
        hall = next(h for h in halls.values() if h['min'][2] <= z0 and z1 <= h['max'][2])
        hw = hall['max'][0]
        gaps['gap%d' % k] = dict(min=[-hw, FLOOR-6, z0], max=[hw, FLOOR, z1], fill=fill, **({'lava': [60, 62]} if fill=='LAVA' else {}))
    decks = {}; ramps = {}
    if did=='godsplitter':
        decks['spine'] = dict(min=[-2, FLOOR, 176], max=[2, FLOOR, 257], block='PLATFORM')
        for name, sp in d['rooms']['s3_anchors']['spawns'].items():
            if name.startswith('anchor'):
                x, z = int(sp['pos'][0]), int(sp['pos'][2])
                decks['isl_'+name] = dict(min=[x-4, FLOOR, z-4], max=[x+4, FLOOR, z+4], block='ACCENT')
                if x != 0:
                    xa, xb = sorted([0, x]); decks['spur_'+name] = dict(min=[xa, FLOOR, z-1], max=[xb, FLOOR, z+1], block='PLATFORM')
    if did=='neongrave':
        ramps['tower_up']   = dict(x=[-halls[[k for k in halls if 'tower_gate' in k][0]]['max'][0], halls[[k for k in halls if 'tower_gate' in k][0]]['max'][0]], z0=140, y0=65, steps=12, dir=1,  block='STONE_BRICK_STAIRS')
        ramps['tower_down'] = dict(x=[-halls[[k for k in halls if 'tower_gate' in k][0]]['max'][0], halls[[k for k in halls if 'tower_gate' in k][0]]['max'][0]], z0=167, y0=76, steps=12, dir=-1, block='STONE_BRICK_STAIRS')
        hw = halls[[k for k in halls if 'tower_gate' in k][0]]['max'][0]
        decks['tower_deck'] = dict(min=[-hw, 76, 152], max=[hw, 76, 166], block='FLOOR')
        decks['tower_core'] = dict(min=[-hw, 65, 152], max=[hw, 75, 166], block='WALL')
    if 'annex' in extras:
        sw_ = next(s_ for s_ in d['secrets'].values() if s_['type']=='SWITCH')['pos']
        assert extras['annex']['min'][0] <= sw_[0] <= extras['annex']['max'][0], (did, 'switch outside annex', sw_, extras['annex'])
        sb_ = next(iter(d.get('secret-bosses',{}).values()), None)
        if sb_: assert extras['alcove']['min'][0] <= sb_['pos'][0] <= extras['alcove']['max'][0], (did, 'secret boss outside alcove')
    out[did] = dict(**{'floor-y': FLOOR}, palette=pal, halls=halls, gaps=gaps, decks=decks, ramps=ramps, **extras)

yaml.safe_dump(out, open(os.path.join(ROOT, 'src/main/resources/builds.yml'), 'w'), sort_keys=False, default_flow_style=None, width=200)
for did,b in out.items():
    print(did, 'halls', {k:(v['max'][0], v['max'][1], v['min'][2], v['max'][2]) for k,v in b['halls'].items()}, 'annex' in b and b['annex']['min'][0:1]+b['annex']['max'][0:1])
