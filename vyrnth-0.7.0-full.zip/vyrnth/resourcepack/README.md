# VYRNTH resource pack (partial)
Included: pack.mcmeta, sounds.json, lang, and 16 generated music loops (assets/vyrnth/sounds/music/*.ogg, 61s each, seamless): 8 dungeon/raid ambient beds and 8 boss themes, each with its own scale, timbre and rhythm
(tools/gen_music.py; re-run to regenerate). They are synthesized atmospheric tracks, not composed scores: replace any file with commissioned music using the same filename.
Not included: boss/mob textures beyond the procedural ones embedded in the .bbmodel files, custom block/item models, particles, UI art. Merge into the mandatory DeS pack; set pack_format for your version.
